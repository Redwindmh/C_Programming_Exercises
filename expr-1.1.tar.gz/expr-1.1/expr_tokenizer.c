/*
 * expr_tokenizer.c
 *
 * Copyright (C) 2025 by Robert Cousins
 * All Rights Reserved
 *
 * Tokenizer for mathematical expression evaluation library.
 * Implements two-pass parsing: tokenization followed by parsing.
 * Properly handles compound assignment operators and whitespace.
 *
 * $Id: expr_tokenizer.c,v 1.1 2025/06/25 16:02:06 rec Exp rec $
 *
 * Author: Robert Cousins
 *
 * 2025-06-22: Initial implementation for compound assignment fix
 */

#include "expr_private.h"

/*
 * expr_priv_skip_whitespace_pos
 *
 * Advances position past whitespace characters.
 *
 * Input: pos - pointer to current position
 * Output: Position after whitespace
 * Side effects: None
 *
 * Dependencies: Standard library character classification
 *
 * Helper function for tokenizer.
 */
static const char*
expr_priv_skip_whitespace_pos(const char *pos)
{
    while (isspace(*pos))
        pos++;
    return pos;
}

/*
 * expr_priv_add_token
 *
 * Adds a token to the token stream, expanding capacity if needed.
 *
 * Input: stream - token stream to add to
 *        type - token type
 *        start - start position in input
 *        length - token length
 * Output: EXPR_SUCCESS on success, error code on failure
 * Side effects: May reallocate token array
 *
 * Dependencies: Memory allocation
 *
 * Handles dynamic array growth for token storage.
 */
static int
expr_priv_add_token(expr_token_stream_t *stream, expr_token_type_t type, 
                   const char *start, int length)
{
    expr_token_t *new_tokens;
    
    if (stream->count >= stream->capacity) {
        stream->capacity = stream->capacity ? stream->capacity * 2 : 16;
        new_tokens = (expr_token_t*)realloc(stream->tokens, 
                                           stream->capacity * sizeof(expr_token_t));
        if (!new_tokens)
            return EXPR_ERROR_MEMORY;
        stream->tokens = new_tokens;
    }
    
    stream->tokens[stream->count].type = type;
    stream->tokens[stream->count].start = start;
    stream->tokens[stream->count].length = length;
    stream->tokens[stream->count].number_value = 0.0;
    stream->tokens[stream->count].string_value = NULL;
    stream->count++;
    
    return EXPR_SUCCESS;
}

/*
 * expr_priv_tokenize_number
 *
 * Tokenizes a numeric literal.
 *
 * Input: pos - current position in input
 *        stream - token stream to add to
 *        new_pos - pointer to store new position
 * Output: EXPR_SUCCESS on success, error code on failure
 * Side effects: Adds number token to stream
 *
 * Dependencies: Number parsing functions
 *
 * Handles decimal and hexadecimal numbers.
 */
static int
expr_priv_tokenize_number(const char *pos, expr_token_stream_t *stream, const char **new_pos)
{
    const char *start = pos;
    char *endptr;
    double value;
    int ret;
    
    if (strncmp(pos, "0x", 2) == 0 || strncmp(pos, "0X", 2) == 0) {
        value = expr_priv_parse_hex_number(pos, &endptr);
    } else {
        value = strtod(pos, &endptr);
    }
    
    if (endptr == pos)
        return EXPR_ERROR_PARSE;
    
    ret = expr_priv_add_token(stream, TOKEN_NUMBER, start, (int)(endptr - start));
    if (ret != EXPR_SUCCESS)
        return ret;
    
    stream->tokens[stream->count - 1].number_value = value;
    *new_pos = endptr;
    return EXPR_SUCCESS;
}

/*
 * expr_priv_tokenize_identifier
 *
 * Tokenizes an identifier (variable, constant, or function name).
 *
 * Input: pos - current position in input
 *        stream - token stream to add to
 *        new_pos - pointer to store new position
 * Output: EXPR_SUCCESS on success, error code on failure
 * Side effects: Adds identifier token to stream
 *
 * Dependencies: Identifier validation, memory allocation
 *
 * Creates copy of identifier string for token.
 */
static int
expr_priv_tokenize_identifier(const char *pos, expr_token_stream_t *stream, const char **new_pos)
{
    const char *start = pos;
    int length;
    int ret;
    
    if (!expr_priv_is_valid_identifier_start(*pos))
        return EXPR_ERROR_PARSE;
    
    while (expr_priv_is_valid_identifier_char(*pos))
        pos++;
    
    length = (int)(pos - start);
    ret = expr_priv_add_token(stream, TOKEN_IDENTIFIER, start, length);
    if (ret != EXPR_SUCCESS)
        return ret;
    
    /* Create copy of identifier string */
    stream->tokens[stream->count - 1].string_value = (char*)malloc(length + 1);
    if (!stream->tokens[stream->count - 1].string_value)
        return EXPR_ERROR_MEMORY;
    
    strncpy(stream->tokens[stream->count - 1].string_value, start, length);
    stream->tokens[stream->count - 1].string_value[length] = '\0';
    
    *new_pos = pos;
    return EXPR_SUCCESS;
}

/*
 * expr_priv_tokenize_operator
 *
 * Tokenizes operators, including compound assignment operators.
 *
 * Input: pos - current position in input
 *        stream - token stream to add to
 *        options - compilation options
 *        new_pos - pointer to store new position
 * Output: EXPR_SUCCESS on success, error code on failure
 * Side effects: Adds operator token to stream
 *
 * Dependencies: None
 *
 * Handles single and multi-character operators with whitespace.
 */
static int
expr_priv_tokenize_operator(const char *pos, expr_token_stream_t *stream, 
                           unsigned options, const char **new_pos)
{
    const char *lookahead;
    expr_token_type_t token_type;
    int length = 1;
    
    /* Check for compound assignment operators first */
    if (options & EXPR_ENABLE_COMPOUND_ASSIGN) {
        lookahead = expr_priv_skip_whitespace_pos(pos + 1);
        if (*lookahead == '=') {
            switch (*pos) {
                case '+':
                    token_type = TOKEN_ADD_ASSIGN;
                    length = (int)(lookahead - pos + 1);
                    break;
                case '-':
                    token_type = TOKEN_SUB_ASSIGN;
                    length = (int)(lookahead - pos + 1);
                    break;
                case '*':
                    token_type = TOKEN_MUL_ASSIGN;
                    length = (int)(lookahead - pos + 1);
                    break;
                case '/':
                    token_type = TOKEN_DIV_ASSIGN;
                    length = (int)(lookahead - pos + 1);
                    break;
                case '^':
                    if (options & EXPR_ENABLE_POWER) {
                        token_type = TOKEN_POW_ASSIGN;
                        length = (int)(lookahead - pos + 1);
                    } else {
                        return EXPR_ERROR_PARSE;
                    }
                    break;
                case '%':
                    if (options & EXPR_ENABLE_MODULO) {
                        token_type = TOKEN_MOD_ASSIGN;
                        length = (int)(lookahead - pos + 1);
                    } else {
                        return EXPR_ERROR_PARSE;
                    }
                    break;
                default:
                    goto single_char_operator;
            }
            *new_pos = lookahead + 1;
            return expr_priv_add_token(stream, token_type, pos, length);
        }
    }
    
single_char_operator:
    /* Handle single-character operators */
    switch (*pos) {
        case '+':
            token_type = TOKEN_PLUS;
            break;
        case '-':
            token_type = TOKEN_MINUS;
            break;
        case '*':
            token_type = TOKEN_MULTIPLY;
            break;
        case '/':
            token_type = TOKEN_DIVIDE;
            break;
        case '^':
            if (options & EXPR_ENABLE_POWER) {
                token_type = TOKEN_POWER;
            } else {
                return EXPR_ERROR_PARSE;
            }
            break;
        case '%':
            if (options & EXPR_ENABLE_MODULO) {
                token_type = TOKEN_MODULO;
            } else {
                return EXPR_ERROR_PARSE;
            }
            break;
        case '=':
            token_type = TOKEN_ASSIGN;
            break;
        case '(':
            token_type = TOKEN_LPAREN;
            break;
        case ')':
            token_type = TOKEN_RPAREN;
            break;
        case ',':
            token_type = TOKEN_COMMA;
            break;
        case ';':
            if (options & EXPR_ALLOW_SEMICOLON) {
                token_type = TOKEN_SEMICOLON;
            } else {
                return EXPR_ERROR_PARSE;
            }
            break;
        default:
            return EXPR_ERROR_PARSE;
    }
    
    *new_pos = pos + 1;
    return expr_priv_add_token(stream, token_type, pos, 1);
}

/*
 * expr_priv_tokenize
 *
 * Tokenizes an input expression string into a token stream.
 *
 * Input: input - expression string to tokenize
 *        ctx - context for error reporting
 *        options - compilation options
 *        stream - pointer to store token stream
 * Output: EXPR_SUCCESS on success, error code on failure
 * Side effects: Allocates token stream and tokens
 *
 * Dependencies: All tokenizer helper functions
 *
 * Main tokenization function for two-pass parser.
 */
int
expr_priv_tokenize(const char *input, expr_context ctx, unsigned options, expr_token_stream_t **stream)
{
    expr_token_stream_t *new_stream;
    const char *pos = input;
    int ret;
    
    if (!input || !stream)
        return EXPR_ERROR_INVALID_PARAM;
    
    new_stream = (expr_token_stream_t*)malloc(sizeof(expr_token_stream_t));
    if (!new_stream)
        return EXPR_ERROR_MEMORY;
    
    new_stream->tokens = NULL;
    new_stream->count = 0;
    new_stream->capacity = 0;
    new_stream->position = 0;
    
    while (*pos) {
        pos = expr_priv_skip_whitespace_pos(pos);
        if (!*pos)
            break;
        
        if (isdigit(*pos) || (strncmp(pos, "0x", 2) == 0) || (strncmp(pos, "0X", 2) == 0)) {
            ret = expr_priv_tokenize_number(pos, new_stream, &pos);
        } else if (expr_priv_is_valid_identifier_start(*pos)) {
            ret = expr_priv_tokenize_identifier(pos, new_stream, &pos);
        } else {
            ret = expr_priv_tokenize_operator(pos, new_stream, options, &pos);
        }
        
        if (ret != EXPR_SUCCESS) {
            expr_priv_set_error(ctx, "Invalid token", pos);
            expr_priv_free_token_stream(new_stream);
            return ret;
        }
    }
    
    /* Add EOF token */
    ret = expr_priv_add_token(new_stream, TOKEN_EOF, pos, 0);
    if (ret != EXPR_SUCCESS) {
        expr_priv_free_token_stream(new_stream);
        return ret;
    }
    
    *stream = new_stream;
    return EXPR_SUCCESS;
}

/*
 * expr_priv_free_token_stream
 *
 * Frees a token stream and all associated memory.
 *
 * Input: stream - token stream to free
 * Output: None
 * Side effects: Frees all token memory
 *
 * Dependencies: Standard library free
 *
 * Cleanup function for token streams.
 */
void
expr_priv_free_token_stream(expr_token_stream_t *stream)
{
    int i;
    
    if (!stream)
        return;
    
    if (stream->tokens) {
        for (i = 0; i < stream->count; i++) {
            if (stream->tokens[i].string_value)
                free(stream->tokens[i].string_value);
        }
        free(stream->tokens);
    }
    
    free(stream);
}

/*
 * expr_priv_current_token
 *
 * Returns the current token in the stream.
 *
 * Input: stream - token stream
 * Output: Current token or NULL if at end
 * Side effects: None
 *
 * Dependencies: None
 *
 * Token stream navigation helper.
 */
expr_token_t*
expr_priv_current_token(expr_token_stream_t *stream)
{
    if (!stream || stream->position >= stream->count)
        return NULL;
    
    return &stream->tokens[stream->position];
}

/*
 * expr_priv_peek_token
 *
 * Returns a token at specified offset from current position.
 *
 * Input: stream - token stream
 *        offset - offset from current position
 * Output: Token at offset or NULL if out of bounds
 * Side effects: None
 *
 * Dependencies: None
 *
 * Lookahead helper for parser.
 */
expr_token_t*
expr_priv_peek_token(expr_token_stream_t *stream, int offset)
{
    int pos;
    
    if (!stream)
        return NULL;
    
    pos = stream->position + offset;
    if (pos < 0 || pos >= stream->count)
        return NULL;
    
    return &stream->tokens[pos];
}

/*
 * expr_priv_advance_token
 *
 * Advances to the next token in the stream.
 *
 * Input: stream - token stream
 * Output: None
 * Side effects: Updates stream position
 *
 * Dependencies: None
 *
 * Token stream navigation helper.
 */
void
expr_priv_advance_token(expr_token_stream_t *stream)
{
    if (stream && stream->position < stream->count)
        stream->position++;
}

/*
 * expr_priv_expect_token
 *
 * Checks if current token matches expected type.
 *
 * Input: stream - token stream
 *        expected - expected token type
 * Output: EXPR_SUCCESS if match, error code otherwise
 * Side effects: None
 *
 * Dependencies: None
 *
 * Parser validation helper.
 */
int
expr_priv_expect_token(expr_token_stream_t *stream, expr_token_type_t expected)
{
    expr_token_t *token;
    
    if (!stream)
        return EXPR_ERROR_INVALID_PARAM;
    
    token = expr_priv_current_token(stream);
    if (!token || token->type != expected)
        return EXPR_ERROR_PARSE;
    
    return EXPR_SUCCESS;
}