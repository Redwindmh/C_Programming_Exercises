# Mathematical Expression Evaluation Library

A portable C library for parsing, evaluating, and optimizing mathematical expressions with advanced optimization capabilities and detailed reporting.

## Features

- **ANSI C Implementation**: Portable across Windows, Linux, FreeBSD, and macOS
- **Recursive Descent Parser**: Proper operator precedence with support for parentheses
- **Rich Operator Support**: Arithmetic, assignment, power, modulo, and compound assignment operators
- **Function Support**: Zero to four parameter functions with pure function optimization
- **Variable System**: Read/write variables with permission controls
- **Advanced Optimization**: Multiple optimization passes with detailed reporting
- **Comprehensive Testing**: Full test suite with performance benchmarking
- **Interactive Demo**: Calculator with built-in mathematical functions
- **Modular Architecture**: Clean separation of parser, symbols, evaluation, and optimization

## Architecture

The library is organized into focused, maintainable modules:

### Core Modules
- **expr_context.c** - Context management and error handling
- **expr_parser_core.c** - Main recursive descent parser implementation
- **expr_parser_validation.c** - Input validation and assignment checking
- **expr_symbol_table.c** - Individual symbol management (constants, variables, functions)
- **expr_symbol_batch.c** - Efficient batch symbol operations
- **expr_evaluator.c** - AST evaluation and computation
- **expr_optimizer.c** - Multi-pass expression optimization
- **expr_tokenizer.c** - Two-pass tokenization with compound operator support
- **expr_ast.c** - Abstract syntax tree operations

### Support Files
- **expr.h** - Public API declarations
- **expr_private.h** - Internal structures and private function declarations
- **test_expr.c** - Comprehensive test suite (256 tests)
- **demo_calculator.c** - Interactive calculator demonstration
- **manual.pdf** - Complete LaTeX manual (75 pages) with detailed API documentation

This modular design enables:
- Easy maintenance and debugging
- Clear separation of concerns  
- Focused testing of individual components
- Flexible extension and modification

## Quick Start

### Building

```bash
make all          # Build library, programs, and tests
make test         # Build and run test suite
make demo         # Build demo calculator
```

### Basic Usage

```c
#include "expr.h"

int main() {
    expr_context ctx;
    expr_handle handle;
    double result;
    
    // Create context
    expr_context_new(&ctx);
    
    // Add mathematical functions
    expr_add_function1(ctx, "sqrt", sqrt, EXPR_FUNC_PURE);
    
    // Method 1: Full compilation and evaluation
    expr_compile(ctx, "sqrt(16) + 2 * 3", 0, &handle);
    expr_evaluate(handle, &result);
    printf("Result: %g\\n", result);  // Output: 10
    expr_handle_free(handle);
    
    // Method 2: Convenience function (one-shot evaluation)
    expr_easy(ctx, "sqrt(25) + 1", &result);
    printf("Easy result: %g\\n", result);  // Output: 6
    
    // Cleanup
    expr_context_free(ctx);
    return 0;
}
```

## Supported Operators

| Operator | Symbol | Precedence | Associativity |
|----------|--------|------------|---------------|
| Parentheses | `()` | Highest | N/A |
| Unary Plus/Minus | `+` `-` | Very High | Right |
| Exponentiation | `^` | Very High | Right |
| Multiplication/Division | `*` `/` `%` | High | Left |
| Addition/Subtraction | `+` `-` | Medium | Left |
| Assignment | `=` `+=` `-=` `*=` `/=` `^=` `%=` | Low | Right |

## Mathematical Functions

The demo calculator includes comprehensive mathematical functions:

- **Trigonometric**: `sin`, `cos`, `tan`, `asin`, `acos`, `atan`, `atan2`
- **Hyperbolic**: `sinh`, `cosh`, `tanh`
- **Exponential**: `exp`, `log`, `log10`, `pow`
- **Utility**: `sqrt`, `abs`, `ceil`, `floor`, `round`, `min`, `max`
- **Constants**: `pi`, `e`, `inf`, `nan`

## Optimization System

The library includes six optimization passes:

1. **Constant Folding** ✅: Evaluates constant expressions at compile time
2. **Dead Code Elimination** ✅: Removes redundant operations (x*1=x, x+0=x)
3. **Common Subexpression Elimination** ✅: Infrastructure for caching repeated subexpressions
4. **Pure Function Optimization** ✅: Pre-evaluates pure functions with constant arguments
5. **Algebraic Simplification** (placeholder): Would perform algebraic transformations
6. **Strength Reduction** ✅: Replaces expensive operations with cheaper equivalents (x^2→x*x)

### Optimization Example

```c
expr_handle handle;
optimization_report_t report;

expr_compile(ctx, "2 + 3 * 4", 0, &handle);
expr_optimize(&handle, &report);

printf("Optimization: %s\\n", report.summary);
// Output: "Optimization completed in 2 passes. Nodes: 5 -> 1. Constant folding: 1, Dead code: 0"

expr_free_optimization_report(&report);
```

## Error Handling

The library provides detailed error reporting with position information:

```c
int ret = expr_compile(ctx, "2 + unknown_var", 0, &handle);
if (ret != EXPR_SUCCESS) {
    printf("Error: %s\\n", expr_error(ctx));
    printf("Position: %d\\n", expr_error_position(ctx));
    // Output: Error: Undefined symbol
    //         Position: 4
}
```

## Performance

The library is designed for high performance with typical benchmarks showing:

- **Compilation**: ~0.0008 ms per expression
- **Evaluation**: ~0.000035 ms per evaluation (unoptimized)
- **Optimized Evaluation**: ~0.000002 ms per evaluation
- **Optimization Speedup**: 9-18x improvement for repeated evaluations
- **Node Reduction**: Up to 13:1 reduction in AST complexity

## Installation

```bash
make install          # Install library and headers to /usr/local
make uninstall        # Remove installed files
```

## Demo Calculator

Try the interactive calculator:

```bash
./demo_calculator
```

Commands:
- `:help` - Show help
- `:vars` - List variables
- `:funcs` - List functions
- `:optimize on/off` - Enable optimization reporting
- `:quit` - Exit

## API Reference

### Core Functions

- `expr_context_new()` - Create new context
- `expr_context_free()` - Free context
- `expr_compile()` - Compile expression to AST
- `expr_evaluate()` - Evaluate compiled expression
- `expr_easy()` - Convenience function (compile, evaluate, and free in one call)
- `expr_optimize()` - Optimize expression with reporting
- `expr_handle_free()` - Free compiled expression

### Symbol Management

- `expr_add_constant()` - Add named constant
- `expr_add_variable()` - Add variable with permissions
- `expr_add_function[0-4]()` - Add functions with 0-4 parameters

### Batch Symbol Management

For efficient setup of multiple symbols, use the batch addition functions:

- `expr_add_constant_list()` - Add multiple constants at once
- `expr_add_variable_list()` - Add multiple variables at once
- `expr_add_function[0-4]_list()` - Add multiple functions at once

#### Batch Addition Example

```c
#include "expr.h"

expr_context ctx;
expr_context_new(&ctx);

// Define constants in array
expr_constant_entry_t constants[] = {
    {"pi", 3.14159265359, 0},
    {"e", 2.71828182846, 0},
    {"golden", 1.61803398875, 0}
};
expr_add_constant_list(ctx, 3, constants);

// Define variables in array  
double x = 5.0, y = 10.0;
expr_variable_entry_t variables[] = {
    {"x", &x, EXPR_VAR_READ_WRITE},
    {"y", &y, EXPR_VAR_READABLE}
};
expr_add_variable_list(ctx, 2, variables);

// Define functions in array
expr_function1_entry_t functions[] = {
    {"sin", sin, EXPR_FUNC_PURE},
    {"cos", cos, EXPR_FUNC_PURE},
    {"sqrt", sqrt, EXPR_FUNC_PURE}
};
expr_add_function1_list(ctx, 3, functions);

// Now use the symbols
double result;
expr_easy(ctx, "sqrt(x*x + y*y) + pi", &result);
printf("Result: %g\n", result);  // Output: 14.1416

expr_context_free(ctx);
```

## Testing

Run the comprehensive test suite:

```bash
./test_expr
```

The test suite covers:
- Basic parsing and evaluation
- All operators and precedence rules
- Function calls and variable operations
- Batch symbol addition functions
- Error handling and edge cases
- Performance benchmarking (individual vs batch operations)
- Optimization effectiveness

## License

Copyright (C) 2025 by Robert Cousins. All Rights Reserved.

## Technical Details

- **Memory Management**: Careful cleanup with leak prevention
- **Thread Safety**: Context-local state (contexts are not thread-safe)
- **Portability**: ANSI C with standard library dependencies
- **Precision**: Double-precision floating point throughout
- **Limits**: No hard limits on expression complexity

## Distribution

The library can be packaged for distribution using:

```bash
make release    # Creates expr-1.1.tar.gz (alias for package)
make package    # Creates expr-1.1.tar.gz with file listing
```

The package includes all source files, headers, documentation (including 75-page PDF manual), and build system needed for compilation and installation on target systems.

## Known Limitations

- Symbol names are case-sensitive and follow identifier rules (supports UTF-8, underscores, periods)
- No support for complex numbers or arbitrary precision arithmetic
- One optimization pass is a placeholder implementation (Algebraic Simplification)

This implementation provides a robust, high-performance mathematical expression evaluation system suitable for embedded use in larger applications requiring formula processing capabilities.