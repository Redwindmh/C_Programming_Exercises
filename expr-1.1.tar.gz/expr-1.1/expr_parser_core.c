/*
 * expr_parser_core.c
 *
 * Copyright (C) 2025 by Robert Cousins
 * All Rights Reserved
 *
 * Core recursive descent parser for mathematical expression evaluation library.
 * Implements operator precedence parsing following the specification's
 * precedence table with proper associativity handling.
 *
 * $Id: expr_parser_core.c,v 1.1 2025/06/25 16:02:06 rec Exp rec $
 *
 * Author: Robert Cousins
 *
 * 2025-06-25: Split from expr_parser.c for better modularity
 */

#include "expr_private.h"

/*
 * expr_priv_parse_primary
 *
 * Parses primary expressions (numbers, identifiers, parentheses).
 *
 * Input: state - parser state
 *        result - pointer to store parsed node
 * Output: EXPR_SUCCESS on success, error code on failure
 * Side effects: Updates parser position, creates AST nodes
 *
 * Dependencies: Number/identifier parsing, symbol lookup
 *
 * Handles numbers, variables, constants, functions, and parentheses.
 */
int
expr_priv_parse_primary(expr_parser_state_t *state, expr_node_t **result)
{
    expr_node_t *node;
    expr_symbol_t *symbol;
    expr_token_t *token;
    int ret, i, arg_count;
    
    token = expr_priv_current_token(state->tokens);
    if (!token || token->type == TOKEN_EOF) {
        expr_priv_set_error(state->ctx, "Unexpected end of expression", token ? token->start : state->input);
        return EXPR_ERROR_PARSE;
    }
    
    if (token->type == TOKEN_LPAREN) {
        expr_priv_advance_token(state->tokens);
        ret = expr_priv_parse_expression(state, result);
        if (ret != EXPR_SUCCESS)
            return ret;
        
        token = expr_priv_current_token(state->tokens);
        if (!token || token->type != TOKEN_RPAREN) {
            expr_priv_set_error(state->ctx, "Missing closing parenthesis", token ? token->start : state->input);
            expr_priv_node_free(*result);
            return EXPR_ERROR_PARSE;
        }
        expr_priv_advance_token(state->tokens);
        return EXPR_SUCCESS;
    }
    
    if (token->type == TOKEN_NUMBER) {
        node = expr_priv_node_new(EXPR_NODE_NUMBER);
        if (!node)
            return EXPR_ERROR_MEMORY;
        
        node->data.number = token->number_value;
        *result = node;
        expr_priv_advance_token(state->tokens);
        return EXPR_SUCCESS;
    }
    
    if (token->type == TOKEN_IDENTIFIER) {
        symbol = expr_priv_symbol_find(state->ctx, token->string_value);
        if (!symbol) {
            expr_priv_set_error(state->ctx, "Undefined symbol", token->start);
            return EXPR_ERROR_UNDEFINED_SYMBOL;
        }
        
        switch (symbol->type) {
            case EXPR_SYMBOL_CONSTANT:
                node = expr_priv_node_new(EXPR_NODE_CONSTANT);
                if (!node)
                    return EXPR_ERROR_MEMORY;
                
                node->data.symbol.name = (char*)malloc(strlen(token->string_value) + 1);
                if (!node->data.symbol.name) {
                    expr_priv_node_free(node);
                    return EXPR_ERROR_MEMORY;
                }
                strcpy(node->data.symbol.name, token->string_value);
                node->data.symbol.symbol_ptr = symbol;
                *result = node;
                expr_priv_advance_token(state->tokens);
                return EXPR_SUCCESS;
                
            case EXPR_SYMBOL_VARIABLE:
                /* Check if this variable will be used for assignment (lookahead) */
                {
                    expr_token_t *next_token = expr_priv_peek_token(state->tokens, 1);
                    int is_assignment = 0;
                    
                    if (next_token) {
                        is_assignment = (next_token->type == TOKEN_ASSIGN ||
                                       next_token->type == TOKEN_ADD_ASSIGN ||
                                       next_token->type == TOKEN_SUB_ASSIGN ||
                                       next_token->type == TOKEN_MUL_ASSIGN ||
                                       next_token->type == TOKEN_DIV_ASSIGN ||
                                       next_token->type == TOKEN_POW_ASSIGN ||
                                       next_token->type == TOKEN_MOD_ASSIGN);
                    }
                    
                    /* For non-assignment contexts, validate read permissions */
                    if (!is_assignment && !(symbol->options & EXPR_VAR_READABLE)) {
                        expr_priv_set_error(state->ctx, "Variable is not readable", token->start);
                        return EXPR_ERROR_INVALID_VARIABLE;
                    }
                }
                
                node = expr_priv_node_new(EXPR_NODE_VARIABLE);
                if (!node)
                    return EXPR_ERROR_MEMORY;
                
                node->data.symbol.name = (char*)malloc(strlen(token->string_value) + 1);
                if (!node->data.symbol.name) {
                    expr_priv_node_free(node);
                    return EXPR_ERROR_MEMORY;
                }
                strcpy(node->data.symbol.name, token->string_value);
                node->data.symbol.symbol_ptr = symbol;
                *result = node;
                expr_priv_advance_token(state->tokens);
                return EXPR_SUCCESS;
                
            case EXPR_SYMBOL_FUNCTION0:
            case EXPR_SYMBOL_FUNCTION1:
            case EXPR_SYMBOL_FUNCTION2:
            case EXPR_SYMBOL_FUNCTION3:
            case EXPR_SYMBOL_FUNCTION4:
                expr_priv_advance_token(state->tokens);
                
                token = expr_priv_current_token(state->tokens);
                if (!token || token->type != TOKEN_LPAREN) {
                    expr_priv_set_error(state->ctx, "Function requires parentheses", token ? token->start : state->input);
                    return EXPR_ERROR_PARSE;
                }
                expr_priv_advance_token(state->tokens);
                
                arg_count = symbol->type - EXPR_SYMBOL_FUNCTION0;
                node = expr_priv_node_new(EXPR_NODE_FUNCTION0 + arg_count);
                if (!node)
                    return EXPR_ERROR_MEMORY;
                
                node->data.function.arg_count = arg_count;
                node->data.function.symbol_ptr = symbol;
                
                if (arg_count > 0) {
                    node->data.function.args = (expr_node_t**)malloc(arg_count * sizeof(expr_node_t*));
                    if (!node->data.function.args) {
                        expr_priv_node_free(node);
                        return EXPR_ERROR_MEMORY;
                    }
                    
                    /* Initialize all pointers to NULL for safe cleanup */
                    for (i = 0; i < arg_count; i++) {
                        node->data.function.args[i] = NULL;
                    }
                    
                    for (i = 0; i < arg_count; i++) {
                        if (i > 0) {
                            token = expr_priv_current_token(state->tokens);
                            if (!token || token->type != TOKEN_COMMA) {
                                expr_priv_set_error(state->ctx, "Missing comma in function arguments", token ? token->start : state->input);
                                expr_priv_node_free(node);
                                return EXPR_ERROR_PARSE;
                            }
                            expr_priv_advance_token(state->tokens);
                        }
                        
                        ret = expr_priv_parse_expression(state, &node->data.function.args[i]);
                        if (ret != EXPR_SUCCESS) {
                            expr_priv_node_free(node);
                            return ret;
                        }
                    }
                }
                
                token = expr_priv_current_token(state->tokens);
                if (!token || token->type != TOKEN_RPAREN) {
                    expr_priv_set_error(state->ctx, "Missing closing parenthesis in function call", token ? token->start : state->input);
                    expr_priv_node_free(node);
                    return EXPR_ERROR_PARSE;
                }
                expr_priv_advance_token(state->tokens);
                
                *result = node;
                return EXPR_SUCCESS;
        }
    }
    
    expr_priv_set_error(state->ctx, "Unexpected token", token->start);
    return EXPR_ERROR_PARSE;
}

/*
 * expr_priv_parse_unary
 *
 * Parses unary expressions (unary +, unary -).
 *
 * Input: state - parser state
 *        result - pointer to store parsed node
 * Output: EXPR_SUCCESS on success, error code on failure
 * Side effects: Updates parser position, creates AST nodes
 *
 * Dependencies: Primary expression parsing
 *
 * Handles unary plus and minus operators with right associativity.
 */
int
expr_priv_parse_unary(expr_parser_state_t *state, expr_node_t **result)
{
    expr_node_t *node;
    expr_token_t *token, *next_token;
    int ret;
    
    token = expr_priv_current_token(state->tokens);
    if (!token)
        return EXPR_ERROR_PARSE;
    
    if (token->type == TOKEN_PLUS) {
        /* Unary plus is allowed, no consecutive operator check needed here */
        
        expr_priv_advance_token(state->tokens);
        ret = expr_priv_parse_unary(state, result);
        if (ret != EXPR_SUCCESS)
            return ret;
        
        node = expr_priv_node_new(EXPR_NODE_UNARY_PLUS);
        if (!node) {
            expr_priv_node_free(*result);
            return EXPR_ERROR_MEMORY;
        }
        
        node->data.unary.operand = *result;
        *result = node;
        return EXPR_SUCCESS;
    }
    
    if (token->type == TOKEN_MINUS) {
        /* Unary minus is allowed, no consecutive operator check needed here */
        
        expr_priv_advance_token(state->tokens);
        ret = expr_priv_parse_unary(state, result);
        if (ret != EXPR_SUCCESS)
            return ret;
        
        node = expr_priv_node_new(EXPR_NODE_UNARY_MINUS);
        if (!node) {
            expr_priv_node_free(*result);
            return EXPR_ERROR_MEMORY;
        }
        
        node->data.unary.operand = *result;
        *result = node;
        return EXPR_SUCCESS;
    }
    
    return expr_priv_parse_primary(state, result);
}

/*
 * expr_priv_parse_power
 *
 * Parses power expressions (^ operator).
 *
 * Input: state - parser state
 *        result - pointer to store parsed node
 * Output: EXPR_SUCCESS on success, error code on failure
 * Side effects: Updates parser position, creates AST nodes
 *
 * Dependencies: Unary expression parsing
 *
 * Handles exponentiation with right associativity.
 */
int
expr_priv_parse_power(expr_parser_state_t *state, expr_node_t **result)
{
    expr_node_t *left, *right, *node;
    expr_token_t *token;
    int ret;
    
    ret = expr_priv_parse_unary(state, &left);
    if (ret != EXPR_SUCCESS)
        return ret;
    
    token = expr_priv_current_token(state->tokens);
    if (token && token->type == TOKEN_POWER && (state->options & EXPR_ENABLE_POWER)) {
        expr_priv_advance_token(state->tokens);
        ret = expr_priv_parse_power(state, &right);
        if (ret != EXPR_SUCCESS) {
            expr_priv_node_free(left);
            return ret;
        }
        
        node = expr_priv_node_new(EXPR_NODE_POWER);
        if (!node) {
            expr_priv_node_free(left);
            expr_priv_node_free(right);
            return EXPR_ERROR_MEMORY;
        }
        
        node->data.binary.left = left;
        node->data.binary.right = right;
        *result = node;
        return EXPR_SUCCESS;
    }
    
    *result = left;
    return EXPR_SUCCESS;
}

/*
 * expr_priv_parse_multiplication
 *
 * Parses multiplication, division, and modulo expressions.
 *
 * Input: state - parser state
 *        result - pointer to store parsed node
 * Output: EXPR_SUCCESS on success, error code on failure
 * Side effects: Updates parser position, creates AST nodes
 *
 * Dependencies: Power expression parsing
 *
 * Handles *, /, % operators with left associativity.
 */
int
expr_priv_parse_multiplication(expr_parser_state_t *state, expr_node_t **result)
{
    expr_node_t *left, *right, *node;
    expr_node_type_t op_type;
    expr_token_t *token;
    int ret;
    
    ret = expr_priv_parse_power(state, &left);
    if (ret != EXPR_SUCCESS)
        return ret;
    
    while (1) {
        token = expr_priv_current_token(state->tokens);
        if (!token)
            break;
        
        if (token->type == TOKEN_MULTIPLY) {
            op_type = EXPR_NODE_MULTIPLY;
        } else if (token->type == TOKEN_DIVIDE) {
            op_type = EXPR_NODE_DIVIDE;
        } else if (token->type == TOKEN_MODULO && (state->options & EXPR_ENABLE_MODULO)) {
            op_type = EXPR_NODE_MODULO;
        } else {
            break;
        }
        
        /* Check for consecutive binary operators (but allow unary after binary) */
        expr_token_t *next_token = expr_priv_peek_token(state->tokens, 1);
        if (next_token && (next_token->type == TOKEN_MULTIPLY || next_token->type == TOKEN_DIVIDE ||
                           next_token->type == TOKEN_POWER || next_token->type == TOKEN_MODULO)) {
            expr_priv_set_error(state->ctx, "Consecutive operators not allowed", next_token->start);
            expr_priv_node_free(left);
            return EXPR_ERROR_PARSE;
        }
        
        expr_priv_advance_token(state->tokens);
        ret = expr_priv_parse_power(state, &right);
        if (ret != EXPR_SUCCESS) {
            expr_priv_node_free(left);
            return ret;
        }
        
        node = expr_priv_node_new(op_type);
        if (!node) {
            expr_priv_node_free(left);
            expr_priv_node_free(right);
            return EXPR_ERROR_MEMORY;
        }
        
        node->data.binary.left = left;
        node->data.binary.right = right;
        left = node;
    }
    
    *result = left;
    return EXPR_SUCCESS;
}

/*
 * expr_priv_parse_addition
 *
 * Parses addition and subtraction expressions.
 *
 * Input: state - parser state
 *        result - pointer to store parsed node
 * Output: EXPR_SUCCESS on success, error code on failure
 * Side effects: Updates parser position, creates AST nodes
 *
 * Dependencies: Multiplication expression parsing
 *
 * Handles +, - binary operators with left associativity.
 */
int
expr_priv_parse_addition(expr_parser_state_t *state, expr_node_t **result)
{
    expr_node_t *left, *right, *node;
    expr_node_type_t op_type;
    expr_token_t *token;
    int ret;
    
    ret = expr_priv_parse_multiplication(state, &left);
    if (ret != EXPR_SUCCESS)
        return ret;
    
    while (1) {
        token = expr_priv_current_token(state->tokens);
        if (!token)
            break;
        
        if (token->type == TOKEN_PLUS) {
            op_type = EXPR_NODE_ADD;
            /* Check for double plus (2 + + 3) which should be an error */
            expr_token_t *next_token = expr_priv_peek_token(state->tokens, 1);
            if (next_token && next_token->type == TOKEN_PLUS) {
                expr_priv_set_error(state->ctx, "Consecutive operators not allowed", next_token->start);
                expr_priv_node_free(left);
                return EXPR_ERROR_PARSE;
            }
        } else if (token->type == TOKEN_MINUS) {
            op_type = EXPR_NODE_SUBTRACT;
            /* Check for double minus after binary context (2 - - 3) which should be an error */
            expr_token_t *next_token = expr_priv_peek_token(state->tokens, 1);
            if (next_token && next_token->type == TOKEN_MINUS) {
                expr_priv_set_error(state->ctx, "Consecutive operators not allowed", next_token->start);
                expr_priv_node_free(left);
                return EXPR_ERROR_PARSE;
            }
        } else {
            break;
        }
        
        /* Check for consecutive binary operators (but allow unary after binary) */
        expr_token_t *next_token = expr_priv_peek_token(state->tokens, 1);
        if (next_token && (next_token->type == TOKEN_MULTIPLY || next_token->type == TOKEN_DIVIDE ||
                           next_token->type == TOKEN_POWER || next_token->type == TOKEN_MODULO)) {
            expr_priv_set_error(state->ctx, "Consecutive operators not allowed", next_token->start);
            expr_priv_node_free(left);
            return EXPR_ERROR_PARSE;
        }
        
        expr_priv_advance_token(state->tokens);
        ret = expr_priv_parse_multiplication(state, &right);
        if (ret != EXPR_SUCCESS) {
            expr_priv_node_free(left);
            return ret;
        }
        
        node = expr_priv_node_new(op_type);
        if (!node) {
            expr_priv_node_free(left);
            expr_priv_node_free(right);
            return EXPR_ERROR_MEMORY;
        }
        
        node->data.binary.left = left;
        node->data.binary.right = right;
        left = node;
    }
    
    *result = left;
    return EXPR_SUCCESS;
}

/*
 * expr_priv_parse_assignment
 *
 * Parses assignment expressions (=, +=, -=, etc.).
 *
 * Input: state - parser state
 *        result - pointer to store parsed node
 * Output: EXPR_SUCCESS on success, error code on failure
 * Side effects: Updates parser position, creates AST nodes
 *
 * Dependencies: Addition expression parsing
 *
 * Handles assignment operators with right associativity.
 */
int
expr_priv_parse_assignment(expr_parser_state_t *state, expr_node_t **result)
{
    expr_node_t *left, *right, *node;
    expr_node_type_t op_type;
    expr_token_t *token;
    int ret;
    
    ret = expr_priv_parse_addition(state, &left);
    if (ret != EXPR_SUCCESS)
        return ret;
    
    token = expr_priv_current_token(state->tokens);
    if (!token) {
        *result = left;
        return EXPR_SUCCESS;
    }
    
    if (token->type == TOKEN_ADD_ASSIGN && (state->options & EXPR_ENABLE_COMPOUND_ASSIGN)) {
        op_type = EXPR_NODE_ADD_ASSIGN;
    } else if (token->type == TOKEN_SUB_ASSIGN && (state->options & EXPR_ENABLE_COMPOUND_ASSIGN)) {
        op_type = EXPR_NODE_SUB_ASSIGN;
    } else if (token->type == TOKEN_MUL_ASSIGN && (state->options & EXPR_ENABLE_COMPOUND_ASSIGN)) {
        op_type = EXPR_NODE_MUL_ASSIGN;
    } else if (token->type == TOKEN_DIV_ASSIGN && (state->options & EXPR_ENABLE_COMPOUND_ASSIGN)) {
        op_type = EXPR_NODE_DIV_ASSIGN;
    } else if (token->type == TOKEN_POW_ASSIGN && (state->options & EXPR_ENABLE_COMPOUND_ASSIGN) && 
               (state->options & EXPR_ENABLE_POWER)) {
        op_type = EXPR_NODE_POW_ASSIGN;
    } else if (token->type == TOKEN_MOD_ASSIGN && (state->options & EXPR_ENABLE_COMPOUND_ASSIGN) && 
               (state->options & EXPR_ENABLE_MODULO)) {
        op_type = EXPR_NODE_MOD_ASSIGN;
    } else if (token->type == TOKEN_ASSIGN) {
        op_type = EXPR_NODE_ASSIGN;
    } else {
        *result = left;
        return EXPR_SUCCESS;
    }
    
    /* Validate assignment target during compilation */
    ret = expr_priv_validate_assignment_target(left, op_type != EXPR_NODE_ASSIGN, 
                                              state->ctx, token->start);
    if (ret != EXPR_SUCCESS) {
        expr_priv_node_free(left);
        return ret;
    }
    
    expr_priv_advance_token(state->tokens);
    ret = expr_priv_parse_assignment(state, &right);
    if (ret != EXPR_SUCCESS) {
        expr_priv_node_free(left);
        return ret;
    }
    
    node = expr_priv_node_new(op_type);
    if (!node) {
        expr_priv_node_free(left);
        expr_priv_node_free(right);
        return EXPR_ERROR_MEMORY;
    }
    
    node->data.binary.left = left;
    node->data.binary.right = right;
    *result = node;
    return EXPR_SUCCESS;
}

/*
 * expr_priv_parse_sequence
 *
 * Parses sequence expressions (semicolon-separated).
 *
 * Input: state - parser state
 *        result - pointer to store parsed node
 * Output: EXPR_SUCCESS on success, error code on failure
 * Side effects: Updates parser position, creates AST nodes
 *
 * Dependencies: Assignment expression parsing
 *
 * Handles semicolon operator for expression sequences.
 */
int
expr_priv_parse_sequence(expr_parser_state_t *state, expr_node_t **result)
{
    expr_node_t *left, *right, *node;
    expr_token_t *token;
    int ret;
    
    /* Skip leading semicolons */
    token = expr_priv_current_token(state->tokens);
    while (token && token->type == TOKEN_SEMICOLON && (state->options & EXPR_ALLOW_SEMICOLON)) {
        expr_priv_advance_token(state->tokens);
        token = expr_priv_current_token(state->tokens);
    }
    
    /* Check if we have an empty expression (only semicolons) */
    if (!token || token->type == TOKEN_EOF) {
        left = expr_priv_node_new(EXPR_NODE_NUMBER);
        if (!left)
            return EXPR_ERROR_MEMORY;
        left->data.number = NAN;
        *result = left;
        return EXPR_SUCCESS;
    }
    
    /* Parse the first non-empty assignment */
    ret = expr_priv_parse_assignment(state, &left);
    if (ret != EXPR_SUCCESS)
        return ret;
    
    /* Look for more sequences */
    while (1) {
        token = expr_priv_current_token(state->tokens);
        if (!token || token->type != TOKEN_SEMICOLON || !(state->options & EXPR_ALLOW_SEMICOLON))
            break;
        
        /* Skip semicolons */
        while (token && token->type == TOKEN_SEMICOLON && (state->options & EXPR_ALLOW_SEMICOLON)) {
            expr_priv_advance_token(state->tokens);
            token = expr_priv_current_token(state->tokens);
        }
        
        /* Check if we've reached the end (trailing semicolons) */
        if (!token || token->type == TOKEN_EOF)
            break;
        
        /* Parse the next assignment */
        ret = expr_priv_parse_assignment(state, &right);
        if (ret != EXPR_SUCCESS) {
            expr_priv_node_free(left);
            return ret;
        }
        
        /* Create sequence node */
        node = expr_priv_node_new(EXPR_NODE_SEQUENCE);
        if (!node) {
            expr_priv_node_free(left);
            expr_priv_node_free(right);
            return EXPR_ERROR_MEMORY;
        }
        
        node->data.binary.left = left;
        node->data.binary.right = right;
        left = node;
    }
    
    *result = left;
    return EXPR_SUCCESS;
}

/*
 * expr_priv_parse_expression
 *
 * Parses a complete expression using recursive descent.
 *
 * Input: state - parser state
 *        result - pointer to store parsed AST
 * Output: EXPR_SUCCESS on success, error code on failure
 * Side effects: Updates parser position, creates AST
 *
 * Dependencies: All precedence level parsers
 *
 * Top-level parsing function that starts precedence chain.
 */
int
expr_priv_parse_expression(expr_parser_state_t *state, expr_node_t **result)
{
    return expr_priv_parse_sequence(state, result);
}

/*
 * expr_compile
 *
 * Compiles an expression string into an AST handle.
 *
 * Input: ctx - context with symbol table
 *        expression - expression string to compile
 *        options - compilation options
 *        handle - pointer to store compiled handle
 * Output: EXPR_SUCCESS on success, error code on failure
 * Side effects: Allocates handle and AST memory
 *
 * Dependencies: Parser, handle creation
 *
 * Public API function for expression compilation.
 */
int
expr_compile(expr_context ctx, const char *expression, unsigned options, expr_handle *handle)
{
    expr_parser_state_t state;
    expr_handle_struct_t *new_handle;
    expr_token_stream_t *tokens;
    int ret;
    
    if (!ctx || !expression || !handle)
        return EXPR_ERROR_INVALID_PARAM;
    
    if (strlen(expression) == 0) {
        expr_priv_set_error(ctx, "Empty expression", expression);
        return EXPR_ERROR_EMPTY_EXPR;
    }
    
    /* Tokenize the expression */
    ret = expr_priv_tokenize(expression, ctx, options, &tokens);
    if (ret != EXPR_SUCCESS)
        return ret;
    
    new_handle = (expr_handle_struct_t*)malloc(sizeof(expr_handle_struct_t));
    if (!new_handle) {
        expr_priv_free_token_stream(tokens);
        return EXPR_ERROR_MEMORY;
    }
    
    new_handle->original_expression = (char*)malloc(strlen(expression) + 1);
    if (!new_handle->original_expression) {
        expr_priv_free_token_stream(tokens);
        free(new_handle);
        return EXPR_ERROR_MEMORY;
    }
    strcpy(new_handle->original_expression, expression);
    
    new_handle->ctx = ctx;
    new_handle->root = NULL;
    
    state.input = expression;
    state.current = expression;
    state.ctx = ctx;
    state.options = options;
    state.tokens = tokens;
    
    ctx->parse_position = expression;
    
    ret = expr_priv_parse_expression(&state, &new_handle->root);
    if (ret != EXPR_SUCCESS) {
        expr_priv_free_token_stream(tokens);
        free(new_handle->original_expression);
        free(new_handle);
        return ret;
    }
    
    /* Check for unexpected tokens at end */
    expr_token_t *current = expr_priv_current_token(tokens);
    if (current && current->type != TOKEN_EOF) {
        expr_priv_set_error(ctx, "Unexpected characters at end of expression", current->start);
        expr_priv_node_free(new_handle->root);
        expr_priv_free_token_stream(tokens);
        free(new_handle->original_expression);
        free(new_handle);
        return EXPR_ERROR_PARSE;
    }
    
    expr_priv_free_token_stream(tokens);
    *handle = new_handle;
    return EXPR_SUCCESS;
}