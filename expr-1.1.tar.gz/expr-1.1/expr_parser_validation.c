/*
 * expr_parser_validation.c
 *
 * Copyright (C) 2025 by Robert Cousins
 * All Rights Reserved
 *
 * Validation functions for mathematical expression parser.
 * Handles identifier validation, assignment target validation,
 * and number parsing utilities.
 *
 * $Id: expr_parser_validation.c,v 1.2 2025/06/25 16:05:47 rec Exp rec $
 *
 * Author: Robert Cousins
 *
 * 2025-06-25: Split from expr_parser.c for better modularity
 */

#include "expr_private.h"

/*
 * expr_priv_is_valid_identifier_start
 *
 * Checks if character can start an identifier, supporting UTF-8.
 *
 * Input: c - character to check (unsigned char for UTF-8 compatibility)
 * Output: Non-zero if valid start character
 * Side effects: None
 *
 * Dependencies: Standard library character classification
 *
 * Identifiers start with ASCII letter, underscore, or UTF-8 high-bit chars (>= 0x80).
 * UTF-8 support allows international identifiers while maintaining ASCII compatibility.
 */
int
expr_priv_is_valid_identifier_start(int c)
{
    unsigned char uc = (unsigned char)c;
    
    /* ASCII letters and underscore */
    if ((uc >= 'A' && uc <= 'Z') || (uc >= 'a' && uc <= 'z') || uc == '_')
        return 1;
    
    /* UTF-8 continuation bytes and high-bit characters */
    if (uc >= 0x80)
        return 1;
    
    return 0;
}

/*
 * expr_priv_is_valid_identifier_char
 *
 * Checks if character can appear in an identifier, supporting UTF-8.
 *
 * Input: c - character to check (unsigned char for UTF-8 compatibility)
 * Output: Non-zero if valid identifier character
 * Side effects: None
 *
 * Dependencies: Standard library character classification
 *
 * Identifier characters include start characters plus ASCII digits.
 * UTF-8 support maintains compatibility with international character sets.
 */
int
expr_priv_is_valid_identifier_char(int c)
{
    unsigned char uc = (unsigned char)c;
    
    /* All identifier start characters are valid */
    if (expr_priv_is_valid_identifier_start(c))
        return 1;
    
    /* ASCII digits */
    if (uc >= '0' && uc <= '9')
        return 1;
    
    /* Period for namespaced identifiers (e.g., μ.coefficient) */
    if (uc == '.')
        return 1;
    
    return 0;
}

/*
 * expr_priv_parse_hex_number
 *
 * Parses hexadecimal number with 0x prefix and returns as double.
 *
 * Input: str - string starting with "0x" or "0X"
 *        endptr - pointer to store end of parsed string
 * Output: Parsed number as double
 * Side effects: Updates endptr to point after parsed digits
 *
 * Dependencies: Standard library character classification
 *
 * Supports both uppercase and lowercase hex digits. Handles empty hex
 * strings by returning 0 and setting endptr to start of digits.
 */
double
expr_priv_parse_hex_number(const char *str, char **endptr)
{
    const char *ptr = str + 2; /* Skip "0x" or "0X" */
    double result = 0.0;
    int digit;
    
    /* Parse hex digits */
    while (*ptr) {
        if (*ptr >= '0' && *ptr <= '9') {
            digit = *ptr - '0';
        } else if (*ptr >= 'A' && *ptr <= 'F') {
            digit = *ptr - 'A' + 10;
        } else if (*ptr >= 'a' && *ptr <= 'f') {
            digit = *ptr - 'a' + 10;
        } else {
            break;
        }
        result = result * 16.0 + digit;
        ptr++;
    }
    
    if (endptr)
        *endptr = (char*)ptr;
    
    return result;
}

/*
 * expr_priv_validate_assignment_target
 *
 * Validates assignment targets during compilation phase instead of evaluation.
 * Simple assignments require writable variables. Compound assignments require
 * readable+writable variables. Constants and literals are rejected.
 */
int
expr_priv_validate_assignment_target(expr_node_t *node, int is_compound, 
                                     expr_context ctx, const char *position)
{
    expr_symbol_t *symbol;
    
    if (!node)
        return EXPR_ERROR_INVALID_PARAM;
    
    /* Only variables can be assigned to */
    if (node->type != EXPR_NODE_VARIABLE) {
        expr_priv_set_error(ctx, "Invalid assignment target", position);
        return EXPR_ERROR_INVALID_ASSIGNMENT;
    }
    
    symbol = (expr_symbol_t*)node->data.symbol.symbol_ptr;
    if (!symbol) {
        expr_priv_set_error(ctx, "Invalid assignment target", position);
        return EXPR_ERROR_INVALID_ASSIGNMENT;
    }
    
    /* Constants cannot be assigned to */
    if (symbol->type == EXPR_SYMBOL_CONSTANT) {
        expr_priv_set_error(ctx, "Cannot assign to constant", position);
        return EXPR_ERROR_INVALID_ASSIGNMENT;
    }
    
    /* Variables must be writable */
    if (!(symbol->options & EXPR_VAR_WRITABLE)) {
        expr_priv_set_error(ctx, "Variable is not writable", position);
        return EXPR_ERROR_INVALID_ASSIGNMENT;
    }
    
    /* Compound assignments also require readable access */
    if (is_compound && !(symbol->options & EXPR_VAR_READABLE)) {
        expr_priv_set_error(ctx, "Variable is not readable for compound assignment", position);
        return EXPR_ERROR_INVALID_ASSIGNMENT;
    }
    
    return EXPR_SUCCESS;
}