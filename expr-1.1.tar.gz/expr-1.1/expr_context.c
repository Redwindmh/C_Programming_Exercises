/*
 * expr_context.c
 *
 * Copyright (C) 2025 by Robert Cousins
 * All Rights Reserved
 *
 * Context management for mathematical expression evaluation library.
 * Handles creation, destruction, and management of expression contexts
 * including symbol table operations and error state management.
 *
 * $Id: expr_context.c,v 1.1 2025/06/25 16:02:06 rec Exp rec $
 *
 * Author: Robert Cousins
 *
 * 2025-06-22: Initial implementation
 */

#include "expr_private.h"

/*
 * expr_context_new
 *
 * Creates a new expression context with empty symbol table.
 *
 * Input: ctx - pointer to store new context
 * Output: EXPR_SUCCESS on success, error code on failure
 * Side effects: Allocates memory for context structure
 *
 * Dependencies: Standard library malloc
 *
 * Initializes all context fields to safe defaults.
 */
int
expr_context_new(expr_context *ctx)
{
    expr_context_struct_t *new_ctx;
    
    if (!ctx)
        return EXPR_ERROR_INVALID_PARAM;
    
    new_ctx = (expr_context_struct_t*)malloc(sizeof(expr_context_struct_t));
    if (!new_ctx)
        return EXPR_ERROR_MEMORY;
    
    new_ctx->symbol_table = NULL;
    new_ctx->error_message = NULL;
    new_ctx->error_position = -1;
    new_ctx->parse_position = NULL;
    
    *ctx = new_ctx;
    return EXPR_SUCCESS;
}

/*
 * expr_context_free
 *
 * Frees an expression context and all associated memory.
 *
 * Input: ctx - context to free
 * Output: EXPR_SUCCESS on success, error code on failure
 * Side effects: Frees all memory associated with context
 *
 * Dependencies: Standard library free, symbol table cleanup
 *
 * Ensures all allocated memory is properly released.
 */
int
expr_context_free(expr_context ctx)
{
    if (!ctx)
        return EXPR_ERROR_INVALID_PARAM;
    
    expr_priv_symbol_table_free(ctx->symbol_table);
    
    if (ctx->error_message)
        free(ctx->error_message);
    
    free(ctx);
    return EXPR_SUCCESS;
}

/*
 * expr_error
 *
 * Returns the most recent error message for a context.
 *
 * Input: ctx - context to query
 * Output: Error message string or NULL if no error
 * Side effects: None
 *
 * Dependencies: None
 *
 * Returns pointer to internal error message string.
 */
const char*
expr_error(expr_context ctx)
{
    if (!ctx)
        return "Invalid context";
    
    return ctx->error_message ? ctx->error_message : "No error";
}

/*
 * expr_error_position
 *
 * Returns the character position where the most recent error occurred.
 *
 * Input: ctx - context to query
 * Output: Character position or -1 if no position available
 * Side effects: None
 *
 * Dependencies: None
 *
 * Position is relative to start of expression string.
 */
int
expr_error_position(expr_context ctx)
{
    if (!ctx)
        return -1;
    
    return ctx->error_position;
}

/*
 * expr_priv_set_error
 *
 * Sets error message and position for a context.
 *
 * Input: ctx - context to update
 *        message - error message string
 *        position - position in input where error occurred
 * Output: None
 * Side effects: Allocates memory for error message copy
 *
 * Dependencies: Standard library malloc, strdup
 *
 * Makes copy of error message for safe storage.
 */
void
expr_priv_set_error(expr_context ctx, const char *message, const char *position)
{
    if (!ctx || !message)
        return;
    
    if (ctx->error_message) {
        free(ctx->error_message);
        ctx->error_message = NULL;
    }
    
    ctx->error_message = (char*)malloc(strlen(message) + 1);
    if (ctx->error_message)
        strcpy(ctx->error_message, message);
    
    if (position && ctx->parse_position)
        ctx->error_position = (int)(position - ctx->parse_position);
    else
        ctx->error_position = -1;
}