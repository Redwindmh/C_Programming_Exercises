/*
 * expr_symbol_table.c
 *
 * Copyright (C) 2025 by Robert Cousins
 * All Rights Reserved
 *
 * Core symbol table management for mathematical expression evaluation library.
 * Handles constants, variables, and functions with linked list implementation.
 * Provides individual symbol addition and lookup operations.
 *
 * $Id: expr_symbol_table.c,v 1.1 2025/06/25 16:02:06 rec Exp rec $
 *
 * Author: Robert Cousins
 *
 * 2025-06-25: Split from expr_symbols.c for better modularity
 */

#include "expr_private.h"

/*
 * expr_priv_symbol_find
 *
 * Searches for a symbol by name in the context's symbol table.
 *
 * Input: ctx - context to search
 *        name - symbol name to find
 * Output: Symbol pointer or NULL if not found
 * Side effects: None
 *
 * Dependencies: String comparison
 *
 * Performs linear search through linked list symbol table.
 */
expr_symbol_t*
expr_priv_symbol_find(expr_context ctx, const char *name)
{
    expr_symbol_t *sym;
    
    if (!ctx || !name)
        return NULL;
    
    for (sym = ctx->symbol_table; sym; sym = sym->next) {
        if (strcmp(sym->name, name) == 0)
            return sym;
    }
    
    return NULL;
}

/*
 * expr_priv_symbol_add
 *
 * Adds a new symbol to the context's symbol table.
 *
 * Input: ctx - context to modify
 *        name - symbol name
 *        type - symbol type
 *        options - symbol options
 *        data - pointer to symbol data
 * Output: EXPR_SUCCESS on success, error code on failure
 * Side effects: Allocates memory for new symbol entry
 *
 * Dependencies: Memory allocation, string duplication
 *
 * Creates new symbol entry and adds to front of linked list.
 */
int
expr_priv_symbol_add(expr_context ctx, const char *name, expr_symbol_type_t type, 
                    unsigned options, void *data)
{
    expr_symbol_t *sym;
    
    if (!ctx || !name)
        return EXPR_ERROR_INVALID_PARAM;
    
    if (expr_priv_symbol_find(ctx, name))
        return EXPR_ERROR_SYMBOL_EXISTS;
    
    sym = (expr_symbol_t*)malloc(sizeof(expr_symbol_t));
    if (!sym)
        return EXPR_ERROR_MEMORY;
    
    sym->name = (char*)malloc(strlen(name) + 1);
    if (!sym->name) {
        free(sym);
        return EXPR_ERROR_MEMORY;
    }
    strcpy(sym->name, name);
    
    sym->type = type;
    sym->options = options;
    
    switch (type) {
        case EXPR_SYMBOL_CONSTANT:
            sym->data.constant_value = *(double*)data;
            break;
        case EXPR_SYMBOL_VARIABLE:
            sym->data.variable_ptr = (double*)data;
            break;
        case EXPR_SYMBOL_FUNCTION0:
            sym->data.func0 = (double(*)(void))data;
            break;
        case EXPR_SYMBOL_FUNCTION1:
            sym->data.func1 = (double(*)(double))data;
            break;
        case EXPR_SYMBOL_FUNCTION2:
            sym->data.func2 = (double(*)(double, double))data;
            break;
        case EXPR_SYMBOL_FUNCTION3:
            sym->data.func3 = (double(*)(double, double, double))data;
            break;
        case EXPR_SYMBOL_FUNCTION4:
            sym->data.func4 = (double(*)(double, double, double, double))data;
            break;
    }
    
    sym->next = ctx->symbol_table;
    ctx->symbol_table = sym;
    
    return EXPR_SUCCESS;
}

/*
 * expr_priv_symbol_table_free
 *
 * Frees entire symbol table linked list.
 *
 * Input: table - head of symbol table linked list
 * Output: None
 * Side effects: Frees all symbol table memory
 *
 * Dependencies: Standard library free
 *
 * Recursively frees all nodes in symbol table.
 */
void
expr_priv_symbol_table_free(expr_symbol_t *table)
{
    expr_symbol_t *next;
    
    while (table) {
        next = table->next;
        free(table->name);
        free(table);
        table = next;
    }
}

/*
 * expr_add_constant
 *
 * Adds a constant to the context's symbol table.
 *
 * Input: ctx - context to modify
 *        name - constant name
 *        value - constant value
 *        options - constant options (currently unused)
 * Output: EXPR_SUCCESS on success, error code on failure
 * Side effects: Modifies symbol table
 *
 * Dependencies: Symbol addition utilities
 *
 * Public API function for adding named constants.
 */
int
expr_add_constant(expr_context ctx, const char *name, double value, unsigned options)
{
    return expr_priv_symbol_add(ctx, name, EXPR_SYMBOL_CONSTANT, options, &value);
}

/*
 * expr_add_variable
 *
 * Adds a variable to the context's symbol table.
 *
 * Input: ctx - context to modify
 *        name - variable name
 *        location - pointer to variable storage
 *        options - variable access options
 * Output: EXPR_SUCCESS on success, error code on failure
 * Side effects: Modifies symbol table
 *
 * Dependencies: Symbol addition utilities
 *
 * Public API function for adding variables with read/write permissions.
 */
int
expr_add_variable(expr_context ctx, const char *name, double *location, unsigned options)
{
    if (!location)
        return EXPR_ERROR_INVALID_PARAM;
    
    if (!(options & (EXPR_VAR_READABLE | EXPR_VAR_WRITABLE)))
        return EXPR_ERROR_INVALID_PARAM;
    
    return expr_priv_symbol_add(ctx, name, EXPR_SYMBOL_VARIABLE, options, location);
}

/*
 * expr_add_function0
 *
 * Adds a zero-argument function to the context's symbol table.
 *
 * Input: ctx - context to modify
 *        name - function name
 *        func - function pointer
 *        options - function options
 * Output: EXPR_SUCCESS on success, error code on failure
 * Side effects: Modifies symbol table
 *
 * Dependencies: Symbol addition utilities
 *
 * Public API function for adding parameterless functions.
 */
int
expr_add_function0(expr_context ctx, const char *name, double (*func)(void), unsigned options)
{
    if (!func)
        return EXPR_ERROR_INVALID_PARAM;
    
    return expr_priv_symbol_add(ctx, name, EXPR_SYMBOL_FUNCTION0, options, (void*)func);
}

/*
 * expr_add_function1
 *
 * Adds a single-argument function to the context's symbol table.
 *
 * Input: ctx - context to modify
 *        name - function name
 *        func - function pointer
 *        options - function options
 * Output: EXPR_SUCCESS on success, error code on failure
 * Side effects: Modifies symbol table
 *
 * Dependencies: Symbol addition utilities
 *
 * Public API function for adding single-parameter functions.
 */
int
expr_add_function1(expr_context ctx, const char *name, double (*func)(double), unsigned options)
{
    if (!func)
        return EXPR_ERROR_INVALID_PARAM;
    
    return expr_priv_symbol_add(ctx, name, EXPR_SYMBOL_FUNCTION1, options, (void*)func);
}

/*
 * expr_add_function2
 *
 * Adds a two-argument function to the context's symbol table.
 *
 * Input: ctx - context to modify
 *        name - function name
 *        func - function pointer
 *        options - function options
 * Output: EXPR_SUCCESS on success, error code on failure
 * Side effects: Modifies symbol table
 *
 * Dependencies: Symbol addition utilities
 *
 * Public API function for adding two-parameter functions.
 */
int
expr_add_function2(expr_context ctx, const char *name, double (*func)(double, double), unsigned options)
{
    if (!func)
        return EXPR_ERROR_INVALID_PARAM;
    
    return expr_priv_symbol_add(ctx, name, EXPR_SYMBOL_FUNCTION2, options, (void*)func);
}

/*
 * expr_add_function3
 *
 * Adds a three-argument function to the context's symbol table.
 *
 * Input: ctx - context to modify
 *        name - function name
 *        func - function pointer
 *        options - function options
 * Output: EXPR_SUCCESS on success, error code on failure
 * Side effects: Modifies symbol table
 *
 * Dependencies: Symbol addition utilities
 *
 * Public API function for adding three-parameter functions.
 */
int
expr_add_function3(expr_context ctx, const char *name, double (*func)(double, double, double), unsigned options)
{
    if (!func)
        return EXPR_ERROR_INVALID_PARAM;
    
    return expr_priv_symbol_add(ctx, name, EXPR_SYMBOL_FUNCTION3, options, (void*)func);
}

/*
 * expr_add_function4
 *
 * Adds a four-argument function to the context's symbol table.
 *
 * Input: ctx - context to modify
 *        name - function name
 *        func - function pointer
 *        options - function options
 * Output: EXPR_SUCCESS on success, error code on failure
 * Side effects: Modifies symbol table
 *
 * Dependencies: Symbol addition utilities
 *
 * Public API function for adding four-parameter functions.
 */
int
expr_add_function4(expr_context ctx, const char *name, double (*func)(double, double, double, double), unsigned options)
{
    if (!func)
        return EXPR_ERROR_INVALID_PARAM;
    
    return expr_priv_symbol_add(ctx, name, EXPR_SYMBOL_FUNCTION4, options, (void*)func);
}