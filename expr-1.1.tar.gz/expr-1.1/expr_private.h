/*
 * expr_private.h
 *
 * Copyright (C) 2025 by Robert Cousins
 * All Rights Reserved
 *
 * Internal data structures and private function declarations for
 * the mathematical expression evaluation library. Contains AST
 * node definitions, symbol table structures, and internal APIs.
 *
 * $Id: expr_private.h,v 1.1 2025/06/25 16:02:06 rec Exp rec $
 *
 * Author: Robert Cousins
 *
 * 2025-06-22: Initial implementation
 */

#ifndef EXPR_PRIVATE_H
#define EXPR_PRIVATE_H

#include "expr.h"
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>

/* AST Node types */
typedef enum {
    EXPR_NODE_NUMBER,
    EXPR_NODE_VARIABLE,
    EXPR_NODE_CONSTANT,
    EXPR_NODE_FUNCTION0,
    EXPR_NODE_FUNCTION1,
    EXPR_NODE_FUNCTION2,
    EXPR_NODE_FUNCTION3,
    EXPR_NODE_FUNCTION4,
    EXPR_NODE_UNARY_PLUS,
    EXPR_NODE_UNARY_MINUS,
    EXPR_NODE_ADD,
    EXPR_NODE_SUBTRACT,
    EXPR_NODE_MULTIPLY,
    EXPR_NODE_DIVIDE,
    EXPR_NODE_POWER,
    EXPR_NODE_MODULO,
    EXPR_NODE_ASSIGN,
    EXPR_NODE_ADD_ASSIGN,
    EXPR_NODE_SUB_ASSIGN,
    EXPR_NODE_MUL_ASSIGN,
    EXPR_NODE_DIV_ASSIGN,
    EXPR_NODE_POW_ASSIGN,
    EXPR_NODE_MOD_ASSIGN,
    EXPR_NODE_SEQUENCE
} expr_node_type_t;

/* AST Node structure */
typedef struct expr_node {
    expr_node_type_t type;
    double cached_value;
    int has_cached_value;
    union {
        double number;
        struct {
            char *name;
            void *symbol_ptr;
        } symbol;
        struct {
            struct expr_node *left;
            struct expr_node *right;
        } binary;
        struct {
            struct expr_node *operand;
        } unary;
        struct {
            struct expr_node **args;
            int arg_count;
            void *symbol_ptr;
        } function;
    } data;
} expr_node_t;

/* Symbol types */
typedef enum {
    EXPR_SYMBOL_CONSTANT,
    EXPR_SYMBOL_VARIABLE,
    EXPR_SYMBOL_FUNCTION0,
    EXPR_SYMBOL_FUNCTION1,
    EXPR_SYMBOL_FUNCTION2,
    EXPR_SYMBOL_FUNCTION3,
    EXPR_SYMBOL_FUNCTION4
} expr_symbol_type_t;

/* Symbol table entry */
typedef struct expr_symbol {
    char *name;
    expr_symbol_type_t type;
    unsigned options;
    union {
        double constant_value;
        double *variable_ptr;
        double (*func0)(void);
        double (*func1)(double);
        double (*func2)(double, double);
        double (*func3)(double, double, double);
        double (*func4)(double, double, double, double);
    } data;
    struct expr_symbol *next;
} expr_symbol_t;

/* Context structure */
typedef struct expr_context_struct {
    expr_symbol_t *symbol_table;
    char *error_message;
    int error_position;
    const char *parse_position;
} expr_context_struct_t;

/* Handle structure */
typedef struct expr_handle_struct {
    expr_node_t *root;
    expr_context ctx;
    char *original_expression;
} expr_handle_struct_t;

/* Token types for two-pass parser */
typedef enum {
    TOKEN_EOF,
    TOKEN_NUMBER,
    TOKEN_IDENTIFIER,
    TOKEN_PLUS,
    TOKEN_MINUS,
    TOKEN_MULTIPLY,
    TOKEN_DIVIDE,
    TOKEN_POWER,
    TOKEN_MODULO,
    TOKEN_ASSIGN,
    TOKEN_ADD_ASSIGN,
    TOKEN_SUB_ASSIGN,
    TOKEN_MUL_ASSIGN,
    TOKEN_DIV_ASSIGN,
    TOKEN_POW_ASSIGN,
    TOKEN_MOD_ASSIGN,
    TOKEN_LPAREN,
    TOKEN_RPAREN,
    TOKEN_COMMA,
    TOKEN_SEMICOLON,
    TOKEN_UNARY_PLUS,
    TOKEN_UNARY_MINUS
} expr_token_type_t;

/* Token structure */
typedef struct expr_token {
    expr_token_type_t type;
    const char *start;
    int length;
    double number_value;        /* For TOKEN_NUMBER */
    char *string_value;         /* For TOKEN_IDENTIFIER (allocated) */
} expr_token_t;

/* Token stream */
typedef struct expr_token_stream {
    expr_token_t *tokens;
    int count;
    int capacity;
    int position;
} expr_token_stream_t;

/* Parser state */
typedef struct expr_parser_state {
    const char *input;
    const char *current;
    expr_context ctx;
    unsigned options;
    expr_token_stream_t *tokens;    /* New: token stream */
} expr_parser_state_t;

/* Private function declarations */

/* AST functions */
expr_node_t* expr_priv_node_new(expr_node_type_t type);
void expr_priv_node_free(expr_node_t *node);
expr_node_t* expr_priv_node_copy(const expr_node_t *node);
int expr_priv_node_count(const expr_node_t *node);
char* expr_priv_node_to_string(const expr_node_t *node);

/* Symbol table functions */
expr_symbol_t* expr_priv_symbol_find(expr_context ctx, const char *name);
int expr_priv_symbol_add(expr_context ctx, const char *name, expr_symbol_type_t type, 
                        unsigned options, void *data);
void expr_priv_symbol_table_free(expr_symbol_t *table);

/* Tokenizer functions */
int expr_priv_tokenize(const char *input, expr_context ctx, unsigned options, expr_token_stream_t **stream);
void expr_priv_free_token_stream(expr_token_stream_t *stream);
expr_token_t* expr_priv_current_token(expr_token_stream_t *stream);
expr_token_t* expr_priv_peek_token(expr_token_stream_t *stream, int offset);
void expr_priv_advance_token(expr_token_stream_t *stream);
int expr_priv_expect_token(expr_token_stream_t *stream, expr_token_type_t expected);

/* Parser functions */
int expr_priv_parse_expression(expr_parser_state_t *state, expr_node_t **result);
int expr_priv_parse_sequence(expr_parser_state_t *state, expr_node_t **result);
int expr_priv_parse_assignment(expr_parser_state_t *state, expr_node_t **result);
int expr_priv_parse_addition(expr_parser_state_t *state, expr_node_t **result);
int expr_priv_parse_multiplication(expr_parser_state_t *state, expr_node_t **result);
int expr_priv_parse_power(expr_parser_state_t *state, expr_node_t **result);
int expr_priv_parse_unary(expr_parser_state_t *state, expr_node_t **result);
int expr_priv_parse_primary(expr_parser_state_t *state, expr_node_t **result);
int expr_priv_parse_number(expr_parser_state_t *state, double *result);
int expr_priv_parse_identifier(expr_parser_state_t *state, char **result);
void expr_priv_skip_whitespace(expr_parser_state_t *state);
int expr_priv_is_compound_assignment(expr_parser_state_t *state, char op);

/* Parser validation functions */
int expr_priv_validate_assignment_target(expr_node_t *node, int is_compound, 
                                         expr_context ctx, const char *position);
int expr_priv_is_valid_identifier_start(int c);
int expr_priv_is_valid_identifier_char(int c);
double expr_priv_parse_hex_number(const char *str, char **endptr);

/* Evaluator functions */
int expr_priv_evaluate_node(expr_node_t *node, double *result);

/* Optimizer functions */
int expr_priv_optimize_constant_fold(expr_node_t **node, int *changed);
int expr_priv_optimize_dead_code(expr_node_t **node, int *changed);
int expr_priv_optimize_common_subexpr(expr_node_t **node, int *changed);
int expr_priv_optimize_pure_functions(expr_node_t **node, int *changed);
int expr_priv_optimize_algebraic(expr_node_t **node, int *changed);
int expr_priv_optimize_strength(expr_node_t **node, int *changed);

/* Error handling */
void expr_priv_set_error(expr_context ctx, const char *message, const char *position);

/* Utility functions */

#endif /* EXPR_PRIVATE_H */