/*
 * expr.h
 *
 * Copyright (C) 2025 by Robert Cousins
 * All Rights Reserved
 *
 * Public API for mathematical expression evaluation library.
 * Provides context-based parsing, compilation, and evaluation of
 * mathematical expressions with optimization support.
 *
 * $Id: expr.h,v 1.1 2025/06/25 16:02:06 rec Exp rec $
 *
 * Author: Robert Cousins
 *
 * 2025-06-22: Initial implementation
 */

#ifndef EXPR_H
#define EXPR_H

#include <stdio.h>

/* Forward declarations */
typedef struct expr_context_struct* expr_context;
typedef struct expr_handle_struct* expr_handle;

/* Error codes */
#define EXPR_SUCCESS                0
#define EXPR_ERROR_MEMORY          -1
#define EXPR_ERROR_INVALID_PARAM   -2
#define EXPR_ERROR_PARSE           -3
#define EXPR_ERROR_UNDEFINED_SYMBOL -4
#define EXPR_ERROR_DIVISION_BY_ZERO -5
#define EXPR_ERROR_INVALID_FUNCTION -6
#define EXPR_ERROR_INVALID_VARIABLE -7
#define EXPR_ERROR_SYNTAX          -8
#define EXPR_ERROR_EMPTY_EXPR      -9
#define EXPR_ERROR_SYMBOL_EXISTS   -10
#define EXPR_ERROR_INVALID_ASSIGNMENT -11

/* Compilation options */
#define EXPR_ALLOW_SEMICOLON       0x01
#define EXPR_SIMPLE_OPERATORS      0x02
#define EXPR_ENABLE_POWER          0x04
#define EXPR_ENABLE_MODULO         0x08
#define EXPR_ENABLE_COMPOUND_ASSIGN 0x10

/* Variable options */
#define EXPR_VAR_READABLE          0x01
#define EXPR_VAR_WRITABLE          0x02
#define EXPR_VAR_READ_WRITE        (EXPR_VAR_READABLE | EXPR_VAR_WRITABLE)

/* Function options */
#define EXPR_FUNC_PURE             0x01

/* Optimization flags */
#define EXPR_OPT_CONSTANT_FOLD     0x01
#define EXPR_OPT_DEAD_CODE         0x02
#define EXPR_OPT_COMMON_SUBEXPR    0x04
#define EXPR_OPT_PURE_FUNCTIONS    0x08
#define EXPR_OPT_ALGEBRAIC         0x10
#define EXPR_OPT_STRENGTH          0x20

/* Optimization report structure */
typedef struct optimization_report {
    int total_passes;
    int original_nodes;
    int final_nodes;
    int constants_folded;
    int dead_code_eliminated;
    int common_subexpressions;
    int pure_functions_precomputed;
    double optimization_time_ms;
    char *summary;
    char *original_expression;
    char *optimized_expression;
} optimization_report_t;

/* List structures for batch operations */
typedef struct expr_constant_entry {
    char *name;
    double value;
    unsigned options;
} expr_constant_entry_t;

typedef struct expr_variable_entry {
    char *name;
    double *location;
    unsigned options;
} expr_variable_entry_t;

typedef struct expr_function0_entry {
    char *name;
    double (*func)(void);
    unsigned options;
} expr_function0_entry_t;

typedef struct expr_function1_entry {
    char *name;
    double (*func)(double);
    unsigned options;
} expr_function1_entry_t;

typedef struct expr_function2_entry {
    char *name;
    double (*func)(double, double);
    unsigned options;
} expr_function2_entry_t;

typedef struct expr_function3_entry {
    char *name;
    double (*func)(double, double, double);
    unsigned options;
} expr_function3_entry_t;

typedef struct expr_function4_entry {
    char *name;
    double (*func)(double, double, double, double);
    unsigned options;
} expr_function4_entry_t;

#ifdef __cplusplus
extern "C" {
#endif

/* Context management */
int expr_context_new(expr_context *ctx);
int expr_context_free(expr_context ctx);

/* Symbol management */
int expr_add_constant(expr_context ctx, const char *name, double value, unsigned options);
int expr_add_variable(expr_context ctx, const char *name, double *location, unsigned options);
int expr_add_function0(expr_context ctx, const char *name, double (*func)(void), unsigned options);
int expr_add_function1(expr_context ctx, const char *name, double (*func)(double), unsigned options);
int expr_add_function2(expr_context ctx, const char *name, double (*func)(double, double), unsigned options);
int expr_add_function3(expr_context ctx, const char *name, double (*func)(double, double, double), unsigned options);
int expr_add_function4(expr_context ctx, const char *name, double (*func)(double, double, double, double), unsigned options);

/* Batch symbol addition */
int expr_add_constant_list(expr_context ctx, int count, const expr_constant_entry_t *list);
int expr_add_variable_list(expr_context ctx, int count, const expr_variable_entry_t *list);
int expr_add_function0_list(expr_context ctx, int count, const expr_function0_entry_t *list);
int expr_add_function1_list(expr_context ctx, int count, const expr_function1_entry_t *list);
int expr_add_function2_list(expr_context ctx, int count, const expr_function2_entry_t *list);
int expr_add_function3_list(expr_context ctx, int count, const expr_function3_entry_t *list);
int expr_add_function4_list(expr_context ctx, int count, const expr_function4_entry_t *list);

/* Expression compilation and evaluation */
int expr_compile(expr_context ctx, const char *expression, unsigned options, expr_handle *handle);
int expr_evaluate(expr_handle handle, double *result);
int expr_easy(expr_context ctx, const char *expression, double *result);

/* Expression optimization */
int expr_optimize(expr_handle *handle, optimization_report_t *report);

/* Handle management */
int expr_handle_free(expr_handle handle);

/* Error reporting */
const char* expr_error(expr_context ctx);
int expr_error_position(expr_context ctx);

/* Utility functions */
void expr_free_optimization_report(optimization_report_t *report);

#ifdef __cplusplus
}
#endif

#endif /* EXPR_H */