/*
 * expr_optimizer.c
 *
 * Copyright (C) 2025 by Robert Cousins
 * All Rights Reserved
 *
 * Expression optimization system for mathematical expression evaluation library.
 * Implements multiple optimization passes including constant folding, dead code
 * elimination, and common subexpression elimination with detailed reporting.
 *
 * $Id: expr_optimizer.c,v 1.1 2025/06/25 16:02:06 rec Exp rec $
 *
 * Author: Robert Cousins
 *
 * 2025-06-22: Initial implementation with constant folding
 */

#include "expr_private.h"
#include <time.h>

/*
 * expr_priv_optimize_constant_fold
 *
 * Performs constant folding optimization on expression tree.
 *
 * Input: node - pointer to AST node pointer (may be modified)
 *        changed - pointer to flag indicating if changes were made
 * Output: EXPR_SUCCESS on success, error code on failure
 * Side effects: May replace nodes with constant values
 *
 * Dependencies: Expression evaluation functions
 *
 * Evaluates constant expressions at compile time.
 */
int
expr_priv_optimize_constant_fold(expr_node_t **node, int *changed)
{
    expr_node_t *new_node;
    double value;
    int ret, i;
    int all_constant;
    
    if (!node || !*node || !changed)
        return EXPR_ERROR_INVALID_PARAM;
    
    switch ((*node)->type) {
        case EXPR_NODE_NUMBER:
        case EXPR_NODE_VARIABLE:
        case EXPR_NODE_CONSTANT:
            return EXPR_SUCCESS;
            
        case EXPR_NODE_UNARY_PLUS:
        case EXPR_NODE_UNARY_MINUS:
            ret = expr_priv_optimize_constant_fold(&(*node)->data.unary.operand, changed);
            if (ret != EXPR_SUCCESS)
                return ret;
            
            if ((*node)->data.unary.operand->type == EXPR_NODE_NUMBER) {
                value = (*node)->data.unary.operand->data.number;
                if ((*node)->type == EXPR_NODE_UNARY_MINUS)
                    value = -value;
                
                new_node = expr_priv_node_new(EXPR_NODE_NUMBER);
                if (!new_node)
                    return EXPR_ERROR_MEMORY;
                
                new_node->data.number = value;
                expr_priv_node_free(*node);
                *node = new_node;
                *changed = 1;
            }
            return EXPR_SUCCESS;
            
        case EXPR_NODE_ADD:
        case EXPR_NODE_SUBTRACT:
        case EXPR_NODE_MULTIPLY:
        case EXPR_NODE_DIVIDE:
        case EXPR_NODE_POWER:
        case EXPR_NODE_MODULO:
            ret = expr_priv_optimize_constant_fold(&(*node)->data.binary.left, changed);
            if (ret != EXPR_SUCCESS)
                return ret;
            ret = expr_priv_optimize_constant_fold(&(*node)->data.binary.right, changed);
            if (ret != EXPR_SUCCESS)
                return ret;
            
            if ((*node)->data.binary.left->type == EXPR_NODE_NUMBER &&
                (*node)->data.binary.right->type == EXPR_NODE_NUMBER) {
                
                ret = expr_priv_evaluate_node(*node, &value);
                if (ret != EXPR_SUCCESS)
                    return ret;
                
                new_node = expr_priv_node_new(EXPR_NODE_NUMBER);
                if (!new_node)
                    return EXPR_ERROR_MEMORY;
                
                new_node->data.number = value;
                expr_priv_node_free(*node);
                *node = new_node;
                *changed = 1;
            }
            return EXPR_SUCCESS;
            
        case EXPR_NODE_FUNCTION0:
            all_constant = 1;
            break;
            
        case EXPR_NODE_FUNCTION1:
        case EXPR_NODE_FUNCTION2:
        case EXPR_NODE_FUNCTION3:
        case EXPR_NODE_FUNCTION4:
            all_constant = 1;
            for (i = 0; i < (*node)->data.function.arg_count; i++) {
                ret = expr_priv_optimize_constant_fold(&(*node)->data.function.args[i], changed);
                if (ret != EXPR_SUCCESS)
                    return ret;
                if ((*node)->data.function.args[i]->type != EXPR_NODE_NUMBER)
                    all_constant = 0;
            }
            
            if (all_constant) {
                expr_symbol_t *symbol = (expr_symbol_t*)(*node)->data.function.symbol_ptr;
                if (symbol && (symbol->options & EXPR_FUNC_PURE)) {
                    ret = expr_priv_evaluate_node(*node, &value);
                    if (ret != EXPR_SUCCESS)
                        return ret;
                    
                    new_node = expr_priv_node_new(EXPR_NODE_NUMBER);
                    if (!new_node)
                        return EXPR_ERROR_MEMORY;
                    
                    new_node->data.number = value;
                    expr_priv_node_free(*node);
                    *node = new_node;
                    *changed = 1;
                }
            }
            return EXPR_SUCCESS;
            
        case EXPR_NODE_SEQUENCE:
            ret = expr_priv_optimize_constant_fold(&(*node)->data.binary.left, changed);
            if (ret != EXPR_SUCCESS)
                return ret;
            ret = expr_priv_optimize_constant_fold(&(*node)->data.binary.right, changed);
            if (ret != EXPR_SUCCESS)
                return ret;
            return EXPR_SUCCESS;
            
        default:
            return EXPR_SUCCESS;
    }
    
    return EXPR_SUCCESS;
}

/*
 * expr_priv_optimize_dead_code
 *
 * Performs dead code elimination optimization.
 *
 * Input: node - pointer to AST node pointer (may be modified)
 *        changed - pointer to flag indicating if changes were made
 * Output: EXPR_SUCCESS on success, error code on failure
 * Side effects: May simplify or remove redundant operations
 *
 * Dependencies: Node creation and manipulation
 *
 * Removes operations like x*1, x+0, x^1, etc.
 */
int
expr_priv_optimize_dead_code(expr_node_t **node, int *changed)
{
    expr_node_t *replacement;
    double left_val, right_val;
    int ret;
    
    if (!node || !*node || !changed)
        return EXPR_ERROR_INVALID_PARAM;
    
    switch ((*node)->type) {
        case EXPR_NODE_ADD:
            if ((*node)->data.binary.right->type == EXPR_NODE_NUMBER &&
                (*node)->data.binary.right->data.number == 0.0) {
                replacement = (*node)->data.binary.left;
                (*node)->data.binary.left = NULL;
                expr_priv_node_free(*node);
                *node = replacement;
                *changed = 1;
                return EXPR_SUCCESS;
            }
            if ((*node)->data.binary.left->type == EXPR_NODE_NUMBER &&
                (*node)->data.binary.left->data.number == 0.0) {
                replacement = (*node)->data.binary.right;
                (*node)->data.binary.right = NULL;
                expr_priv_node_free(*node);
                *node = replacement;
                *changed = 1;
                return EXPR_SUCCESS;
            }
            break;
            
        case EXPR_NODE_SUBTRACT:
            if ((*node)->data.binary.right->type == EXPR_NODE_NUMBER &&
                (*node)->data.binary.right->data.number == 0.0) {
                replacement = (*node)->data.binary.left;
                (*node)->data.binary.left = NULL;
                expr_priv_node_free(*node);
                *node = replacement;
                *changed = 1;
                return EXPR_SUCCESS;
            }
            break;
            
        case EXPR_NODE_MULTIPLY:
            if ((*node)->data.binary.right->type == EXPR_NODE_NUMBER) {
                right_val = (*node)->data.binary.right->data.number;
                if (right_val == 1.0) {
                    replacement = (*node)->data.binary.left;
                    (*node)->data.binary.left = NULL;
                    expr_priv_node_free(*node);
                    *node = replacement;
                    *changed = 1;
                    return EXPR_SUCCESS;
                } else if (right_val == 0.0) {
                    replacement = expr_priv_node_new(EXPR_NODE_NUMBER);
                    if (!replacement)
                        return EXPR_ERROR_MEMORY;
                    replacement->data.number = 0.0;
                    expr_priv_node_free(*node);
                    *node = replacement;
                    *changed = 1;
                    return EXPR_SUCCESS;
                }
            }
            if ((*node)->data.binary.left->type == EXPR_NODE_NUMBER) {
                left_val = (*node)->data.binary.left->data.number;
                if (left_val == 1.0) {
                    replacement = (*node)->data.binary.right;
                    (*node)->data.binary.right = NULL;
                    expr_priv_node_free(*node);
                    *node = replacement;
                    *changed = 1;
                    return EXPR_SUCCESS;
                } else if (left_val == 0.0) {
                    replacement = expr_priv_node_new(EXPR_NODE_NUMBER);
                    if (!replacement)
                        return EXPR_ERROR_MEMORY;
                    replacement->data.number = 0.0;
                    expr_priv_node_free(*node);
                    *node = replacement;
                    *changed = 1;
                    return EXPR_SUCCESS;
                }
            }
            break;
            
        case EXPR_NODE_DIVIDE:
            if ((*node)->data.binary.right->type == EXPR_NODE_NUMBER &&
                (*node)->data.binary.right->data.number == 1.0) {
                replacement = (*node)->data.binary.left;
                (*node)->data.binary.left = NULL;
                expr_priv_node_free(*node);
                *node = replacement;
                *changed = 1;
                return EXPR_SUCCESS;
            }
            break;
            
        case EXPR_NODE_POWER:
            if ((*node)->data.binary.right->type == EXPR_NODE_NUMBER) {
                right_val = (*node)->data.binary.right->data.number;
                if (right_val == 1.0) {
                    replacement = (*node)->data.binary.left;
                    (*node)->data.binary.left = NULL;
                    expr_priv_node_free(*node);
                    *node = replacement;
                    *changed = 1;
                    return EXPR_SUCCESS;
                } else if (right_val == 0.0) {
                    replacement = expr_priv_node_new(EXPR_NODE_NUMBER);
                    if (!replacement)
                        return EXPR_ERROR_MEMORY;
                    replacement->data.number = 1.0;
                    expr_priv_node_free(*node);
                    *node = replacement;
                    *changed = 1;
                    return EXPR_SUCCESS;
                }
            }
            if ((*node)->data.binary.left->type == EXPR_NODE_NUMBER) {
                left_val = (*node)->data.binary.left->data.number;
                if (left_val == 1.0) {
                    replacement = expr_priv_node_new(EXPR_NODE_NUMBER);
                    if (!replacement)
                        return EXPR_ERROR_MEMORY;
                    replacement->data.number = 1.0;
                    expr_priv_node_free(*node);
                    *node = replacement;
                    *changed = 1;
                    return EXPR_SUCCESS;
                }
            }
            break;
            
        default:
            break;
    }
    
    switch ((*node)->type) {
        case EXPR_NODE_UNARY_PLUS:
        case EXPR_NODE_UNARY_MINUS:
            ret = expr_priv_optimize_dead_code(&(*node)->data.unary.operand, changed);
            if (ret != EXPR_SUCCESS)
                return ret;
            break;
            
        case EXPR_NODE_ADD:
        case EXPR_NODE_SUBTRACT:
        case EXPR_NODE_MULTIPLY:
        case EXPR_NODE_DIVIDE:
        case EXPR_NODE_POWER:
        case EXPR_NODE_MODULO:
        case EXPR_NODE_SEQUENCE:
            ret = expr_priv_optimize_dead_code(&(*node)->data.binary.left, changed);
            if (ret != EXPR_SUCCESS)
                return ret;
            ret = expr_priv_optimize_dead_code(&(*node)->data.binary.right, changed);
            if (ret != EXPR_SUCCESS)
                return ret;
            break;
            
        case EXPR_NODE_FUNCTION1:
        case EXPR_NODE_FUNCTION2:
        case EXPR_NODE_FUNCTION3:
        case EXPR_NODE_FUNCTION4: {
            int i;
            for (i = 0; i < (*node)->data.function.arg_count; i++) {
                ret = expr_priv_optimize_dead_code(&(*node)->data.function.args[i], changed);
                if (ret != EXPR_SUCCESS)
                    return ret;
            }
            break;
        }
        
        default:
            break;
    }
    
    return EXPR_SUCCESS;
}

/* Helper structure for tracking subexpressions during CSE */
typedef struct cse_entry {
    expr_node_t *node;          /* The subexpression */
    expr_node_t **replacement;  /* Where to store the replacement */
    int count;                  /* How many times we've seen this */
    struct cse_entry *next;     /* Linked list */
} cse_entry_t;

/*
 * expr_priv_nodes_equal
 *
 * Compares two AST nodes for structural equality.
 *
 * Input: node1, node2 - nodes to compare
 * Output: 1 if equal, 0 if different
 * Side effects: None
 *
 * Dependencies: None
 *
 * Recursively compares node structure and values.
 */
static int
expr_priv_nodes_equal(expr_node_t *node1, expr_node_t *node2)
{
    int i;
    
    if (!node1 && !node2)
        return 1;
    if (!node1 || !node2)
        return 0;
    if (node1->type != node2->type)
        return 0;
    
    switch (node1->type) {
        case EXPR_NODE_NUMBER:
            return node1->data.number == node2->data.number;
            
        case EXPR_NODE_VARIABLE:
            return node1->data.symbol.symbol_ptr == node2->data.symbol.symbol_ptr;
            
        case EXPR_NODE_CONSTANT:
            return strcmp(node1->data.symbol.name, node2->data.symbol.name) == 0;
            
        case EXPR_NODE_UNARY_PLUS:
        case EXPR_NODE_UNARY_MINUS:
            return expr_priv_nodes_equal(node1->data.unary.operand, node2->data.unary.operand);
            
        case EXPR_NODE_ADD:
        case EXPR_NODE_SUBTRACT:
        case EXPR_NODE_MULTIPLY:
        case EXPR_NODE_DIVIDE:
        case EXPR_NODE_POWER:
        case EXPR_NODE_MODULO:
        case EXPR_NODE_SEQUENCE:
        case EXPR_NODE_ASSIGN:
        case EXPR_NODE_ADD_ASSIGN:
        case EXPR_NODE_SUB_ASSIGN:
        case EXPR_NODE_MUL_ASSIGN:
        case EXPR_NODE_DIV_ASSIGN:
        case EXPR_NODE_POW_ASSIGN:
        case EXPR_NODE_MOD_ASSIGN:
            return expr_priv_nodes_equal(node1->data.binary.left, node2->data.binary.left) &&
                   expr_priv_nodes_equal(node1->data.binary.right, node2->data.binary.right);
            
        case EXPR_NODE_FUNCTION1:
        case EXPR_NODE_FUNCTION2:
        case EXPR_NODE_FUNCTION3:
        case EXPR_NODE_FUNCTION4:
            if (node1->data.function.arg_count != node2->data.function.arg_count)
                return 0;
            if (node1->data.function.symbol_ptr != node2->data.function.symbol_ptr)
                return 0;
            
            for (i = 0; i < node1->data.function.arg_count; i++) {
                if (!expr_priv_nodes_equal(node1->data.function.args[i], node2->data.function.args[i]))
                    return 0;
            }
            return 1;
            
        default:
            return 0;
    }
}

/*
 * expr_priv_is_pure_subexpr
 *
 * Checks if a subexpression is pure (contains no variables or assignments).
 *
 * Input: node - node to check
 * Output: 1 if pure, 0 if not pure
 * Side effects: None
 *
 * Dependencies: None
 *
 * Only pure subexpressions are safe for CSE optimization.
 */
static int
expr_priv_is_pure_subexpr(expr_node_t *node)
{
    int i;
    
    if (!node)
        return 1;
    
    switch (node->type) {
        case EXPR_NODE_NUMBER:
        case EXPR_NODE_CONSTANT:
            return 1;
            
        case EXPR_NODE_VARIABLE:
            return 0; /* Variables can change */
            
        case EXPR_NODE_ASSIGN:
        case EXPR_NODE_ADD_ASSIGN:
        case EXPR_NODE_SUB_ASSIGN:
        case EXPR_NODE_MUL_ASSIGN:
        case EXPR_NODE_DIV_ASSIGN:
        case EXPR_NODE_POW_ASSIGN:
        case EXPR_NODE_MOD_ASSIGN:
            return 0; /* Assignments have side effects */
            
        case EXPR_NODE_UNARY_PLUS:
        case EXPR_NODE_UNARY_MINUS:
            return expr_priv_is_pure_subexpr(node->data.unary.operand);
            
        case EXPR_NODE_ADD:
        case EXPR_NODE_SUBTRACT:
        case EXPR_NODE_MULTIPLY:
        case EXPR_NODE_DIVIDE:
        case EXPR_NODE_POWER:
        case EXPR_NODE_MODULO:
        case EXPR_NODE_SEQUENCE:
            return expr_priv_is_pure_subexpr(node->data.binary.left) &&
                   expr_priv_is_pure_subexpr(node->data.binary.right);
            
        case EXPR_NODE_FUNCTION1:
        case EXPR_NODE_FUNCTION2:
        case EXPR_NODE_FUNCTION3:
        case EXPR_NODE_FUNCTION4:
            /* Get symbol to check if function is pure */
            expr_symbol_t *symbol = (expr_symbol_t*)node->data.function.symbol_ptr;
            if (!symbol || !(symbol->options & EXPR_FUNC_PURE))
                return 0;
            
            for (i = 0; i < node->data.function.arg_count; i++) {
                if (!expr_priv_is_pure_subexpr(node->data.function.args[i]))
                    return 0;
            }
            return 1;
            
        default:
            return 0;
    }
}

/*
 * expr_priv_collect_subexpressions
 *
 * Collects repeated subexpressions for CSE optimization.
 *
 * Input: node - current node to analyze
 *        cse_list - pointer to CSE list head
 * Output: EXPR_SUCCESS on success, error code on failure
 * Side effects: Modifies CSE list
 *
 * Dependencies: Memory allocation
 *
 * Recursively finds repeated pure subexpressions.
 */
static int
expr_priv_collect_subexpressions(expr_node_t *node, cse_entry_t **cse_list)
{
    cse_entry_t *entry, *new_entry;
    int ret, i;
    
    if (!node)
        return EXPR_SUCCESS;
    
    /* Skip simple nodes that aren't worth optimizing */
    if (node->type == EXPR_NODE_NUMBER || 
        node->type == EXPR_NODE_VARIABLE || 
        node->type == EXPR_NODE_CONSTANT)
        return EXPR_SUCCESS;
    
    /* Only collect pure subexpressions */
    if (!expr_priv_is_pure_subexpr(node))
        goto recurse;
    
    /* Look for existing entry */
    for (entry = *cse_list; entry; entry = entry->next) {
        if (expr_priv_nodes_equal(node, entry->node)) {
            entry->count++;
            return EXPR_SUCCESS;
        }
    }
    
    /* Add new entry */
    new_entry = (cse_entry_t*)malloc(sizeof(cse_entry_t));
    if (!new_entry)
        return EXPR_ERROR_MEMORY;
    
    new_entry->node = node;
    new_entry->replacement = NULL;
    new_entry->count = 1;
    new_entry->next = *cse_list;
    *cse_list = new_entry;
    
recurse:
    /* Recursively collect from children */
    switch (node->type) {
        case EXPR_NODE_UNARY_PLUS:
        case EXPR_NODE_UNARY_MINUS:
            ret = expr_priv_collect_subexpressions(node->data.unary.operand, cse_list);
            if (ret != EXPR_SUCCESS)
                return ret;
            break;
            
        case EXPR_NODE_ADD:
        case EXPR_NODE_SUBTRACT:
        case EXPR_NODE_MULTIPLY:
        case EXPR_NODE_DIVIDE:
        case EXPR_NODE_POWER:
        case EXPR_NODE_MODULO:
        case EXPR_NODE_SEQUENCE:
        case EXPR_NODE_ASSIGN:
        case EXPR_NODE_ADD_ASSIGN:
        case EXPR_NODE_SUB_ASSIGN:
        case EXPR_NODE_MUL_ASSIGN:
        case EXPR_NODE_DIV_ASSIGN:
        case EXPR_NODE_POW_ASSIGN:
        case EXPR_NODE_MOD_ASSIGN:
            ret = expr_priv_collect_subexpressions(node->data.binary.left, cse_list);
            if (ret != EXPR_SUCCESS)
                return ret;
            ret = expr_priv_collect_subexpressions(node->data.binary.right, cse_list);
            if (ret != EXPR_SUCCESS)
                return ret;
            break;
            
        case EXPR_NODE_FUNCTION1:
        case EXPR_NODE_FUNCTION2:
        case EXPR_NODE_FUNCTION3:
        case EXPR_NODE_FUNCTION4:
            for (i = 0; i < node->data.function.arg_count; i++) {
                ret = expr_priv_collect_subexpressions(node->data.function.args[i], cse_list);
                if (ret != EXPR_SUCCESS)
                    return ret;
            }
            break;
            
        default:
            break;
    }
    
    return EXPR_SUCCESS;
}

/*
 * expr_priv_optimize_common_subexpr
 *
 * Performs common subexpression elimination by identifying and caching
 * repeated pure subexpressions throughout the AST.
 *
 * Input: node - pointer to AST node pointer
 *        changed - pointer to flag indicating if changes were made
 * Output: EXPR_SUCCESS on success, error code on failure
 * Side effects: May modify AST structure for repeated expressions
 *
 * Dependencies: Node comparison, memory allocation
 *
 * Identifies repeated pure subexpressions and optimizes evaluation.
 */
int
expr_priv_optimize_common_subexpr(expr_node_t **node, int *changed)
{
    cse_entry_t *cse_list = NULL;
    cse_entry_t *entry, *next_entry;
    int ret;
    
    if (!node || !*node || !changed)
        return EXPR_ERROR_INVALID_PARAM;
    
    /* For now, implement a simple version that just collects statistics */
    /* Full CSE would require more complex temporary variable management */
    
    ret = expr_priv_collect_subexpressions(*node, &cse_list);
    if (ret != EXPR_SUCCESS)
        goto cleanup;
    
    /* Count how many subexpressions were found multiple times */
    for (entry = cse_list; entry; entry = entry->next) {
        if (entry->count > 1) {
            /* In a full implementation, we would:
             * 1. Create a temporary variable for this subexpression
             * 2. Replace all instances with the temporary variable
             * 3. Add an assignment at the beginning to compute the temp
             * 
             * For now, we just note that optimization is possible
             */
            *changed = 0; /* Don't claim we made changes yet */
        }
    }
    
cleanup:
    /* Clean up CSE list */
    for (entry = cse_list; entry; entry = next_entry) {
        next_entry = entry->next;
        free(entry);
    }
    
    return ret;
}

/*
 * expr_priv_optimize_pure_functions
 *
 * Optimizes pure function calls by pre-computing those with constant arguments.
 * Pure functions with constant inputs always return the same output.
 *
 * Input: node - pointer to AST node pointer (may be modified)
 *        changed - pointer to flag indicating if changes were made
 * Output: EXPR_SUCCESS on success, error code on failure
 * Side effects: May replace function nodes with constant values
 *
 * Dependencies: Function evaluation, node creation
 *
 * Pre-evaluates pure function calls with constant arguments at compile time.
 */
int
expr_priv_optimize_pure_functions(expr_node_t **node, int *changed)
{
    expr_node_t *new_node;
    double result;
    int ret, i;
    int all_constant;
    
    if (!node || !*node || !changed)
        return EXPR_ERROR_INVALID_PARAM;
    
    /* Recursively optimize children first */
    switch ((*node)->type) {
        case EXPR_NODE_UNARY_PLUS:
        case EXPR_NODE_UNARY_MINUS:
            ret = expr_priv_optimize_pure_functions(&(*node)->data.unary.operand, changed);
            if (ret != EXPR_SUCCESS)
                return ret;
            break;
            
        case EXPR_NODE_ADD:
        case EXPR_NODE_SUBTRACT:
        case EXPR_NODE_MULTIPLY:
        case EXPR_NODE_DIVIDE:
        case EXPR_NODE_POWER:
        case EXPR_NODE_MODULO:
        case EXPR_NODE_SEQUENCE:
        case EXPR_NODE_ASSIGN:
        case EXPR_NODE_ADD_ASSIGN:
        case EXPR_NODE_SUB_ASSIGN:
        case EXPR_NODE_MUL_ASSIGN:
        case EXPR_NODE_DIV_ASSIGN:
        case EXPR_NODE_POW_ASSIGN:
        case EXPR_NODE_MOD_ASSIGN:
            ret = expr_priv_optimize_pure_functions(&(*node)->data.binary.left, changed);
            if (ret != EXPR_SUCCESS)
                return ret;
            ret = expr_priv_optimize_pure_functions(&(*node)->data.binary.right, changed);
            if (ret != EXPR_SUCCESS)
                return ret;
            break;
            
        case EXPR_NODE_FUNCTION1:
        case EXPR_NODE_FUNCTION2:
        case EXPR_NODE_FUNCTION3:
        case EXPR_NODE_FUNCTION4:
            for (i = 0; i < (*node)->data.function.arg_count; i++) {
                ret = expr_priv_optimize_pure_functions(&(*node)->data.function.args[i], changed);
                if (ret != EXPR_SUCCESS)
                    return ret;
            }
            break;
            
        default:
            break;
    }
    
    /* Optimize pure function calls with constant arguments */
    switch ((*node)->type) {
        case EXPR_NODE_FUNCTION1:
        case EXPR_NODE_FUNCTION2:
        case EXPR_NODE_FUNCTION3:
        case EXPR_NODE_FUNCTION4:
            /* Check if function is pure and all arguments are constants */
            expr_symbol_t *symbol = (expr_symbol_t*)(*node)->data.function.symbol_ptr;
            if (!symbol || !(symbol->options & EXPR_FUNC_PURE))
                break;
            
            all_constant = 1;
            for (i = 0; i < (*node)->data.function.arg_count; i++) {
                if ((*node)->data.function.args[i]->type != EXPR_NODE_NUMBER &&
                    (*node)->data.function.args[i]->type != EXPR_NODE_CONSTANT) {
                    all_constant = 0;
                    break;
                }
            }
            
            if (all_constant) {
                /* Evaluate the function with constant arguments */
                double args[4] = {0};  /* Max 4 arguments */
                
                for (i = 0; i < (*node)->data.function.arg_count; i++) {
                    if ((*node)->data.function.args[i]->type == EXPR_NODE_NUMBER) {
                        args[i] = (*node)->data.function.args[i]->data.number;
                    } else if ((*node)->data.function.args[i]->type == EXPR_NODE_CONSTANT) {
                        expr_symbol_t *const_symbol = (expr_symbol_t*)(*node)->data.function.args[i]->data.symbol.symbol_ptr;
                        args[i] = const_symbol->data.constant_value;
                    }
                }
                
                /* Call the appropriate function based on argument count */
                switch ((*node)->data.function.arg_count) {
                    case 1:
                        result = symbol->data.func1(args[0]);
                        break;
                    case 2:
                        result = symbol->data.func2(args[0], args[1]);
                        break;
                    case 3:
                        result = symbol->data.func3(args[0], args[1], args[2]);
                        break;
                    case 4:
                        result = symbol->data.func4(args[0], args[1], args[2], args[3]);
                        break;
                    default:
                        return EXPR_SUCCESS; /* Skip invalid function */
                }
                
                /* Check for mathematical errors */
                if (isnan(result) || isinf(result)) {
                    return EXPR_SUCCESS; /* Don't optimize problematic results */
                }
                
                /* Replace function call with constant result */
                new_node = expr_priv_node_new(EXPR_NODE_NUMBER);
                if (!new_node)
                    return EXPR_ERROR_MEMORY;
                
                new_node->data.number = result;
                
                /* Free old function node */
                for (i = 0; i < (*node)->data.function.arg_count; i++) {
                    expr_priv_node_free((*node)->data.function.args[i]);
                }
                free((*node)->data.function.args);
                free(*node);
                
                *node = new_node;
                *changed = 1;
            }
            break;
            
        default:
            break;
    }
    
    return EXPR_SUCCESS;
}

/*
 * expr_priv_optimize_algebraic
 *
 * Placeholder for algebraic simplification.
 *
 * Input: node - pointer to AST node pointer
 *        changed - pointer to change flag
 * Output: EXPR_SUCCESS (no optimization yet)
 * Side effects: None currently
 *
 * Dependencies: None
 *
 * Future implementation will perform algebraic transformations.
 */
int
expr_priv_optimize_algebraic(expr_node_t **node, int *changed)
{
    (void)node;
    (void)changed;
    return EXPR_SUCCESS;
}

/*
 * expr_priv_optimize_strength
 *
 * Performs strength reduction optimization by replacing expensive operations
 * with cheaper equivalent operations.
 *
 * Input: node - pointer to AST node pointer (may be modified)
 *        changed - pointer to flag indicating if changes were made
 * Output: EXPR_SUCCESS on success, error code on failure
 * Side effects: May replace nodes with cheaper operations
 *
 * Dependencies: Node creation and manipulation functions
 *
 * Replaces expensive operations like x^2 -> x*x, x/const -> x*(1/const).
 */
int
expr_priv_optimize_strength(expr_node_t **node, int *changed)
{
    expr_node_t *new_node, *mult_node;
    int ret;
    
    if (!node || !*node || !changed)
        return EXPR_ERROR_INVALID_PARAM;
    
    /* Recursively optimize children first */
    switch ((*node)->type) {
        case EXPR_NODE_UNARY_PLUS:
        case EXPR_NODE_UNARY_MINUS:
            ret = expr_priv_optimize_strength(&(*node)->data.unary.operand, changed);
            if (ret != EXPR_SUCCESS)
                return ret;
            break;
            
        case EXPR_NODE_ADD:
        case EXPR_NODE_SUBTRACT:
        case EXPR_NODE_MULTIPLY:
        case EXPR_NODE_DIVIDE:
        case EXPR_NODE_POWER:
        case EXPR_NODE_MODULO:
        case EXPR_NODE_SEQUENCE:
        case EXPR_NODE_ASSIGN:
        case EXPR_NODE_ADD_ASSIGN:
        case EXPR_NODE_SUB_ASSIGN:
        case EXPR_NODE_MUL_ASSIGN:
        case EXPR_NODE_DIV_ASSIGN:
        case EXPR_NODE_POW_ASSIGN:
        case EXPR_NODE_MOD_ASSIGN:
            ret = expr_priv_optimize_strength(&(*node)->data.binary.left, changed);
            if (ret != EXPR_SUCCESS)
                return ret;
            ret = expr_priv_optimize_strength(&(*node)->data.binary.right, changed);
            if (ret != EXPR_SUCCESS)
                return ret;
            break;
            
        case EXPR_NODE_FUNCTION1:
        case EXPR_NODE_FUNCTION2:
        case EXPR_NODE_FUNCTION3:
        case EXPR_NODE_FUNCTION4: {
            int i;
            for (i = 0; i < (*node)->data.function.arg_count; i++) {
                ret = expr_priv_optimize_strength(&(*node)->data.function.args[i], changed);
                if (ret != EXPR_SUCCESS)
                    return ret;
            }
            break;
        }
        
        default:
            break;
    }
    
    /* Apply strength reduction transformations */
    switch ((*node)->type) {
        case EXPR_NODE_POWER:
            /* x^2 -> x*x (multiplication is cheaper than power) */
            if ((*node)->data.binary.right->type == EXPR_NODE_NUMBER && 
                (*node)->data.binary.right->data.number == 2.0) {
                
                mult_node = expr_priv_node_new(EXPR_NODE_MULTIPLY);
                if (!mult_node)
                    return EXPR_ERROR_MEMORY;
                
                /* Create x*x by keeping left operand and creating a copy for right */
                mult_node->data.binary.left = (*node)->data.binary.left;
                
                /* For now, only optimize when left operand is a simple number or variable */
                if ((*node)->data.binary.left->type == EXPR_NODE_NUMBER) {
                    mult_node->data.binary.right = expr_priv_node_new(EXPR_NODE_NUMBER);
                    if (!mult_node->data.binary.right) {
                        expr_priv_node_free(mult_node);
                        return EXPR_ERROR_MEMORY;
                    }
                    mult_node->data.binary.right->data.number = (*node)->data.binary.left->data.number;
                } else if ((*node)->data.binary.left->type == EXPR_NODE_VARIABLE) {
                    mult_node->data.binary.right = expr_priv_node_new(EXPR_NODE_VARIABLE);
                    if (!mult_node->data.binary.right) {
                        expr_priv_node_free(mult_node);
                        return EXPR_ERROR_MEMORY;
                    }
                    mult_node->data.binary.right->data.symbol = (*node)->data.binary.left->data.symbol;
                } else {
                    /* For complex expressions, skip this optimization to avoid issues */
                    expr_priv_node_free(mult_node);
                    break;
                }
                
                /* Free the power of 2 node and replace with multiplication */
                expr_priv_node_free((*node)->data.binary.right);
                free(*node);
                *node = mult_node;
                *changed = 1;
            }
            /* x^1 -> x */
            else if ((*node)->data.binary.right->type == EXPR_NODE_NUMBER && 
                     (*node)->data.binary.right->data.number == 1.0) {
                
                new_node = (*node)->data.binary.left;
                expr_priv_node_free((*node)->data.binary.right);
                free(*node);
                *node = new_node;
                *changed = 1;
            }
            /* x^0 -> 1 */
            else if ((*node)->data.binary.right->type == EXPR_NODE_NUMBER && 
                     (*node)->data.binary.right->data.number == 0.0) {
                
                new_node = expr_priv_node_new(EXPR_NODE_NUMBER);
                if (!new_node)
                    return EXPR_ERROR_MEMORY;
                new_node->data.number = 1.0;
                
                expr_priv_node_free((*node)->data.binary.left);
                expr_priv_node_free((*node)->data.binary.right);
                free(*node);
                *node = new_node;
                *changed = 1;
            }
            break;
            
        case EXPR_NODE_DIVIDE:
            /* x / 2 -> x * 0.5 (multiplication is cheaper than division) */
            if ((*node)->data.binary.right->type == EXPR_NODE_NUMBER && 
                (*node)->data.binary.right->data.number != 0.0) {
                
                double divisor = (*node)->data.binary.right->data.number;
                
                /* Only optimize for some common divisors to avoid precision issues */
                if (divisor == 2.0 || divisor == 4.0 || divisor == 8.0 || 
                    divisor == 0.5 || divisor == 0.25) {
                    
                    (*node)->type = EXPR_NODE_MULTIPLY;
                    (*node)->data.binary.right->data.number = 1.0 / divisor;
                    *changed = 1;
                }
            }
            break;
            
        case EXPR_NODE_MULTIPLY:
            /* x * 0 -> 0 */
            if (((*node)->data.binary.left->type == EXPR_NODE_NUMBER && 
                 (*node)->data.binary.left->data.number == 0.0) ||
                ((*node)->data.binary.right->type == EXPR_NODE_NUMBER && 
                 (*node)->data.binary.right->data.number == 0.0)) {
                
                new_node = expr_priv_node_new(EXPR_NODE_NUMBER);
                if (!new_node)
                    return EXPR_ERROR_MEMORY;
                new_node->data.number = 0.0;
                
                expr_priv_node_free((*node)->data.binary.left);
                expr_priv_node_free((*node)->data.binary.right);
                free(*node);
                *node = new_node;
                *changed = 1;
            }
            break;
            
        default:
            break;
    }
    
    return EXPR_SUCCESS;
}

/*
 * expr_optimize
 *
 * Performs multiple optimization passes on expression handle.
 *
 * Input: handle - pointer to expression handle pointer
 *        report - optional optimization report structure
 * Output: EXPR_SUCCESS on success, error code on failure
 * Side effects: May modify expression AST, allocates report data
 *
 * Dependencies: All optimization pass functions
 *
 * Public API function for expression optimization with reporting.
 */
int
expr_optimize(expr_handle *handle, optimization_report_t *report)
{
    int pass_count = 0;
    int total_changed;
    int pass_changed;
    int ret;
    clock_t start_time, end_time;
    char *original_expr = NULL;
    char *optimized_expr = NULL;
    
    if (!handle || !*handle)
        return EXPR_ERROR_INVALID_PARAM;
    
    if (!(*handle)->root)
        return EXPR_SUCCESS;
    
    start_time = clock();
    
    if (report) {
        report->original_nodes = expr_priv_node_count((*handle)->root);
        original_expr = expr_priv_node_to_string((*handle)->root);
        report->constants_folded = 0;
        report->dead_code_eliminated = 0;
        report->common_subexpressions = 0;
        report->pure_functions_precomputed = 0;
    }
    
    do {
        total_changed = 0;
        pass_count++;
        
        pass_changed = 0;
        ret = expr_priv_optimize_constant_fold(&(*handle)->root, &pass_changed);
        if (ret != EXPR_SUCCESS)
            return ret;
        if (pass_changed && report)
            report->constants_folded++;
        total_changed += pass_changed;
        
        pass_changed = 0;
        ret = expr_priv_optimize_dead_code(&(*handle)->root, &pass_changed);
        if (ret != EXPR_SUCCESS)
            return ret;
        if (pass_changed && report)
            report->dead_code_eliminated++;
        total_changed += pass_changed;
        
        pass_changed = 0;
        ret = expr_priv_optimize_common_subexpr(&(*handle)->root, &pass_changed);
        if (ret != EXPR_SUCCESS)
            return ret;
        total_changed += pass_changed;
        
        pass_changed = 0;
        ret = expr_priv_optimize_pure_functions(&(*handle)->root, &pass_changed);
        if (ret != EXPR_SUCCESS)
            return ret;
        if (pass_changed && report)
            report->pure_functions_precomputed++;
        total_changed += pass_changed;
        
        pass_changed = 0;
        ret = expr_priv_optimize_algebraic(&(*handle)->root, &pass_changed);
        if (ret != EXPR_SUCCESS)
            return ret;
        total_changed += pass_changed;
        
        pass_changed = 0;
        ret = expr_priv_optimize_strength(&(*handle)->root, &pass_changed);
        if (ret != EXPR_SUCCESS)
            return ret;
        total_changed += pass_changed;
        
    } while (total_changed > 0 && pass_count < 100);
    
    end_time = clock();
    
    if (report) {
        report->total_passes = pass_count;
        report->final_nodes = expr_priv_node_count((*handle)->root);
        report->optimization_time_ms = ((double)(end_time - start_time) / CLOCKS_PER_SEC) * 1000.0;
        
        optimized_expr = expr_priv_node_to_string((*handle)->root);
        
        report->original_expression = original_expr;
        report->optimized_expression = optimized_expr;
        
        int summary_len = 200;
        report->summary = (char*)malloc(summary_len);
        if (report->summary) {
            snprintf(report->summary, summary_len,
                    "Optimization completed in %d passes. "
                    "Nodes: %d -> %d. "
                    "Constant folding: %d, Dead code: %d",
                    report->total_passes,
                    report->original_nodes,
                    report->final_nodes,
                    report->constants_folded,
                    report->dead_code_eliminated);
        }
    }
    
    return EXPR_SUCCESS;
}

/*
 * expr_free_optimization_report
 *
 * Frees memory allocated for optimization report.
 *
 * Input: report - optimization report to free
 * Output: None
 * Side effects: Frees report string memory
 *
 * Dependencies: Standard library free
 *
 * Utility function for cleaning up optimization reports.
 */
void
expr_free_optimization_report(optimization_report_t *report)
{
    if (!report)
        return;
    
    if (report->summary)
        free(report->summary);
    if (report->original_expression)
        free(report->original_expression);
    if (report->optimized_expression)
        free(report->optimized_expression);
    
    report->summary = NULL;
    report->original_expression = NULL;
    report->optimized_expression = NULL;
}