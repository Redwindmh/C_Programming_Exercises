/*
 * expr_ast.c
 *
 * Copyright (C) 2025 by Robert Cousins
 * All Rights Reserved
 *
 * Abstract Syntax Tree utilities for mathematical expression evaluation library.
 * Provides node creation, manipulation, copying, and string representation
 * functions for expression ASTs.
 *
 * $Id: expr_ast.c,v 1.1 2025/06/25 16:02:06 rec Exp rec $
 *
 * Author: Robert Cousins
 *
 * 2025-06-22: Initial implementation
 */

#include "expr_private.h"

/*
 * expr_priv_node_new
 *
 * Creates a new AST node of the specified type.
 *
 * Input: type - node type to create
 * Output: Pointer to new node or NULL on failure
 * Side effects: Allocates memory for node structure
 *
 * Dependencies: Standard library malloc
 *
 * Initializes all node fields to safe defaults.
 */
expr_node_t*
expr_priv_node_new(expr_node_type_t type)
{
    expr_node_t *node;
    
    node = (expr_node_t*)malloc(sizeof(expr_node_t));
    if (!node)
        return NULL;
    
    node->type = type;
    node->cached_value = 0.0;
    node->has_cached_value = 0;
    
    switch (type) {
        case EXPR_NODE_NUMBER:
            node->data.number = 0.0;
            break;
        case EXPR_NODE_VARIABLE:
        case EXPR_NODE_CONSTANT:
            node->data.symbol.name = NULL;
            node->data.symbol.symbol_ptr = NULL;
            break;
        case EXPR_NODE_FUNCTION0:
        case EXPR_NODE_FUNCTION1:
        case EXPR_NODE_FUNCTION2:
        case EXPR_NODE_FUNCTION3:
        case EXPR_NODE_FUNCTION4:
            node->data.function.args = NULL;
            node->data.function.arg_count = 0;
            node->data.function.symbol_ptr = NULL;
            break;
        case EXPR_NODE_UNARY_PLUS:
        case EXPR_NODE_UNARY_MINUS:
            node->data.unary.operand = NULL;
            break;
        default:
            node->data.binary.left = NULL;
            node->data.binary.right = NULL;
            break;
    }
    
    return node;
}

/*
 * expr_priv_node_free
 *
 * Recursively frees an AST node and all its children.
 *
 * Input: node - node to free
 * Output: None
 * Side effects: Frees all memory associated with node tree
 *
 * Dependencies: Standard library free
 *
 * Performs deep traversal to free entire subtree.
 */
void
expr_priv_node_free(expr_node_t *node)
{
    int i;
    
    if (!node)
        return;
    
    switch (node->type) {
        case EXPR_NODE_VARIABLE:
        case EXPR_NODE_CONSTANT:
            if (node->data.symbol.name)
                free(node->data.symbol.name);
            break;
        case EXPR_NODE_FUNCTION0:
        case EXPR_NODE_FUNCTION1:
        case EXPR_NODE_FUNCTION2:
        case EXPR_NODE_FUNCTION3:
        case EXPR_NODE_FUNCTION4:
            if (node->data.function.args) {
                for (i = 0; i < node->data.function.arg_count; i++) {
                    if (node->data.function.args[i])
                        expr_priv_node_free(node->data.function.args[i]);
                }
                free(node->data.function.args);
            }
            break;
        case EXPR_NODE_UNARY_PLUS:
        case EXPR_NODE_UNARY_MINUS:
            expr_priv_node_free(node->data.unary.operand);
            break;
        case EXPR_NODE_NUMBER:
            break;
        default:
            expr_priv_node_free(node->data.binary.left);
            expr_priv_node_free(node->data.binary.right);
            break;
    }
    
    free(node);
}

/*
 * expr_priv_node_copy
 *
 * Creates a deep copy of an AST node and all its children.
 *
 * Input: node - node to copy
 * Output: Pointer to copied node or NULL on failure
 * Side effects: Allocates memory for new node tree
 *
 * Dependencies: Node creation and string duplication
 *
 * Recursively copies entire subtree structure.
 */
expr_node_t*
expr_priv_node_copy(const expr_node_t *node)
{
    expr_node_t *copy;
    int i;
    
    if (!node)
        return NULL;
    
    copy = expr_priv_node_new(node->type);
    if (!copy)
        return NULL;
    
    copy->cached_value = node->cached_value;
    copy->has_cached_value = node->has_cached_value;
    
    switch (node->type) {
        case EXPR_NODE_NUMBER:
            copy->data.number = node->data.number;
            break;
        case EXPR_NODE_VARIABLE:
        case EXPR_NODE_CONSTANT:
            if (node->data.symbol.name) {
                copy->data.symbol.name = (char*)malloc(strlen(node->data.symbol.name) + 1);
                if (!copy->data.symbol.name) {
                    expr_priv_node_free(copy);
                    return NULL;
                }
                strcpy(copy->data.symbol.name, node->data.symbol.name);
            }
            copy->data.symbol.symbol_ptr = node->data.symbol.symbol_ptr;
            break;
        case EXPR_NODE_FUNCTION0:
        case EXPR_NODE_FUNCTION1:
        case EXPR_NODE_FUNCTION2:
        case EXPR_NODE_FUNCTION3:
        case EXPR_NODE_FUNCTION4:
            copy->data.function.arg_count = node->data.function.arg_count;
            copy->data.function.symbol_ptr = node->data.function.symbol_ptr;
            if (node->data.function.arg_count > 0) {
                copy->data.function.args = (expr_node_t**)malloc(
                    node->data.function.arg_count * sizeof(expr_node_t*));
                if (!copy->data.function.args) {
                    expr_priv_node_free(copy);
                    return NULL;
                }
                /* Initialize to NULL for safe cleanup */
                for (i = 0; i < node->data.function.arg_count; i++) {
                    copy->data.function.args[i] = NULL;
                }
                for (i = 0; i < node->data.function.arg_count; i++) {
                    copy->data.function.args[i] = expr_priv_node_copy(node->data.function.args[i]);
                    if (!copy->data.function.args[i]) {
                        expr_priv_node_free(copy);
                        return NULL;
                    }
                }
            }
            break;
        case EXPR_NODE_UNARY_PLUS:
        case EXPR_NODE_UNARY_MINUS:
            copy->data.unary.operand = expr_priv_node_copy(node->data.unary.operand);
            if (!copy->data.unary.operand) {
                expr_priv_node_free(copy);
                return NULL;
            }
            break;
        default:
            copy->data.binary.left = expr_priv_node_copy(node->data.binary.left);
            copy->data.binary.right = expr_priv_node_copy(node->data.binary.right);
            if (!copy->data.binary.left || !copy->data.binary.right) {
                expr_priv_node_free(copy);
                return NULL;
            }
            break;
    }
    
    return copy;
}

/*
 * expr_priv_node_count
 *
 * Counts the total number of nodes in an AST subtree.
 *
 * Input: node - root of subtree to count
 * Output: Total number of nodes
 * Side effects: None
 *
 * Dependencies: None
 *
 * Recursively traverses tree to count all nodes.
 */
int
expr_priv_node_count(const expr_node_t *node)
{
    int count = 0;
    int i;
    
    if (!node)
        return 0;
    
    count = 1;
    
    switch (node->type) {
        case EXPR_NODE_FUNCTION0:
        case EXPR_NODE_FUNCTION1:
        case EXPR_NODE_FUNCTION2:
        case EXPR_NODE_FUNCTION3:
        case EXPR_NODE_FUNCTION4:
            for (i = 0; i < node->data.function.arg_count; i++)
                count += expr_priv_node_count(node->data.function.args[i]);
            break;
        case EXPR_NODE_UNARY_PLUS:
        case EXPR_NODE_UNARY_MINUS:
            count += expr_priv_node_count(node->data.unary.operand);
            break;
        case EXPR_NODE_NUMBER:
        case EXPR_NODE_VARIABLE:
        case EXPR_NODE_CONSTANT:
            break;
        default:
            count += expr_priv_node_count(node->data.binary.left);
            count += expr_priv_node_count(node->data.binary.right);
            break;
    }
    
    return count;
}

/*
 * expr_priv_node_to_string
 *
 * Converts an AST node tree to string representation.
 *
 * Input: node - root node to convert
 * Output: String representation or NULL on failure
 * Side effects: Allocates memory for result string
 *
 * Dependencies: String manipulation, dynamic memory allocation
 *
 * Creates parenthesized string representation of expression.
 */
char*
expr_priv_node_to_string(const expr_node_t *node)
{
    char *result, *left_str, *right_str, *temp;
    int len, i;
    
    if (!node)
        return NULL;
    
    switch (node->type) {
        case EXPR_NODE_NUMBER:
            result = (char*)malloc(64);
            if (result)
                sprintf(result, "%.15g", node->data.number);
            return result;
            
        case EXPR_NODE_VARIABLE:
        case EXPR_NODE_CONSTANT:
            if (!node->data.symbol.name)
                return NULL;
            len = strlen(node->data.symbol.name);
            result = (char*)malloc(len + 1);
            if (result)
                strcpy(result, node->data.symbol.name);
            return result;
            
        case EXPR_NODE_FUNCTION0:
        case EXPR_NODE_FUNCTION1:
        case EXPR_NODE_FUNCTION2:
        case EXPR_NODE_FUNCTION3:
        case EXPR_NODE_FUNCTION4: {
            expr_symbol_t *sym = (expr_symbol_t*)node->data.function.symbol_ptr;
            if (!sym || !sym->name)
                return NULL;
            
            len = strlen(sym->name) + 3;
            for (i = 0; i < node->data.function.arg_count; i++) {
                temp = expr_priv_node_to_string(node->data.function.args[i]);
                if (!temp)
                    return NULL;
                len += strlen(temp) + 2;
                free(temp);
            }
            
            result = (char*)malloc(len);
            if (!result)
                return NULL;
            
            strcpy(result, sym->name);
            strcat(result, "(");
            for (i = 0; i < node->data.function.arg_count; i++) {
                if (i > 0)
                    strcat(result, ", ");
                temp = expr_priv_node_to_string(node->data.function.args[i]);
                if (!temp) {
                    free(result);
                    return NULL;
                }
                strcat(result, temp);
                free(temp);
            }
            strcat(result, ")");
            return result;
        }
        
        case EXPR_NODE_UNARY_PLUS:
            temp = expr_priv_node_to_string(node->data.unary.operand);
            if (!temp)
                return NULL;
            len = strlen(temp) + 4;
            result = (char*)malloc(len);
            if (result) {
                strcpy(result, "(+");
                strcat(result, temp);
                strcat(result, ")");
            }
            free(temp);
            return result;
            
        case EXPR_NODE_UNARY_MINUS:
            temp = expr_priv_node_to_string(node->data.unary.operand);
            if (!temp)
                return NULL;
            len = strlen(temp) + 4;
            result = (char*)malloc(len);
            if (result) {
                strcpy(result, "(-");
                strcat(result, temp);
                strcat(result, ")");
            }
            free(temp);
            return result;
            
        default: {
            const char *op;
            switch (node->type) {
                case EXPR_NODE_ADD: op = " + "; break;
                case EXPR_NODE_SUBTRACT: op = " - "; break;
                case EXPR_NODE_MULTIPLY: op = " * "; break;
                case EXPR_NODE_DIVIDE: op = " / "; break;
                case EXPR_NODE_POWER: op = " ^ "; break;
                case EXPR_NODE_MODULO: op = " % "; break;
                case EXPR_NODE_ASSIGN: op = " = "; break;
                case EXPR_NODE_ADD_ASSIGN: op = " += "; break;
                case EXPR_NODE_SUB_ASSIGN: op = " -= "; break;
                case EXPR_NODE_MUL_ASSIGN: op = " *= "; break;
                case EXPR_NODE_DIV_ASSIGN: op = " /= "; break;
                case EXPR_NODE_POW_ASSIGN: op = " ^= "; break;
                case EXPR_NODE_MOD_ASSIGN: op = " %= "; break;
                case EXPR_NODE_SEQUENCE: op = "; "; break;
                default: op = " ? "; break;
            }
            
            left_str = expr_priv_node_to_string(node->data.binary.left);
            right_str = expr_priv_node_to_string(node->data.binary.right);
            
            if (!left_str || !right_str) {
                if (left_str) free(left_str);
                if (right_str) free(right_str);
                return NULL;
            }
            
            len = strlen(left_str) + strlen(right_str) + strlen(op) + 3;
            result = (char*)malloc(len);
            if (result) {
                strcpy(result, "(");
                strcat(result, left_str);
                strcat(result, op);
                strcat(result, right_str);
                strcat(result, ")");
            }
            
            free(left_str);
            free(right_str);
            return result;
        }
    }
}