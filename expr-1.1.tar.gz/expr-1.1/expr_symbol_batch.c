/*
 * expr_symbol_batch.c
 *
 * Copyright (C) 2025 by Robert Cousins
 * All Rights Reserved
 *
 * Batch symbol operations for mathematical expression evaluation library.
 * Provides efficient bulk addition of constants, variables, and functions
 * to symbol tables using array-based interfaces.
 *
 * $Id: expr_symbol_batch.c,v 1.1 2025/06/25 16:02:06 rec Exp rec $
 *
 * Author: Robert Cousins
 *
 * 2025-06-25: Split from expr_symbols.c for better modularity
 */

#include "expr_private.h"

/*
 * expr_add_constant_list
 *
 * Adds multiple constants from an array.
 *
 * Input: ctx - context to modify
 *        count - number of constants
 *        list - array of constant entries
 * Output: EXPR_SUCCESS on success, error code on failure
 * Side effects: Modifies symbol table
 *
 * Dependencies: Individual constant addition functions
 *
 * Batch operation for adding multiple constants efficiently.
 */
int
expr_add_constant_list(expr_context ctx, int count, const expr_constant_entry_t *list)
{
    int i, result;
    
    if (!ctx || !list || count < 0)
        return EXPR_ERROR_INVALID_PARAM;
    
    for (i = 0; i < count; i++) {
        result = expr_add_constant(ctx, list[i].name, list[i].value, list[i].options);
        if (result != EXPR_SUCCESS)
            return result;
    }
    
    return EXPR_SUCCESS;
}

/*
 * expr_add_variable_list
 *
 * Adds multiple variables from an array.
 *
 * Input: ctx - context to modify
 *        count - number of variables
 *        list - array of variable entries
 * Output: EXPR_SUCCESS on success, error code on failure
 * Side effects: Modifies symbol table
 *
 * Dependencies: Individual variable addition functions
 *
 * Batch operation for adding multiple variables efficiently.
 */
int
expr_add_variable_list(expr_context ctx, int count, const expr_variable_entry_t *list)
{
    int i, result;
    
    if (!ctx || !list || count < 0)
        return EXPR_ERROR_INVALID_PARAM;
    
    for (i = 0; i < count; i++) {
        result = expr_add_variable(ctx, list[i].name, list[i].location, list[i].options);
        if (result != EXPR_SUCCESS)
            return result;
    }
    
    return EXPR_SUCCESS;
}

/*
 * expr_add_function0_list
 *
 * Adds multiple zero-argument functions from an array.
 *
 * Input: ctx - context to modify
 *        count - number of functions
 *        list - array of function entries
 * Output: EXPR_SUCCESS on success, error code on failure
 * Side effects: Modifies symbol table
 *
 * Dependencies: Individual function addition functions
 *
 * Batch operation for adding multiple parameterless functions.
 */
int
expr_add_function0_list(expr_context ctx, int count, const expr_function0_entry_t *list)
{
    int i, result;
    
    if (!ctx || !list || count < 0)
        return EXPR_ERROR_INVALID_PARAM;
    
    for (i = 0; i < count; i++) {
        result = expr_add_function0(ctx, list[i].name, list[i].func, list[i].options);
        if (result != EXPR_SUCCESS)
            return result;
    }
    
    return EXPR_SUCCESS;
}

/*
 * expr_add_function1_list
 *
 * Adds multiple single-argument functions from an array.
 *
 * Input: ctx - context to modify
 *        count - number of functions
 *        list - array of function entries
 * Output: EXPR_SUCCESS on success, error code on failure
 * Side effects: Modifies symbol table
 *
 * Dependencies: Individual function addition functions
 *
 * Batch operation for adding multiple single-parameter functions.
 */
int
expr_add_function1_list(expr_context ctx, int count, const expr_function1_entry_t *list)
{
    int i, result;
    
    if (!ctx || !list || count < 0)
        return EXPR_ERROR_INVALID_PARAM;
    
    for (i = 0; i < count; i++) {
        result = expr_add_function1(ctx, list[i].name, list[i].func, list[i].options);
        if (result != EXPR_SUCCESS)
            return result;
    }
    
    return EXPR_SUCCESS;
}

/*
 * expr_add_function2_list
 *
 * Adds multiple two-argument functions from an array.
 *
 * Input: ctx - context to modify
 *        count - number of functions
 *        list - array of function entries
 * Output: EXPR_SUCCESS on success, error code on failure
 * Side effects: Modifies symbol table
 *
 * Dependencies: Individual function addition functions
 *
 * Batch operation for adding multiple two-parameter functions.
 */
int
expr_add_function2_list(expr_context ctx, int count, const expr_function2_entry_t *list)
{
    int i, result;
    
    if (!ctx || !list || count < 0)
        return EXPR_ERROR_INVALID_PARAM;
    
    for (i = 0; i < count; i++) {
        result = expr_add_function2(ctx, list[i].name, list[i].func, list[i].options);
        if (result != EXPR_SUCCESS)
            return result;
    }
    
    return EXPR_SUCCESS;
}

/*
 * expr_add_function3_list
 *
 * Adds multiple three-argument functions from an array.
 *
 * Input: ctx - context to modify
 *        count - number of functions
 *        list - array of function entries
 * Output: EXPR_SUCCESS on success, error code on failure
 * Side effects: Modifies symbol table
 *
 * Dependencies: Individual function addition functions
 *
 * Batch operation for adding multiple three-parameter functions.
 */
int
expr_add_function3_list(expr_context ctx, int count, const expr_function3_entry_t *list)
{
    int i, result;
    
    if (!ctx || !list || count < 0)
        return EXPR_ERROR_INVALID_PARAM;
    
    for (i = 0; i < count; i++) {
        result = expr_add_function3(ctx, list[i].name, list[i].func, list[i].options);
        if (result != EXPR_SUCCESS)
            return result;
    }
    
    return EXPR_SUCCESS;
}

/*
 * expr_add_function4_list
 *
 * Adds multiple four-argument functions from an array.
 *
 * Input: ctx - context to modify
 *        count - number of functions
 *        list - array of function entries
 * Output: EXPR_SUCCESS on success, error code on failure
 * Side effects: Modifies symbol table
 *
 * Dependencies: Individual function addition functions
 *
 * Batch operation for adding multiple four-parameter functions.
 */
int
expr_add_function4_list(expr_context ctx, int count, const expr_function4_entry_t *list)
{
    int i, result;
    
    if (!ctx || !list || count < 0)
        return EXPR_ERROR_INVALID_PARAM;
    
    for (i = 0; i < count; i++) {
        result = expr_add_function4(ctx, list[i].name, list[i].func, list[i].options);
        if (result != EXPR_SUCCESS)
            return result;
    }
    
    return EXPR_SUCCESS;
}