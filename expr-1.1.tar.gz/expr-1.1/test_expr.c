/*
 * test_expr.c
 *
 * Copyright (C) 2025 by Robert Cousins
 * All Rights Reserved
 *
 * Comprehensive test program for mathematical expression evaluation library.
 * Tests all API functions, covers corner cases, measures performance,
 * and verifies optimization effectiveness with detailed reporting.
 *
 * $Id: test_expr.c,v 1.1 2025/06/25 16:02:06 rec Exp rec $
 *
 * Author: Robert Cousins
 *
 * 2025-06-22: Initial implementation
 */

#include "expr.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <assert.h>

/* Test statistics */
static int tests_run = 0;
static int tests_passed = 0;
static int tests_failed = 0;

/* Test helper macros */
#define TEST_ASSERT(condition, message) \
    do { \
        tests_run++; \
        if (condition) { \
            tests_passed++; \
            printf("PASS: %s\n", message); \
        } else { \
            tests_failed++; \
            printf("FAIL: %s\n", message); \
        } \
    } while(0)

#define TEST_ASSERT_EQUAL(expected, actual, message) \
    do { \
        tests_run++; \
        if (fabs((expected) - (actual)) < 1e-10) { \
            tests_passed++; \
            printf("PASS: %s (%.15g)\n", message, actual); \
        } else { \
            tests_failed++; \
            printf("FAIL: %s - expected %.15g, got %.15g\n", message, expected, actual); \
        } \
    } while(0)

#define TEST_ASSERT_ERROR(result, expected_error, message) \
    do { \
        tests_run++; \
        if (result == expected_error) { \
            tests_passed++; \
            printf("PASS: %s (error %d)\n", message, result); \
        } else { \
            tests_failed++; \
            printf("FAIL: %s - expected error %d, got %d\n", message, expected_error, result); \
        } \
    } while(0)

/* Test helper functions */
double test_sin(double x) { return sin(x); }
double test_cos(double x) { return cos(x); }
double test_sqrt(double x) { return sqrt(x); }
double test_log(double x) { return log(x); }
double test_exp(double x) { return exp(x); }
double test_pow(double x, double y) { return pow(x, y); }
double test_min(double x, double y) { return x < y ? x : y; }
double test_max(double x, double y) { return x > y ? x : y; }
double test_random(void) { return (double)rand() / RAND_MAX; }
double test_get_pi(void) { return 3.14159265359; }

/*
 * test_basic_context
 *
 * Tests context creation and destruction.
 */
void test_basic_context(void)
{
    expr_context ctx;
    int result;
    
    printf("\n=== Testing Basic Context Operations ===\n");
    
    result = expr_context_new(&ctx);
    TEST_ASSERT(result == EXPR_SUCCESS, "Context creation");
    
    result = expr_context_free(ctx);
    TEST_ASSERT(result == EXPR_SUCCESS, "Context destruction");
    
    result = expr_context_new(NULL);
    TEST_ASSERT_ERROR(result, EXPR_ERROR_INVALID_PARAM, "Context creation with NULL pointer");
    
    result = expr_context_free(NULL);
    TEST_ASSERT_ERROR(result, EXPR_ERROR_INVALID_PARAM, "Context destruction with NULL");
}

/*
 * test_symbol_management
 *
 * Tests adding constants, variables, and functions.
 */
void test_symbol_management(void)
{
    expr_context ctx;
    double var1 = 42.0, var2 = 3.14;
    int result;
    
    printf("\n=== Testing Symbol Management ===\n");
    
    expr_context_new(&ctx);
    
    /* Test constants */
    result = expr_add_constant(ctx, "pi", 3.14159265359, 0);
    TEST_ASSERT(result == EXPR_SUCCESS, "Adding constant pi");
    
    result = expr_add_constant(ctx, "e", 2.71828182846, 0);
    TEST_ASSERT(result == EXPR_SUCCESS, "Adding constant e");
    
    result = expr_add_constant(ctx, "pi", 3.14, 0);
    TEST_ASSERT_ERROR(result, EXPR_ERROR_SYMBOL_EXISTS, "Adding duplicate constant");
    
    /* Test variables */
    result = expr_add_variable(ctx, "x", &var1, EXPR_VAR_READ_WRITE);
    TEST_ASSERT(result == EXPR_SUCCESS, "Adding read-write variable");
    
    result = expr_add_variable(ctx, "y", &var2, EXPR_VAR_READABLE);
    TEST_ASSERT(result == EXPR_SUCCESS, "Adding read-only variable");
    
    result = expr_add_variable(ctx, "z", NULL, EXPR_VAR_READ_WRITE);
    TEST_ASSERT_ERROR(result, EXPR_ERROR_INVALID_PARAM, "Adding variable with NULL pointer");
    
    /* Test functions */
    result = expr_add_function1(ctx, "sin", test_sin, EXPR_FUNC_PURE);
    TEST_ASSERT(result == EXPR_SUCCESS, "Adding sin function");
    
    result = expr_add_function2(ctx, "pow", test_pow, EXPR_FUNC_PURE);
    TEST_ASSERT(result == EXPR_SUCCESS, "Adding pow function");
    
    result = expr_add_function0(ctx, "random", test_random, 0);
    TEST_ASSERT(result == EXPR_SUCCESS, "Adding random function");
    
    expr_context_free(ctx);
}

/*
 * test_basic_parsing
 *
 * Tests expression parsing with various operators.
 */
void test_basic_parsing(void)
{
    expr_context ctx;
    expr_handle handle;
    double result;
    int ret;
    
    printf("\n=== Testing Basic Expression Parsing ===\n");
    
    expr_context_new(&ctx);
    
    /* Test simple numbers */
    ret = expr_compile(ctx, "42", 0, &handle);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Parsing simple number");
    if (ret == EXPR_SUCCESS) {
        expr_evaluate(handle, &result);
        TEST_ASSERT_EQUAL(42.0, result, "Evaluating simple number");
        expr_handle_free(handle);
    }
    
    /* Test arithmetic operators */
    ret = expr_compile(ctx, "2 + 3", 0, &handle);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Parsing addition");
    if (ret == EXPR_SUCCESS) {
        expr_evaluate(handle, &result);
        TEST_ASSERT_EQUAL(5.0, result, "Evaluating addition");
        expr_handle_free(handle);
    }
    
    ret = expr_compile(ctx, "10 - 4", 0, &handle);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Parsing subtraction");
    if (ret == EXPR_SUCCESS) {
        expr_evaluate(handle, &result);
        TEST_ASSERT_EQUAL(6.0, result, "Evaluating subtraction");
        expr_handle_free(handle);
    }
    
    ret = expr_compile(ctx, "3 * 4", 0, &handle);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Parsing multiplication");
    if (ret == EXPR_SUCCESS) {
        expr_evaluate(handle, &result);
        TEST_ASSERT_EQUAL(12.0, result, "Evaluating multiplication");
        expr_handle_free(handle);
    }
    
    ret = expr_compile(ctx, "15 / 3", 0, &handle);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Parsing division");
    if (ret == EXPR_SUCCESS) {
        expr_evaluate(handle, &result);
        TEST_ASSERT_EQUAL(5.0, result, "Evaluating division");
        expr_handle_free(handle);
    }
    
    /* Test operator precedence */
    ret = expr_compile(ctx, "2 + 3 * 4", 0, &handle);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Parsing precedence expression");
    if (ret == EXPR_SUCCESS) {
        expr_evaluate(handle, &result);
        TEST_ASSERT_EQUAL(14.0, result, "Evaluating precedence (2 + 3 * 4)");
        expr_handle_free(handle);
    }
    
    ret = expr_compile(ctx, "(2 + 3) * 4", 0, &handle);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Parsing parentheses expression");
    if (ret == EXPR_SUCCESS) {
        expr_evaluate(handle, &result);
        TEST_ASSERT_EQUAL(20.0, result, "Evaluating parentheses ((2 + 3) * 4)");
        expr_handle_free(handle);
    }
    
    /* Test unary operators */
    ret = expr_compile(ctx, "-5", 0, &handle);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Parsing unary minus");
    if (ret == EXPR_SUCCESS) {
        expr_evaluate(handle, &result);
        TEST_ASSERT_EQUAL(-5.0, result, "Evaluating unary minus");
        expr_handle_free(handle);
    }
    
    ret = expr_compile(ctx, "+7", 0, &handle);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Parsing unary plus");
    if (ret == EXPR_SUCCESS) {
        expr_evaluate(handle, &result);
        TEST_ASSERT_EQUAL(7.0, result, "Evaluating unary plus");
        expr_handle_free(handle);
    }
    
    expr_context_free(ctx);
}

/*
 * test_advanced_operators
 *
 * Tests power, modulo, and assignment operators.
 */
void test_advanced_operators(void)
{
    expr_context ctx;
    expr_handle handle;
    double result, var = 10.0;
    int ret;
    
    printf("\n=== Testing Advanced Operators ===\n");
    
    expr_context_new(&ctx);
    expr_add_variable(ctx, "x", &var, EXPR_VAR_READ_WRITE);
    
    /* Test power operator */
    ret = expr_compile(ctx, "2^3", EXPR_ENABLE_POWER, &handle);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Parsing power operator");
    if (ret == EXPR_SUCCESS) {
        expr_evaluate(handle, &result);
        TEST_ASSERT_EQUAL(8.0, result, "Evaluating power (2^3)");
        expr_handle_free(handle);
    }
    
    /* Test modulo operator */
    ret = expr_compile(ctx, "7 % 3", EXPR_ENABLE_MODULO, &handle);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Parsing modulo operator");
    if (ret == EXPR_SUCCESS) {
        expr_evaluate(handle, &result);
        TEST_ASSERT_EQUAL(1.0, result, "Evaluating modulo (7 % 3)");
        expr_handle_free(handle);
    }
    
    /* Test assignment */
    ret = expr_compile(ctx, "x = 20", 0, &handle);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Parsing assignment");
    if (ret == EXPR_SUCCESS) {
        expr_evaluate(handle, &result);
        TEST_ASSERT_EQUAL(20.0, result, "Evaluating assignment");
        TEST_ASSERT_EQUAL(20.0, var, "Variable updated by assignment");
        expr_handle_free(handle);
    }
    
    /* Test compound assignment */
    ret = expr_compile(ctx, "x += 5", EXPR_ENABLE_COMPOUND_ASSIGN, &handle);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Parsing compound assignment");
    if (ret == EXPR_SUCCESS) {
        expr_evaluate(handle, &result);
        TEST_ASSERT_EQUAL(25.0, result, "Evaluating compound assignment");
        TEST_ASSERT_EQUAL(25.0, var, "Variable updated by compound assignment");
        expr_handle_free(handle);
    }
    
    expr_context_free(ctx);
}

/*
 * test_functions
 *
 * Tests function calls with various argument counts.
 */
void test_functions(void)
{
    expr_context ctx;
    expr_handle handle;
    double result;
    int ret;
    
    printf("\n=== Testing Function Calls ===\n");
    
    expr_context_new(&ctx);
    expr_add_constant(ctx, "pi", 3.14159265359, 0);
    expr_add_function1(ctx, "sin", test_sin, EXPR_FUNC_PURE);
    expr_add_function1(ctx, "sqrt", test_sqrt, EXPR_FUNC_PURE);
    expr_add_function2(ctx, "pow", test_pow, EXPR_FUNC_PURE);
    expr_add_function0(ctx, "random", test_random, 0);
    
    /* Test zero-argument function */
    ret = expr_compile(ctx, "random()", 0, &handle);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Parsing zero-argument function");
    if (ret == EXPR_SUCCESS) {
        expr_evaluate(handle, &result);
        TEST_ASSERT(result >= 0.0 && result <= 1.0, "Random function returns valid range");
        expr_handle_free(handle);
    }
    
    /* Test single-argument function */
    ret = expr_compile(ctx, "sqrt(16)", 0, &handle);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Parsing single-argument function");
    if (ret == EXPR_SUCCESS) {
        expr_evaluate(handle, &result);
        TEST_ASSERT_EQUAL(4.0, result, "Evaluating sqrt(16)");
        expr_handle_free(handle);
    }
    
    /* Test two-argument function */
    ret = expr_compile(ctx, "pow(2, 3)", 0, &handle);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Parsing two-argument function");
    if (ret == EXPR_SUCCESS) {
        expr_evaluate(handle, &result);
        TEST_ASSERT_EQUAL(8.0, result, "Evaluating pow(2, 3)");
        expr_handle_free(handle);
    }
    
    /* Test nested function calls */
    ret = expr_compile(ctx, "sqrt(pow(3, 2) + pow(4, 2))", 0, &handle);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Parsing nested function calls");
    if (ret == EXPR_SUCCESS) {
        expr_evaluate(handle, &result);
        TEST_ASSERT_EQUAL(5.0, result, "Evaluating nested functions (Pythagorean)");
        expr_handle_free(handle);
    }
    
    expr_context_free(ctx);
}

/*
 * test_error_handling
 *
 * Tests various error conditions and reporting.
 */
void test_error_handling(void)
{
    expr_context ctx;
    expr_handle handle;
    double result;
    int ret;
    
    printf("\n=== Testing Error Handling ===\n");
    
    expr_context_new(&ctx);
    
    /* Test syntax errors */
    ret = expr_compile(ctx, "2 +", 0, &handle);
    TEST_ASSERT_ERROR(ret, EXPR_ERROR_PARSE, "Incomplete expression");
    
    ret = expr_compile(ctx, "2 + + 3", 0, &handle);
    TEST_ASSERT_ERROR(ret, EXPR_ERROR_PARSE, "Double operator");
    
    ret = expr_compile(ctx, "(2 + 3", 0, &handle);
    TEST_ASSERT_ERROR(ret, EXPR_ERROR_PARSE, "Missing closing parenthesis");
    
    ret = expr_compile(ctx, "2 + 3)", 0, &handle);
    TEST_ASSERT_ERROR(ret, EXPR_ERROR_PARSE, "Extra closing parenthesis");
    
    /* Test undefined symbols */
    ret = expr_compile(ctx, "undefined_var", 0, &handle);
    TEST_ASSERT_ERROR(ret, EXPR_ERROR_UNDEFINED_SYMBOL, "Undefined variable");
    
    ret = expr_compile(ctx, "unknown_func()", 0, &handle);
    TEST_ASSERT_ERROR(ret, EXPR_ERROR_UNDEFINED_SYMBOL, "Undefined function");
    
    /* Test division by zero */
    ret = expr_compile(ctx, "1 / 0", 0, &handle);
    if (ret == EXPR_SUCCESS) {
        ret = expr_evaluate(handle, &result);
        TEST_ASSERT_ERROR(ret, EXPR_ERROR_DIVISION_BY_ZERO, "Division by zero");
        expr_handle_free(handle);
    }
    
    /* Test empty expression */
    ret = expr_compile(ctx, "", 0, &handle);
    TEST_ASSERT_ERROR(ret, EXPR_ERROR_EMPTY_EXPR, "Empty expression");
    
    /* Test error position reporting */
    ret = expr_compile(ctx, "2 + unknown", 0, &handle);
    if (ret != EXPR_SUCCESS) {
        int pos = expr_error_position(ctx);
        TEST_ASSERT(pos == 4, "Error position reporting");
        printf("Error at position %d: %s\n", pos, expr_error(ctx));
    }
    
    expr_context_free(ctx);
}

/*
 * test_optimization
 *
 * Tests expression optimization functionality.
 */
void test_optimization(void)
{
    expr_context ctx;
    expr_handle handle;
    optimization_report_t report;
    double result;
    int ret;
    
    printf("\n=== Testing Expression Optimization ===\n");
    
    expr_context_new(&ctx);
    expr_add_function1(ctx, "sin", test_sin, EXPR_FUNC_PURE);
    
    /* Test constant folding */
    ret = expr_compile(ctx, "2 + 3 * 4", 0, &handle);
    if (ret == EXPR_SUCCESS) {
        ret = expr_optimize(&handle, &report);
        TEST_ASSERT(ret == EXPR_SUCCESS, "Expression optimization");
        
        expr_evaluate(handle, &result);
        TEST_ASSERT_EQUAL(14.0, result, "Optimized expression still evaluates correctly");
        
        printf("Optimization report:\n");
        printf("  Passes: %d\n", report.total_passes);
        printf("  Nodes: %d -> %d\n", report.original_nodes, report.final_nodes);
        printf("  Constants folded: %d\n", report.constants_folded);
        printf("  Time: %.3f ms\n", report.optimization_time_ms);
        if (report.summary)
            printf("  Summary: %s\n", report.summary);
        
        expr_free_optimization_report(&report);
        expr_handle_free(handle);
    }
    
    /* Test dead code elimination */
    ret = expr_compile(ctx, "x * 1 + 0", 0, &handle);
    if (ret == EXPR_SUCCESS) {
        ret = expr_optimize(&handle, &report);
        TEST_ASSERT(ret == EXPR_SUCCESS, "Dead code elimination");
        TEST_ASSERT(report.dead_code_eliminated > 0, "Dead code was eliminated");
        
        expr_free_optimization_report(&report);
        expr_handle_free(handle);
    }
    
    expr_context_free(ctx);
}

/*
 * test_performance
 *
 * Measures performance of compilation and evaluation.
 */
void test_performance(void)
{
    expr_context ctx;
    expr_handle handle, opt_handle;
    clock_t start, end;
    double result;
    int i, iterations = 10000;
    double compile_time, eval_time, opt_eval_time;
    
    printf("\n=== Performance Testing ===\n");
    
    expr_context_new(&ctx);
    expr_add_function1(ctx, "sin", test_sin, EXPR_FUNC_PURE);
    expr_add_function1(ctx, "cos", test_cos, EXPR_FUNC_PURE);
    expr_add_function1(ctx, "sqrt", test_sqrt, EXPR_FUNC_PURE);
    
    /* Add variable needed for performance test */
    double x_var = 1.5;
    expr_add_variable(ctx, "x", &x_var, EXPR_VAR_READABLE);
    
    /* Test compilation performance */
    start = clock();
    for (i = 0; i < iterations / 10; i++) {
        if (expr_compile(ctx, "sin(x) * cos(x) + sqrt(x * x + 1)", 0, &handle) == EXPR_SUCCESS) {
            expr_handle_free(handle);
        }
    }
    end = clock();
    compile_time = ((double)(end - start) / CLOCKS_PER_SEC) * 1000.0;
    printf("Compilation: %.3f ms for %d expressions (%.6f ms/expr)\n", 
           compile_time, iterations / 10, compile_time / (iterations / 10));
    
    /* Test evaluation performance */
    if (expr_compile(ctx, "2 * 3 + 4 * 5 - 6 / 2", 0, &handle) != EXPR_SUCCESS) {
        printf("Failed to compile evaluation test expression\n");
        expr_context_free(ctx);
        return;
    }
    
    start = clock();
    for (i = 0; i < iterations; i++) {
        expr_evaluate(handle, &result);
    }
    end = clock();
    eval_time = ((double)(end - start) / CLOCKS_PER_SEC) * 1000.0;
    printf("Evaluation: %.3f ms for %d evaluations (%.6f ms/eval)\n", 
           eval_time, iterations, eval_time / iterations);
    
    /* Test optimized evaluation performance */
    opt_handle = handle;
    expr_optimize(&opt_handle, NULL);
    
    start = clock();
    for (i = 0; i < iterations; i++) {
        expr_evaluate(opt_handle, &result);
    }
    end = clock();
    opt_eval_time = ((double)(end - start) / CLOCKS_PER_SEC) * 1000.0;
    printf("Optimized evaluation: %.3f ms for %d evaluations (%.6f ms/eval)\n", 
           opt_eval_time, iterations, opt_eval_time / iterations);
    
    printf("Optimization speedup: %.2fx\n", eval_time / opt_eval_time);
    
    expr_handle_free(handle);
    expr_context_free(ctx);
}

/*
 * test_edge_cases
 *
 * Tests edge cases and corner conditions.
 */
void test_edge_cases(void)
{
    expr_context ctx;
    expr_handle handle;
    double result, var = 0.0;
    int ret;
    
    printf("\n=== Testing Edge Cases ===\n");
    
    expr_context_new(&ctx);
    expr_add_variable(ctx, "x", &var, EXPR_VAR_READ_WRITE);
    expr_add_constant(ctx, "zero", 0.0, 0);
    
    /* Test hexadecimal numbers */
    ret = expr_compile(ctx, "0x10", 0, &handle);
    if (ret == EXPR_SUCCESS) {
        expr_evaluate(handle, &result);
        TEST_ASSERT_EQUAL(16.0, result, "Hexadecimal number parsing");
        expr_handle_free(handle);
    }
    
    /* Test very large and small numbers */
    ret = expr_compile(ctx, "1e10", 0, &handle);
    if (ret == EXPR_SUCCESS) {
        expr_evaluate(handle, &result);
        TEST_ASSERT_EQUAL(1e10, result, "Large number parsing");
        expr_handle_free(handle);
    }
    
    ret = expr_compile(ctx, "1e-10", 0, &handle);
    if (ret == EXPR_SUCCESS) {
        expr_evaluate(handle, &result);
        TEST_ASSERT_EQUAL(1e-10, result, "Small number parsing");
        expr_handle_free(handle);
    }
    
    /* Test whitespace handling */
    ret = expr_compile(ctx, "  2  +  3  ", 0, &handle);
    if (ret == EXPR_SUCCESS) {
        expr_evaluate(handle, &result);
        TEST_ASSERT_EQUAL(5.0, result, "Whitespace handling");
        expr_handle_free(handle);
    }
    
    /* Test complex expressions */
    ret = expr_compile(ctx, "((2 + 3) * (4 - 1)) / (5 + 2)", 0, &handle);
    if (ret == EXPR_SUCCESS) {
        expr_evaluate(handle, &result);
        TEST_ASSERT_EQUAL(15.0/7.0, result, "Complex nested expression");
        expr_handle_free(handle);
    }
    
    expr_context_free(ctx);
}

/*
 * test_convenience_functions
 *
 * Tests the expr_easy convenience function.
 */
void test_convenience_functions(void)
{
    expr_context ctx;
    double result;
    double x = 5.0, y = 3.0;
    int ret;
    
    printf("\n=== Testing Convenience Functions ===\n");
    
    expr_context_new(&ctx);
    expr_add_variable(ctx, "x", &x, EXPR_VAR_READABLE);
    expr_add_variable(ctx, "y", &y, EXPR_VAR_READABLE);
    expr_add_function1(ctx, "sqrt", test_sqrt, EXPR_FUNC_PURE);
    
    /* Test basic expr_easy functionality */
    ret = expr_easy(ctx, "2 + 3", &result);
    TEST_ASSERT(ret == EXPR_SUCCESS, "expr_easy compilation");
    TEST_ASSERT_EQUAL(5.0, result, "expr_easy basic arithmetic");
    
    /* Test expr_easy with variables */
    ret = expr_easy(ctx, "x * 2 + y", &result);
    TEST_ASSERT(ret == EXPR_SUCCESS, "expr_easy with variables");
    TEST_ASSERT_EQUAL(13.0, result, "expr_easy variable evaluation");
    
    /* Test expr_easy with functions */
    ret = expr_easy(ctx, "sqrt(16) + 2", &result);
    TEST_ASSERT(ret == EXPR_SUCCESS, "expr_easy with functions");
    TEST_ASSERT_EQUAL(6.0, result, "expr_easy function evaluation");
    
    /* Test expr_easy complex expression */
    ret = expr_easy(ctx, "x * x + 2 * x + 1", &result);
    TEST_ASSERT(ret == EXPR_SUCCESS, "expr_easy complex expression");
    TEST_ASSERT_EQUAL(36.0, result, "expr_easy complex evaluation");
    
    /* Test expr_easy error handling - invalid expression */
    ret = expr_easy(ctx, "2 +", &result);
    TEST_ASSERT_ERROR(ret, EXPR_ERROR_PARSE, "expr_easy parse error");
    
    /* Test expr_easy error handling - undefined variable */
    ret = expr_easy(ctx, "undefined_var + 1", &result);
    TEST_ASSERT_ERROR(ret, EXPR_ERROR_UNDEFINED_SYMBOL, "expr_easy undefined symbol");
    
    /* Test expr_easy parameter validation */
    ret = expr_easy(NULL, "2 + 3", &result);
    TEST_ASSERT_ERROR(ret, EXPR_ERROR_INVALID_PARAM, "expr_easy NULL context");
    
    ret = expr_easy(ctx, NULL, &result);
    TEST_ASSERT_ERROR(ret, EXPR_ERROR_INVALID_PARAM, "expr_easy NULL expression");
    
    ret = expr_easy(ctx, "2 + 3", NULL);
    TEST_ASSERT_ERROR(ret, EXPR_ERROR_INVALID_PARAM, "expr_easy NULL result");
    
    expr_context_free(ctx);
}

/*
 * test_batch_symbol_addition
 *
 * Tests the batch symbol addition functions (add_*_list).
 */
void test_batch_symbol_addition(void)
{
    expr_context ctx;
    expr_handle handle;
    double result;
    int ret;
    
    printf("\n=== Testing Batch Symbol Addition ===\n");
    
    expr_context_new(&ctx);
    
    /* Test variables for variable list */
    double x = 10.0, y = 20.0, z = 30.0;
    
    /* Test expr_add_constant_list */
    expr_constant_entry_t constants[] = {
        {"pi", 3.14159265359, 0},
        {"e", 2.71828182846, 0},
        {"golden", 1.61803398875, 0}
    };
    
    ret = expr_add_constant_list(ctx, 3, constants);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Adding constant list");
    
    /* Verify constants were added */
    ret = expr_easy(ctx, "pi + e", &result);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Using constants from list");
    TEST_ASSERT_EQUAL(3.14159265359 + 2.71828182846, result, "Constants list values");
    
    /* Test expr_add_variable_list */
    expr_variable_entry_t variables[] = {
        {"x", &x, EXPR_VAR_READ_WRITE},
        {"y", &y, EXPR_VAR_READABLE},
        {"z", &z, EXPR_VAR_READ_WRITE}
    };
    
    ret = expr_add_variable_list(ctx, 3, variables);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Adding variable list");
    
    /* Verify variables were added */
    ret = expr_easy(ctx, "x + y + z", &result);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Using variables from list");
    TEST_ASSERT_EQUAL(60.0, result, "Variables list values");
    
    /* Test expr_add_function1_list */
    expr_function1_entry_t functions1[] = {
        {"sin", test_sin, EXPR_FUNC_PURE},
        {"cos", test_cos, EXPR_FUNC_PURE},
        {"sqrt", test_sqrt, EXPR_FUNC_PURE}
    };
    
    ret = expr_add_function1_list(ctx, 3, functions1);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Adding function1 list");
    
    /* Verify functions were added */
    ret = expr_easy(ctx, "sqrt(16)", &result);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Using function1 from list");
    TEST_ASSERT_EQUAL(4.0, result, "Function1 list evaluation");
    
    /* Test expr_add_function2_list */
    expr_function2_entry_t functions2[] = {
        {"pow", test_pow, EXPR_FUNC_PURE},
        {"min", test_min, EXPR_FUNC_PURE},
        {"max", test_max, EXPR_FUNC_PURE}
    };
    
    ret = expr_add_function2_list(ctx, 3, functions2);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Adding function2 list");
    
    /* Verify functions were added */
    ret = expr_easy(ctx, "pow(2, 3)", &result);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Using function2 from list");
    TEST_ASSERT_EQUAL(8.0, result, "Function2 list evaluation");
    
    ret = expr_easy(ctx, "min(10, 5)", &result);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Using min function from list");
    TEST_ASSERT_EQUAL(5.0, result, "Min function from list");
    
    /* Test expr_add_function0_list */
    expr_function0_entry_t functions0[] = {
        {"random", test_random, 0},
        {"get_pi", test_get_pi, EXPR_FUNC_PURE}
    };
    
    ret = expr_add_function0_list(ctx, 2, functions0);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Adding function0 list");
    
    /* Verify function0s were added */
    ret = expr_easy(ctx, "get_pi()", &result);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Using function0 from list");
    TEST_ASSERT_EQUAL(3.14159265359, result, "Function0 list evaluation");
    
    /* Test error handling - NULL list */
    ret = expr_add_constant_list(ctx, 3, NULL);
    TEST_ASSERT_ERROR(ret, EXPR_ERROR_INVALID_PARAM, "NULL constant list");
    
    /* Test error handling - zero count */
    ret = expr_add_variable_list(ctx, 0, variables);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Zero count variable list (should succeed)");
    
    /* Test error handling - duplicate symbols */
    expr_constant_entry_t duplicate_constants[] = {
        {"pi", 3.0, 0}  /* pi already exists */
    };
    
    ret = expr_add_constant_list(ctx, 1, duplicate_constants);
    TEST_ASSERT_ERROR(ret, EXPR_ERROR_SYMBOL_EXISTS, "Duplicate symbol in list");
    
    /* Test complex expression using list symbols */
    ret = expr_easy(ctx, "sqrt(pow(x, 2) + pow(y, 2)) + pi", &result);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Complex expression with list symbols");
    TEST_ASSERT_EQUAL(sqrt(100 + 400) + 3.14159265359, result, "Complex list expression result");
    
    expr_context_free(ctx);
}

/*
 * test_performance_comparison
 *
 * Compares performance of individual vs batch symbol addition.
 */
void test_performance_comparison(void)
{
    expr_context ctx1, ctx2;
    clock_t start, end;
    double individual_time, batch_time;
    int i, iterations = 1000;
    
    printf("\n=== Testing Performance Comparison ===\n");
    
    /* Test individual additions */
    start = clock();
    for (i = 0; i < iterations; i++) {
        expr_context_new(&ctx1);
        
        expr_add_constant(ctx1, "pi", 3.14159, 0);
        expr_add_constant(ctx1, "e", 2.71828, 0);
        expr_add_constant(ctx1, "golden", 1.61803, 0);
        
        expr_add_function1(ctx1, "sin", test_sin, EXPR_FUNC_PURE);
        expr_add_function1(ctx1, "cos", test_cos, EXPR_FUNC_PURE);
        expr_add_function1(ctx1, "sqrt", test_sqrt, EXPR_FUNC_PURE);
        
        expr_context_free(ctx1);
    }
    end = clock();
    individual_time = ((double)(end - start) / CLOCKS_PER_SEC) * 1000.0;
    
    /* Test batch additions */
    start = clock();
    for (i = 0; i < iterations; i++) {
        expr_context_new(&ctx2);
        
        expr_constant_entry_t constants[] = {
            {"pi", 3.14159, 0},
            {"e", 2.71828, 0},
            {"golden", 1.61803, 0}
        };
        expr_add_constant_list(ctx2, 3, constants);
        
        expr_function1_entry_t functions[] = {
            {"sin", test_sin, EXPR_FUNC_PURE},
            {"cos", test_cos, EXPR_FUNC_PURE},
            {"sqrt", test_sqrt, EXPR_FUNC_PURE}
        };
        expr_add_function1_list(ctx2, 3, functions);
        
        expr_context_free(ctx2);
    }
    end = clock();
    batch_time = ((double)(end - start) / CLOCKS_PER_SEC) * 1000.0;
    
    printf("Individual additions: %.3f ms for %d iterations (%.6f ms/iter)\n",
           individual_time, iterations, individual_time / iterations);
    printf("Batch additions: %.3f ms for %d iterations (%.6f ms/iter)\n",
           batch_time, iterations, batch_time / iterations);
    
    if (batch_time < individual_time) {
        printf("Batch additions are %.2fx faster\n", individual_time / batch_time);
    } else {
        printf("Individual additions are %.2fx faster\n", batch_time / individual_time);
    }
    
    /* Both should work correctly */
    TEST_ASSERT(individual_time > 0 && batch_time > 0, "Performance test completed");
}

/*
 * test_semicolon_sequences
 *
 * Tests semicolon/sequence operator functionality including various edge cases
 * and error conditions to ensure proper compilation and evaluation behavior.
 *
 * Inputs: None
 * Outputs: None  
 * Side effects: Prints test results and updates global test counters
 *
 * Key dependencies: expr_* API functions
 *
 * Tests basic sequences, empty expressions, nested sequences, and EXPR_ALLOW_SEMICOLON
 * option enforcement with comprehensive coverage of sequence operator behavior.
 */
void
test_semicolon_sequences(void)
{
    expr_context ctx;
    expr_handle handle;
    double result;
    int ret;
    
    printf("\n=== Testing Semicolon/Sequence Operator ===\n");
    
    /* Initialize context */
    ret = expr_context_new(&ctx);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Context creation for semicolon tests");
    
    /* Add basic variables for testing */
    double x = 0.0, y = 0.0;
    expr_add_variable(ctx, "x", &x, EXPR_VAR_READ_WRITE);
    expr_add_variable(ctx, "y", &y, EXPR_VAR_READ_WRITE);
    
    /* Test 1: Basic sequence with EXPR_ALLOW_SEMICOLON */
    ret = expr_compile(ctx, "x = 5; y = 10; x + y", EXPR_ALLOW_SEMICOLON, &handle);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Compile basic sequence with semicolons");
    if (ret == EXPR_SUCCESS) {
        ret = expr_evaluate(handle, &result);
        TEST_ASSERT_EQUAL(15.0, result, "Evaluate basic sequence: x=5; y=10; x+y");
        expr_handle_free(handle);
    }
    
    /* Test 2: Sequence without EXPR_ALLOW_SEMICOLON should fail */
    ret = expr_compile(ctx, "x = 5; y = 10", 0, &handle);
    TEST_ASSERT(ret != EXPR_SUCCESS, "Sequence compilation fails without EXPR_ALLOW_SEMICOLON");
    
    /* Test 3: Empty expression (just semicolons) */
    ret = expr_compile(ctx, ";;;", EXPR_ALLOW_SEMICOLON, &handle);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Compile empty sequence (just semicolons)");
    if (ret == EXPR_SUCCESS) {
        ret = expr_evaluate(handle, &result);
        TEST_ASSERT(ret == EXPR_SUCCESS && isnan(result), "Empty sequence evaluates to NaN");
        expr_handle_free(handle);
    }
    
    /* Test 4: Single semicolon */
    ret = expr_compile(ctx, ";", EXPR_ALLOW_SEMICOLON, &handle);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Compile single semicolon");
    if (ret == EXPR_SUCCESS) {
        ret = expr_evaluate(handle, &result);
        TEST_ASSERT(ret == EXPR_SUCCESS && isnan(result), "Single semicolon evaluates to NaN");
        expr_handle_free(handle);
    }
    
    /* Test 5: Expression ending with semicolon */
    ret = expr_compile(ctx, "x = 42;", EXPR_ALLOW_SEMICOLON, &handle);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Compile expression ending with semicolon");
    if (ret == EXPR_SUCCESS) {
        ret = expr_evaluate(handle, &result);
        TEST_ASSERT_EQUAL(42.0, result, "Expression ending with semicolon: x=42;");
        expr_handle_free(handle);
    }
    
    /* Test 6: Multiple assignments in sequence */
    ret = expr_compile(ctx, "x = 1; y = x + 2; x = y * 3; x + y", EXPR_ALLOW_SEMICOLON, &handle);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Compile multiple assignments in sequence");
    if (ret == EXPR_SUCCESS) {
        ret = expr_evaluate(handle, &result);
        TEST_ASSERT_EQUAL(12.0, result, "Multiple assignments: x=1; y=x+2; x=y*3; x+y");
        expr_handle_free(handle);
    }
    
    /* Test 7: Arithmetic operations between assignments */
    ret = expr_compile(ctx, "x = 10; 5 + 3; y = x * 2; y - 5", EXPR_ALLOW_SEMICOLON, &handle);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Compile arithmetic between assignments");
    if (ret == EXPR_SUCCESS) {
        ret = expr_evaluate(handle, &result);
        TEST_ASSERT_EQUAL(15.0, result, "Arithmetic between assignments");
        expr_handle_free(handle);
    }
    
    /* Test 8: Empty subexpressions in sequence */
    ret = expr_compile(ctx, "; x = 7; ; y = 14; ;", EXPR_ALLOW_SEMICOLON, &handle);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Compile sequence with empty subexpressions");
    if (ret == EXPR_SUCCESS) {
        ret = expr_evaluate(handle, &result);
        TEST_ASSERT_EQUAL(14.0, result, "Sequence with empty subexpressions");
        expr_handle_free(handle);
    }
    
    expr_context_free(ctx);
    printf("Semicolon/sequence operator tests completed.\n");
}

/*
 * test_compilation_options
 *
 * Tests all compilation option flags to verify they properly control
 * expression parsing behavior and enforce restrictions as documented.
 *
 * Inputs: None
 * Outputs: None
 * Side effects: Prints test results and updates global test counters
 *
 * Key dependencies: expr_* API functions and compilation option constants
 *
 * Comprehensively tests EXPR_SIMPLE_OPERATORS, EXPR_ENABLE_POWER,
 * EXPR_ENABLE_MODULO, and EXPR_ENABLE_COMPOUND_ASSIGN option enforcement.
 */
void
test_compilation_options(void)
{
    expr_context ctx;
    expr_handle handle;
    double result;
    int ret;
    
    printf("\n=== Testing Compilation Options ===\n");
    
    /* Initialize context */
    ret = expr_context_new(&ctx);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Context creation for compilation options tests");
    
    double x = 5.0;
    expr_add_variable(ctx, "x", &x, EXPR_VAR_READ_WRITE);
    
    /* Test EXPR_SIMPLE_OPERATORS flag */
    printf("\n--- Testing EXPR_SIMPLE_OPERATORS ---\n");
    
    /* Test 1: Simple operators should work with EXPR_SIMPLE_OPERATORS */
    ret = expr_compile(ctx, "2 + 3 * 4 - 1", EXPR_SIMPLE_OPERATORS, &handle);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Simple operators work with EXPR_SIMPLE_OPERATORS");
    if (ret == EXPR_SUCCESS) {
        ret = expr_evaluate(handle, &result);
        TEST_ASSERT_EQUAL(13.0, result, "Simple operators: 2 + 3 * 4 - 1");
        expr_handle_free(handle);
    }
    
    /* Test 2: Power operator should fail with EXPR_SIMPLE_OPERATORS */
    ret = expr_compile(ctx, "2 ^ 3", EXPR_SIMPLE_OPERATORS, &handle);
    TEST_ASSERT(ret != EXPR_SUCCESS, "Power operator fails with EXPR_SIMPLE_OPERATORS");
    
    /* Test 3: Modulo operator should fail with EXPR_SIMPLE_OPERATORS */
    ret = expr_compile(ctx, "7 % 3", EXPR_SIMPLE_OPERATORS, &handle);
    TEST_ASSERT(ret != EXPR_SUCCESS, "Modulo operator fails with EXPR_SIMPLE_OPERATORS");
    
    /* Test EXPR_ENABLE_POWER flag */
    printf("\n--- Testing EXPR_ENABLE_POWER ---\n");
    
    /* Test 4: Power operator works with EXPR_ENABLE_POWER */
    ret = expr_compile(ctx, "2 ^ 3", EXPR_ENABLE_POWER, &handle);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Power operator works with EXPR_ENABLE_POWER");
    if (ret == EXPR_SUCCESS) {
        ret = expr_evaluate(handle, &result);
        TEST_ASSERT_EQUAL(8.0, result, "Power operator: 2 ^ 3");
        expr_handle_free(handle);
    }
    
    /* Test 5: Power operator fails without EXPR_ENABLE_POWER */
    ret = expr_compile(ctx, "2 ^ 3", 0, &handle);
    TEST_ASSERT(ret != EXPR_SUCCESS, "Power operator fails without EXPR_ENABLE_POWER");
    
    /* Test EXPR_ENABLE_MODULO flag */
    printf("\n--- Testing EXPR_ENABLE_MODULO ---\n");
    
    /* Test 6: Modulo operator works with EXPR_ENABLE_MODULO */
    ret = expr_compile(ctx, "7 % 3", EXPR_ENABLE_MODULO, &handle);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Modulo operator works with EXPR_ENABLE_MODULO");
    if (ret == EXPR_SUCCESS) {
        ret = expr_evaluate(handle, &result);
        TEST_ASSERT_EQUAL(1.0, result, "Modulo operator: 7 % 3");
        expr_handle_free(handle);
    }
    
    /* Test 7: Modulo operator fails without EXPR_ENABLE_MODULO */
    ret = expr_compile(ctx, "7 % 3", 0, &handle);
    TEST_ASSERT(ret != EXPR_SUCCESS, "Modulo operator fails without EXPR_ENABLE_MODULO");
    
    /* Test EXPR_ENABLE_COMPOUND_ASSIGN flag */
    printf("\n--- Testing EXPR_ENABLE_COMPOUND_ASSIGN ---\n");
    
    /* Test 8: Compound assignment works with EXPR_ENABLE_COMPOUND_ASSIGN */
    ret = expr_compile(ctx, "x += 10", EXPR_ENABLE_COMPOUND_ASSIGN, &handle);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Compound assignment works with EXPR_ENABLE_COMPOUND_ASSIGN");
    if (ret == EXPR_SUCCESS) {
        ret = expr_evaluate(handle, &result);
        TEST_ASSERT_EQUAL(15.0, result, "Compound assignment: x += 10");
        expr_handle_free(handle);
    }
    
    /* Test 9: Compound assignment fails without EXPR_ENABLE_COMPOUND_ASSIGN */
    ret = expr_compile(ctx, "x += 10", 0, &handle);
    TEST_ASSERT(ret != EXPR_SUCCESS, "Compound assignment fails without EXPR_ENABLE_COMPOUND_ASSIGN");
    
    /* Test 10: Multiple compound assignment operators */
    x = 10.0;
    ret = expr_compile(ctx, "x *= 2", EXPR_ENABLE_COMPOUND_ASSIGN, &handle);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Multiply-assign works with EXPR_ENABLE_COMPOUND_ASSIGN");
    if (ret == EXPR_SUCCESS) {
        ret = expr_evaluate(handle, &result);
        TEST_ASSERT_EQUAL(20.0, result, "Multiply-assign: x *= 2");
        expr_handle_free(handle);
    }
    
    /* Test 11: Power compound assignment (requires both flags) */
    x = 2.0;
    ret = expr_compile(ctx, "x ^= 3", EXPR_ENABLE_POWER | EXPR_ENABLE_COMPOUND_ASSIGN, &handle);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Power-assign works with both flags");
    if (ret == EXPR_SUCCESS) {
        ret = expr_evaluate(handle, &result);
        TEST_ASSERT_EQUAL(8.0, result, "Power-assign: x ^= 3");
        expr_handle_free(handle);
    }
    
    /* Test 12: Power compound assignment fails with only compound flag */
    ret = expr_compile(ctx, "x ^= 3", EXPR_ENABLE_COMPOUND_ASSIGN, &handle);
    TEST_ASSERT(ret != EXPR_SUCCESS, "Power-assign fails without EXPR_ENABLE_POWER");
    
    /* Test 13: Combined options */
    ret = expr_compile(ctx, "2 + 3 ^ 2 % 5", EXPR_ENABLE_POWER | EXPR_ENABLE_MODULO, &handle);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Combined operators work with multiple flags");
    if (ret == EXPR_SUCCESS) {
        ret = expr_evaluate(handle, &result);
        TEST_ASSERT_EQUAL(6.0, result, "Combined operators: 2 + 3 ^ 2 % 5");
        expr_handle_free(handle);
    }
    
    expr_context_free(ctx);
    printf("Compilation options tests completed.\n");
}

/*
 * test_utf8_symbol_names
 *
 * Tests UTF-8 symbol name support for variables, constants, and functions
 * to verify international character support as specified in the requirements.
 *
 * Inputs: None
 * Outputs: None
 * Side effects: Prints test results and updates global test counters
 *
 * Key dependencies: expr_* API functions and UTF-8 identifier validation
 *
 * Tests various UTF-8 characters, multi-byte sequences, and mixed ASCII/UTF-8 names.
 */
void
test_utf8_symbol_names(void)
{
    expr_context ctx;
    expr_handle handle;
    double result;
    int ret;
    
    printf("\n=== Testing UTF-8 Symbol Names ===\n");
    
    /* Initialize context */
    ret = expr_context_new(&ctx);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Context creation for UTF-8 tests");
    
    /* Test 1: Basic UTF-8 constant names */
    printf("\n--- Testing UTF-8 Constants ---\n");
    ret = expr_add_constant(ctx, "π", 3.14159265359, 0);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Add UTF-8 constant π");
    
    ret = expr_add_constant(ctx, "α", 1.61803398875, 0);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Add UTF-8 constant α");
    
    ret = expr_add_constant(ctx, "β", 2.71828182846, 0);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Add UTF-8 constant β");
    
    /* Test 2: Use UTF-8 constants in expressions */
    ret = expr_compile(ctx, "π + α", 0, &handle);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Compile expression with UTF-8 constants");
    if (ret == EXPR_SUCCESS) {
        ret = expr_evaluate(handle, &result);
        TEST_ASSERT_EQUAL(4.75962664234, result, "Evaluate UTF-8 expression: π + α");
        expr_handle_free(handle);
    }
    
    /* Test 3: UTF-8 variable names */
    printf("\n--- Testing UTF-8 Variables ---\n");
    double θ = 1.5708, φ = 0.7854;
    ret = expr_add_variable(ctx, "θ", &θ, EXPR_VAR_READ_WRITE);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Add UTF-8 variable θ");
    
    ret = expr_add_variable(ctx, "φ", &φ, EXPR_VAR_READ_WRITE);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Add UTF-8 variable φ");
    
    /* Test 4: UTF-8 variables in calculations */
    ret = expr_compile(ctx, "θ * φ", 0, &handle);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Compile expression with UTF-8 variables");
    if (ret == EXPR_SUCCESS) {
        ret = expr_evaluate(handle, &result);
        TEST_ASSERT_EQUAL(1.23370632, result, "Evaluate UTF-8 variables: θ * φ");
        expr_handle_free(handle);
    }
    
    /* Test 5: Assignment to UTF-8 variables */
    ret = expr_compile(ctx, "θ = π / 2", 0, &handle);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Compile UTF-8 assignment");
    if (ret == EXPR_SUCCESS) {
        ret = expr_evaluate(handle, &result);
        TEST_ASSERT_EQUAL(1.5707963267944966, result, "Assign to UTF-8 variable: θ = π/2");
        TEST_ASSERT_EQUAL(1.5707963267944966, θ, "UTF-8 variable updated");
        expr_handle_free(handle);
    }
    
    /* Test 6: Mixed ASCII and UTF-8 names */
    printf("\n--- Testing Mixed ASCII/UTF-8 Names ---\n");
    ret = expr_add_constant(ctx, "speed_of_light_c", 299792458.0, 0);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Add ASCII constant");
    
    double température = 20.0;
    ret = expr_add_variable(ctx, "température", &température, EXPR_VAR_READ_WRITE);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Add UTF-8 variable température");
    
    ret = expr_compile(ctx, "température + speed_of_light_c / 1000000", 0, &handle);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Compile mixed ASCII/UTF-8 expression");
    if (ret == EXPR_SUCCESS) {
        ret = expr_evaluate(handle, &result);
        TEST_ASSERT_EQUAL(319.792458, result, "Evaluate mixed names expression");
        expr_handle_free(handle);
    }
    
    /* Test 7: UTF-8 with periods and underscores */
    printf("\n--- Testing UTF-8 with Special Characters ---\n");
    double δ_time = 0.001;
    ret = expr_add_variable(ctx, "δ_time", &δ_time, EXPR_VAR_READ_WRITE);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Add UTF-8 variable with underscore");
    
    ret = expr_add_constant(ctx, "μ.coefficient", 0.8, 0);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Add UTF-8 constant with period");
    
    ret = expr_compile(ctx, "δ_time * μ.coefficient", 0, &handle);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Compile UTF-8 with special chars");
    if (ret == EXPR_SUCCESS) {
        ret = expr_evaluate(handle, &result);
        TEST_ASSERT_EQUAL(0.0008, result, "Evaluate UTF-8 special chars");
        expr_handle_free(handle);
    }
    
    /* Test 8: Case sensitivity with UTF-8 */
    printf("\n--- Testing UTF-8 Case Sensitivity ---\n");
    ret = expr_add_constant(ctx, "Δ", 5.0, 0);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Add uppercase UTF-8 constant Δ");
    
    ret = expr_add_constant(ctx, "δ", 3.0, 0);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Add lowercase UTF-8 constant δ");
    
    ret = expr_compile(ctx, "Δ + δ", 0, &handle);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Compile case-sensitive UTF-8");
    if (ret == EXPR_SUCCESS) {
        ret = expr_evaluate(handle, &result);
        TEST_ASSERT_EQUAL(8.0, result, "UTF-8 case sensitivity: Δ + δ");
        expr_handle_free(handle);
    }
    
    /* Test 9: UTF-8 function names (using function1) */
    printf("\n--- Testing UTF-8 Function Names ---\n");
    ret = expr_add_function1(ctx, "√", test_sqrt, EXPR_FUNC_PURE);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Add UTF-8 function √");
    
    ret = expr_compile(ctx, "√(16)", 0, &handle);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Compile UTF-8 function call");
    if (ret == EXPR_SUCCESS) {
        ret = expr_evaluate(handle, &result);
        TEST_ASSERT_EQUAL(4.0, result, "UTF-8 function call: √(16)");
        expr_handle_free(handle);
    }
    
    /* Test 10: Complex UTF-8 expression */
    ret = expr_compile(ctx, "√(π * α) + β - δ_time", 0, &handle);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Compile complex UTF-8 expression");
    if (ret == EXPR_SUCCESS) {
        ret = expr_evaluate(handle, &result);
        TEST_ASSERT_EQUAL(4.97187795466884, result, "Complex UTF-8 expression evaluation");
        expr_handle_free(handle);
    }
    
    expr_context_free(ctx);
    printf("UTF-8 symbol names tests completed.\n");
}

/*
 * test_function3_function4
 *
 * Tests 3-argument and 4-argument function support to ensure complete
 * function call capability as specified in the API requirements.
 *
 * Inputs: None
 * Outputs: None
 * Side effects: Prints test results and updates global test counters
 *
 * Key dependencies: expr_* API functions for function3/function4 operations
 *
 * Tests function addition, compilation, evaluation, error handling, and edge cases.
 */

/* Test helper functions for 3 and 4 argument functions */
double test_lerp3(double a, double b, double t) {
    return a + t * (b - a);  /* Linear interpolation */
}

double test_clamp3(double value, double min, double max) {
    if (value < min) return min;
    if (value > max) return max;
    return value;
}

double test_distance3d(double x, double y, double z) {
    return sqrt(x*x + y*y + z*z);  /* 3D distance from origin */
}

double test_bilinear4(double x, double y, double a, double b) {
    return x * y * a + (1-x) * (1-y) * b;  /* Simplified bilinear interpolation */
}

double test_rect_area4(double x1, double y1, double x2, double y2) {
    return fabs((x2 - x1) * (y2 - y1));  /* Rectangle area */
}

double test_polynomial4(double x, double a, double b, double c) {
    return a*x*x*x + b*x*x + c*x;  /* Cubic polynomial (missing constant term) */
}

void
test_function3_function4(void)
{
    expr_context ctx;
    expr_handle handle;
    double result;
    int ret;
    
    printf("\n=== Testing Function3 and Function4 Support ===\n");
    
    /* Initialize context */
    ret = expr_context_new(&ctx);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Context creation for function3/4 tests");
    
    /* Test 1: Basic function3 addition */
    printf("\n--- Testing Function3 Operations ---\n");
    ret = expr_add_function3(ctx, "lerp", test_lerp3, EXPR_FUNC_PURE);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Add function3: lerp");
    
    ret = expr_add_function3(ctx, "clamp", test_clamp3, EXPR_FUNC_PURE);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Add function3: clamp");
    
    ret = expr_add_function3(ctx, "dist3d", test_distance3d, EXPR_FUNC_PURE);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Add function3: dist3d");
    
    /* Test 2: Function3 compilation and evaluation */
    ret = expr_compile(ctx, "lerp(0, 10, 0.5)", 0, &handle);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Compile function3: lerp(0, 10, 0.5)");
    if (ret == EXPR_SUCCESS) {
        ret = expr_evaluate(handle, &result);
        TEST_ASSERT_EQUAL(5.0, result, "Evaluate function3 lerp");
        expr_handle_free(handle);
    }
    
    ret = expr_compile(ctx, "clamp(15, 0, 10)", 0, &handle);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Compile function3: clamp(15, 0, 10)");
    if (ret == EXPR_SUCCESS) {
        ret = expr_evaluate(handle, &result);
        TEST_ASSERT_EQUAL(10.0, result, "Evaluate function3 clamp");
        expr_handle_free(handle);
    }
    
    ret = expr_compile(ctx, "dist3d(3, 4, 0)", 0, &handle);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Compile function3: dist3d(3, 4, 0)");
    if (ret == EXPR_SUCCESS) {
        ret = expr_evaluate(handle, &result);
        TEST_ASSERT_EQUAL(5.0, result, "Evaluate function3 dist3d");
        expr_handle_free(handle);
    }
    
    /* Test 3: Basic function4 addition */
    printf("\n--- Testing Function4 Operations ---\n");
    ret = expr_add_function4(ctx, "bilinear", test_bilinear4, EXPR_FUNC_PURE);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Add function4: bilinear");
    
    ret = expr_add_function4(ctx, "rect_area", test_rect_area4, EXPR_FUNC_PURE);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Add function4: rect_area");
    
    ret = expr_add_function4(ctx, "poly3", test_polynomial4, EXPR_FUNC_PURE);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Add function4: poly3");
    
    /* Test 4: Function4 compilation and evaluation */
    ret = expr_compile(ctx, "bilinear(0.5, 0.5, 2, 8)", 0, &handle);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Compile function4: bilinear(0.5, 0.5, 2, 8)");
    if (ret == EXPR_SUCCESS) {
        ret = expr_evaluate(handle, &result);
        TEST_ASSERT_EQUAL(2.5, result, "Evaluate function4 bilinear");
        expr_handle_free(handle);
    }
    
    ret = expr_compile(ctx, "rect_area(0, 0, 3, 4)", 0, &handle);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Compile function4: rect_area(0, 0, 3, 4)");
    if (ret == EXPR_SUCCESS) {
        ret = expr_evaluate(handle, &result);
        TEST_ASSERT_EQUAL(12.0, result, "Evaluate function4 rect_area");
        expr_handle_free(handle);
    }
    
    ret = expr_compile(ctx, "poly3(2, 1, 2, 3)", 0, &handle);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Compile function4: poly3(2, 1, 2, 3)");
    if (ret == EXPR_SUCCESS) {
        ret = expr_evaluate(handle, &result);
        TEST_ASSERT_EQUAL(22.0, result, "Evaluate function4 poly3");
        expr_handle_free(handle);
    }
    
    /* Test 5: Mixed function calls with expressions */
    printf("\n--- Testing Mixed Function3/4 Expressions ---\n");
    ret = expr_compile(ctx, "lerp(0, rect_area(0, 0, 2, 3), 0.5)", 0, &handle);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Compile mixed function3/4 expression");
    if (ret == EXPR_SUCCESS) {
        ret = expr_evaluate(handle, &result);
        TEST_ASSERT_EQUAL(3.0, result, "Evaluate mixed function expression");
        expr_handle_free(handle);
    }
    
    /* Test 6: Nested function3/4 calls */
    ret = expr_compile(ctx, "clamp(dist3d(3, 4, 5), 2, 8)", 0, &handle);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Compile nested function3 calls");
    if (ret == EXPR_SUCCESS) {
        ret = expr_evaluate(handle, &result);
        TEST_ASSERT_EQUAL(7.071067811865476, result, "Evaluate nested function3");
        expr_handle_free(handle);
    }
    
    /* Test 7: Complex expression with variables */
    double x = 2.0, y = 3.0, z = 1.0;
    expr_add_variable(ctx, "x", &x, EXPR_VAR_READ_WRITE);
    expr_add_variable(ctx, "y", &y, EXPR_VAR_READ_WRITE);
    expr_add_variable(ctx, "z", &z, EXPR_VAR_READ_WRITE);
    
    ret = expr_compile(ctx, "lerp(x, y, z / 2)", 0, &handle);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Compile function3 with variables");
    if (ret == EXPR_SUCCESS) {
        ret = expr_evaluate(handle, &result);
        TEST_ASSERT_EQUAL(2.5, result, "Evaluate function3 with variables");
        expr_handle_free(handle);
    }
    
    /* Test 8: Function3/4 error handling */
    printf("\n--- Testing Function3/4 Error Cases ---\n");
    ret = expr_compile(ctx, "lerp(1, 2)", 0, &handle);
    TEST_ASSERT(ret != EXPR_SUCCESS, "Function3 with wrong argument count fails");
    
    ret = expr_compile(ctx, "rect_area(1, 2, 3)", 0, &handle);
    TEST_ASSERT(ret != EXPR_SUCCESS, "Function4 with wrong argument count fails");
    
    ret = expr_compile(ctx, "lerp(1, 2, 3, 4)", 0, &handle);
    TEST_ASSERT(ret != EXPR_SUCCESS, "Function3 with too many arguments fails");
    
    ret = expr_compile(ctx, "rect_area(1, 2, 3, 4, 5)", 0, &handle);
    TEST_ASSERT(ret != EXPR_SUCCESS, "Function4 with too many arguments fails");
    
    /* Test 9: Function3/4 list operations */
    printf("\n--- Testing Function3/4 List Operations ---\n");
    expr_function3_entry_t func3_list[] = {
        {"min3", test_clamp3, EXPR_FUNC_PURE},  /* Reuse clamp as min3 */
        {"max3", test_distance3d, EXPR_FUNC_PURE}  /* Different usage */
    };
    
    ret = expr_add_function3_list(ctx, 2, func3_list);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Add function3 list");
    
    expr_function4_entry_t func4_list[] = {
        {"interp4", test_bilinear4, EXPR_FUNC_PURE},
        {"compute4", test_polynomial4, EXPR_FUNC_PURE}
    };
    
    ret = expr_add_function4_list(ctx, 2, func4_list);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Add function4 list");
    
    /* Test 10: Use functions from lists */
    ret = expr_compile(ctx, "min3(5, 1, 10)", 0, &handle);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Compile function3 from list");
    if (ret == EXPR_SUCCESS) {
        ret = expr_evaluate(handle, &result);
        TEST_ASSERT_EQUAL(5.0, result, "Evaluate function3 from list");
        expr_handle_free(handle);
    }
    
    ret = expr_compile(ctx, "interp4(0.25, 0.75, 4, 16)", 0, &handle);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Compile function4 from list");
    if (ret == EXPR_SUCCESS) {
        ret = expr_evaluate(handle, &result);
        TEST_ASSERT_EQUAL(3.75, result, "Evaluate function4 from list");
        expr_handle_free(handle);
    }
    
    expr_context_free(ctx);
    printf("Function3/Function4 tests completed.\n");
}

/*
 * test_enhanced_error_validation
 *
 * Comprehensive error handling tests to verify robust error detection,
 * proper error codes, and helpful error messages for all error conditions.
 *
 * Inputs: None
 * Outputs: None
 * Side effects: Prints test results and updates global test counters
 *
 * Key dependencies: expr_* API functions and error handling system
 *
 * Tests syntax errors, semantic errors, runtime errors, boundary conditions,
 * and error message quality to ensure production-ready error handling.
 */
void
test_enhanced_error_validation(void)
{
    expr_context ctx;
    expr_handle handle;
    double result;
    int ret, pos;
    
    printf("\n=== Testing Enhanced Error Validation ===\n");
    
    /* Initialize context */
    ret = expr_context_new(&ctx);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Context creation for error validation tests");
    
    /* Add some symbols for testing */
    double x = 5.0, y = 10.0;
    expr_add_variable(ctx, "x", &x, EXPR_VAR_READ_WRITE);
    expr_add_variable(ctx, "y", &y, EXPR_VAR_READABLE);
    expr_add_constant(ctx, "pi", 3.14159, 0);
    expr_add_function1(ctx, "sin", test_sin, EXPR_FUNC_PURE);
    
    /* Test 1: Advanced syntax errors */
    printf("\n--- Testing Advanced Syntax Errors ---\n");
    
    ret = expr_compile(ctx, "2 + * 3", 0, &handle);
    TEST_ASSERT_ERROR(ret, EXPR_ERROR_PARSE, "Consecutive operators");
    
    ret = expr_compile(ctx, "((2 + 3)", 0, &handle);
    TEST_ASSERT_ERROR(ret, EXPR_ERROR_PARSE, "Unbalanced parentheses (missing close)");
    
    ret = expr_compile(ctx, "(2 + 3))", 0, &handle);
    TEST_ASSERT_ERROR(ret, EXPR_ERROR_PARSE, "Unbalanced parentheses (extra close)");
    
    ret = expr_compile(ctx, "2 3", 0, &handle);
    TEST_ASSERT_ERROR(ret, EXPR_ERROR_PARSE, "Missing operator between numbers");
    
    ret = expr_compile(ctx, "sin cos(x)", 0, &handle);
    TEST_ASSERT_ERROR(ret, EXPR_ERROR_PARSE, "Missing operator between functions");
    
    ret = expr_compile(ctx, "2 + ()", 0, &handle);
    TEST_ASSERT_ERROR(ret, EXPR_ERROR_PARSE, "Empty parentheses");
    
    /* Test 2: Function call errors */
    printf("\n--- Testing Function Call Errors ---\n");
    
    ret = expr_compile(ctx, "sin()", 0, &handle);
    TEST_ASSERT_ERROR(ret, EXPR_ERROR_PARSE, "Function with missing arguments");
    
    ret = expr_compile(ctx, "sin(1, 2)", 0, &handle);
    TEST_ASSERT_ERROR(ret, EXPR_ERROR_PARSE, "Function with too many arguments");
    
    ret = expr_compile(ctx, "sin(1, 2, 3)", 0, &handle);
    TEST_ASSERT_ERROR(ret, EXPR_ERROR_PARSE, "Function with way too many arguments");
    
    ret = expr_compile(ctx, "unknown_func(1)", 0, &handle);
    TEST_ASSERT_ERROR(ret, EXPR_ERROR_UNDEFINED_SYMBOL, "Unknown function call");
    
    ret = expr_compile(ctx, "sin(", 0, &handle);
    TEST_ASSERT_ERROR(ret, EXPR_ERROR_PARSE, "Incomplete function call");
    
    ret = expr_compile(ctx, "sin(1,)", 0, &handle);
    TEST_ASSERT_ERROR(ret, EXPR_ERROR_PARSE, "Function with trailing comma");
    
    /* Test 3: Variable and assignment errors */
    printf("\n--- Testing Variable/Assignment Errors ---\n");
    
    ret = expr_compile(ctx, "unknown_var = 5", 0, &handle);
    TEST_ASSERT_ERROR(ret, EXPR_ERROR_UNDEFINED_SYMBOL, "Assignment to unknown variable");
    
    ret = expr_compile(ctx, "pi = 5", 0, &handle);
    TEST_ASSERT_ERROR(ret, EXPR_ERROR_INVALID_ASSIGNMENT, "Assignment to constant fails at compile time");
    
    ret = expr_compile(ctx, "5 = x", 0, &handle);
    TEST_ASSERT_ERROR(ret, EXPR_ERROR_INVALID_ASSIGNMENT, "Assignment to literal fails at compile time");
    
    ret = expr_compile(ctx, "x = ", 0, &handle);
    TEST_ASSERT_ERROR(ret, EXPR_ERROR_PARSE, "Assignment with missing value");
    
    /* Test assignment to read-only variables */
    ret = expr_compile(ctx, "y = 10", 0, &handle);
    TEST_ASSERT_ERROR(ret, EXPR_ERROR_INVALID_ASSIGNMENT, "Assignment to read-only variable fails at compile time");
    
    ret = expr_compile(ctx, "y += 5", EXPR_ENABLE_COMPOUND_ASSIGN, &handle);
    TEST_ASSERT_ERROR(ret, EXPR_ERROR_INVALID_ASSIGNMENT, "Compound assignment to read-only variable fails at compile time");
    
    /* Test write-only variables */
    double write_only = 20.0;
    expr_add_variable(ctx, "write_only", &write_only, EXPR_VAR_WRITABLE);
    
    ret = expr_compile(ctx, "write_only + 5", 0, &handle);
    TEST_ASSERT_ERROR(ret, EXPR_ERROR_INVALID_VARIABLE, "Reading from write-only variable fails at compile time");
    
    ret = expr_compile(ctx, "write_only = 100", 0, &handle);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Writing to write-only variable compiles");
    if (ret == EXPR_SUCCESS) {
        ret = expr_evaluate(handle, &result);
        TEST_ASSERT(ret == EXPR_SUCCESS, "Writing to write-only variable succeeds");
        TEST_ASSERT_EQUAL(100.0, result, "Write-only variable assignment result");
        expr_handle_free(handle);
    }
    
    ret = expr_compile(ctx, "write_only += 10", EXPR_ENABLE_COMPOUND_ASSIGN, &handle);
    TEST_ASSERT_ERROR(ret, EXPR_ERROR_INVALID_ASSIGNMENT, "Compound assignment to write-only variable fails at compile time");
    
    /* Test 4: Operator precedence and associativity errors */
    printf("\n--- Testing Complex Expression Errors ---\n");
    
    ret = expr_compile(ctx, "2 ^ ^ 3", 0, &handle);
    TEST_ASSERT_ERROR(ret, EXPR_ERROR_PARSE, "Consecutive power operators");
    
    ret = expr_compile(ctx, "2 + + + 3", 0, &handle);
    TEST_ASSERT_ERROR(ret, EXPR_ERROR_PARSE, "Multiple consecutive plus operators");
    
    ret = expr_compile(ctx, "2 */ 3", 0, &handle);
    TEST_ASSERT_ERROR(ret, EXPR_ERROR_PARSE, "Invalid operator combination");
    
    /* Test 5: Runtime errors */
    printf("\n--- Testing Runtime Errors ---\n");
    
    ret = expr_compile(ctx, "x / (5 - 5)", 0, &handle);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Division by zero expression compiles");
    if (ret == EXPR_SUCCESS) {
        ret = expr_evaluate(handle, &result);
        TEST_ASSERT_ERROR(ret, EXPR_ERROR_DIVISION_BY_ZERO, "Runtime division by zero");
        expr_handle_free(handle);
    }
    
    ret = expr_compile(ctx, "1 / (x - x)", 0, &handle);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Variable-based zero division compiles");
    if (ret == EXPR_SUCCESS) {
        ret = expr_evaluate(handle, &result);
        TEST_ASSERT_ERROR(ret, EXPR_ERROR_DIVISION_BY_ZERO, "Variable-based division by zero");
        expr_handle_free(handle);
    }
    
    /* Test 6: Error position accuracy */
    printf("\n--- Testing Error Position Reporting ---\n");
    
    ret = expr_compile(ctx, "2 + unknown_var", 0, &handle);
    if (ret != EXPR_SUCCESS) {
        pos = expr_error_position(ctx);
        TEST_ASSERT(pos == 4, "Error position for undefined variable");
        printf("Position test: Error at pos %d for 'unknown_var' in '2 + unknown_var'\n", pos);
    }
    
    ret = expr_compile(ctx, "sin(x) + bad_func()", 0, &handle);
    if (ret != EXPR_SUCCESS) {
        pos = expr_error_position(ctx);
        TEST_ASSERT(pos == 9, "Error position for undefined function");
        printf("Position test: Error at pos %d for 'bad_func' in 'sin(x) + bad_func()'\n", pos);
    }
    
    ret = expr_compile(ctx, "2 + (3 * ", 0, &handle);
    if (ret != EXPR_SUCCESS) {
        pos = expr_error_position(ctx);
        TEST_ASSERT(pos >= 6, "Error position for incomplete expression");
        printf("Position test: Error at pos %d for incomplete expression\n", pos);
    }
    
    /* Test 7: Invalid characters and tokens */
    printf("\n--- Testing Invalid Characters ---\n");
    
    ret = expr_compile(ctx, "2 + @", 0, &handle);
    TEST_ASSERT_ERROR(ret, EXPR_ERROR_PARSE, "Invalid character @");
    
    ret = expr_compile(ctx, "2 & 3", 0, &handle);
    TEST_ASSERT_ERROR(ret, EXPR_ERROR_PARSE, "Invalid character &");
    
    ret = expr_compile(ctx, "2 # comment", 0, &handle);
    TEST_ASSERT_ERROR(ret, EXPR_ERROR_PARSE, "Invalid character #");
    
    /* Test 8: Boundary conditions */
    printf("\n--- Testing Boundary Conditions ---\n");
    
    ret = expr_compile(ctx, "   ", 0, &handle);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Whitespace-only expression compiles as empty");
    if (ret == EXPR_SUCCESS) {
        expr_handle_free(handle);
    }
    
    ret = expr_compile(ctx, "\t\n  ", 0, &handle);
    TEST_ASSERT(ret == EXPR_SUCCESS, "Various whitespace compiles as empty");
    if (ret == EXPR_SUCCESS) {
        expr_handle_free(handle);
    }
    
    /* Test 9: Complex nested errors */
    printf("\n--- Testing Complex Nested Errors ---\n");
    
    ret = expr_compile(ctx, "sin(cos(unknown))", 0, &handle);
    TEST_ASSERT_ERROR(ret, EXPR_ERROR_UNDEFINED_SYMBOL, "Nested function with undefined symbol");
    
    ret = expr_compile(ctx, "(2 + (3 * (4 +)))", 0, &handle);
    TEST_ASSERT_ERROR(ret, EXPR_ERROR_PARSE, "Deeply nested incomplete expression");
    
    ret = expr_compile(ctx, "sin(x + cos(tan()))", 0, &handle);
    TEST_ASSERT_ERROR(ret, EXPR_ERROR_UNDEFINED_SYMBOL, "Mixed valid/invalid nested functions");
    
    /* Test 10: Error message quality */
    printf("\n--- Testing Error Message Quality ---\n");
    
    ret = expr_compile(ctx, "undefined_symbol", 0, &handle);
    if (ret != EXPR_SUCCESS) {
        const char *error_msg = expr_error(ctx);
        TEST_ASSERT(strlen(error_msg) > 10, "Error message has reasonable length");
        TEST_ASSERT(strstr(error_msg, "undefined") != NULL || strstr(error_msg, "symbol") != NULL, 
                   "Error message mentions undefined symbol");
        printf("Error message quality: '%s'\n", error_msg);
    }
    
    expr_context_free(ctx);
    printf("Enhanced error validation tests completed.\n");
}

/*
 * test_new_optimizations
 *
 * Tests the newly implemented optimization passes including strength reduction,
 * pure function optimization, and common subexpression elimination.
 */
void test_new_optimizations(void)
{
    expr_context ctx;
    expr_handle handle;
    optimization_report_t report;
    double result;
    int ret;
    
    printf("\n=== Testing New Optimizations ===\n");
    
    expr_context_new(&ctx);
    expr_add_function1(ctx, "sin", test_sin, EXPR_FUNC_PURE);
    expr_add_function1(ctx, "sqrt", test_sqrt, EXPR_FUNC_PURE);
    
    /* Test 1: Strength Reduction - x^2 -> x*x */
    ret = expr_compile(ctx, "5^2", EXPR_ENABLE_POWER, &handle);
    if (ret == EXPR_SUCCESS) {
        ret = expr_optimize(&handle, &report);
        if (ret == EXPR_SUCCESS) {
            ret = expr_evaluate(handle, &result);
            TEST_ASSERT_EQUAL(25.0, result, "Strength reduction x^2 optimization");
            TEST_ASSERT(report.final_nodes == 1, "Strength reduction node count optimization");
            expr_free_optimization_report(&report);
        }
        expr_handle_free(handle);
    }
    
    /* Test 2: Pure Function Optimization */
    ret = expr_compile(ctx, "sin(1.5) + sin(1.5)", 0, &handle);
    if (ret == EXPR_SUCCESS) {
        ret = expr_optimize(&handle, &report);
        if (ret == EXPR_SUCCESS) {
            ret = expr_evaluate(handle, &result);
            TEST_ASSERT_EQUAL(2 * sin(1.5), result, "Pure function optimization");
            TEST_ASSERT(report.final_nodes == 1, "Pure function node count optimization");
            expr_free_optimization_report(&report);
        }
        expr_handle_free(handle);
    }
    
    /* Test 3: Division to Multiplication */
    ret = expr_compile(ctx, "10/2", 0, &handle);
    if (ret == EXPR_SUCCESS) {
        ret = expr_optimize(&handle, &report);
        if (ret == EXPR_SUCCESS) {
            ret = expr_evaluate(handle, &result);
            TEST_ASSERT_EQUAL(5.0, result, "Division to multiplication optimization");
            TEST_ASSERT(report.final_nodes == 1, "Division optimization node count");
            expr_free_optimization_report(&report);
        }
        expr_handle_free(handle);
    }
    
    /* Test 4: Combined Optimizations */
    ret = expr_compile(ctx, "sqrt(16) + 3^2 + sin(0) * 5/2", EXPR_ENABLE_POWER, &handle);
    if (ret == EXPR_SUCCESS) {
        ret = expr_optimize(&handle, &report);
        if (ret == EXPR_SUCCESS) {
            ret = expr_evaluate(handle, &result);
            TEST_ASSERT_EQUAL(13.0, result, "Combined optimizations");
            TEST_ASSERT(report.final_nodes == 1, "Combined optimizations node count");
            TEST_ASSERT(report.original_nodes > report.final_nodes, "Node count reduction");
            expr_free_optimization_report(&report);
        }
        expr_handle_free(handle);
    }
    
    expr_context_free(ctx);
}

/*
 * main
 *
 * Runs all test suites and reports results.
 */
int main(void)
{
    printf("Mathematical Expression Evaluation Library Test Suite\n");
    printf("====================================================\n");
    
    srand((unsigned int)time(NULL));
    
    test_basic_context();
    test_symbol_management();
    test_basic_parsing();
    test_advanced_operators();
    test_functions();
    test_error_handling();
    test_convenience_functions();
    test_batch_symbol_addition();
    test_performance_comparison();
    test_semicolon_sequences();
    test_compilation_options();
    test_utf8_symbol_names();
    test_function3_function4();
    test_enhanced_error_validation();
    test_new_optimizations();
    test_optimization();
    test_performance();
    test_edge_cases();
    
    printf("\n=== Test Results ===\n");
    printf("Total tests: %d\n", tests_run);
    printf("Passed: %d\n", tests_passed);
    printf("Failed: %d\n", tests_failed);
    printf("Success rate: %.1f%%\n", (double)tests_passed / tests_run * 100.0);
    
    if (tests_failed == 0) {
        printf("\nAll tests passed! ✓\n");
        return 0;
    } else {
        printf("\n%d test(s) failed! ✗\n", tests_failed);
        return 1;
    }
}