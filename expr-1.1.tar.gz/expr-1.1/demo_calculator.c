/*
 * demo_calculator.c
 *
 * Copyright (C) 2025 by Robert Cousins
 * All Rights Reserved
 *
 * Interactive calculator demonstration program for mathematical expression
 * evaluation library. Provides command-line interface with built-in
 * mathematical functions, variables, and optimization support.
 *
 * $Id: demo_calculator.c,v 1.1 2025/06/25 16:02:06 rec Exp rec $
 *
 * Author: Robert Cousins
 *
 * 2025-06-22: Initial implementation
 */

#define _GNU_SOURCE
#include "expr.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

#ifndef M_E
#define M_E 2.7182818284590452354
#endif

#define MAX_LINE_LENGTH 1024
#define MAX_VARIABLES 100

/* Calculator state */
typedef struct {
    expr_context ctx;
    double variables[MAX_VARIABLES];
    char *variable_names[MAX_VARIABLES];
    unsigned variable_permissions[MAX_VARIABLES];
    int variable_count;
    int show_optimization;
    int enable_all_operators;
} calculator_state_t;

/* Mathematical functions for calculator */
double calc_sin(double x) { return sin(x); }
double calc_cos(double x) { return cos(x); }
double calc_tan(double x) { return tan(x); }
double calc_asin(double x) { return asin(x); }
double calc_acos(double x) { return acos(x); }
double calc_atan(double x) { return atan(x); }
double calc_sinh(double x) { return sinh(x); }
double calc_cosh(double x) { return cosh(x); }
double calc_tanh(double x) { return tanh(x); }
double calc_exp(double x) { return exp(x); }
double calc_log(double x) { return log(x); }
double calc_log10(double x) { return log10(x); }
double calc_sqrt(double x) { return sqrt(x); }
double calc_fabs(double x) { return fabs(x); }
double calc_ceil(double x) { return ceil(x); }
double calc_floor(double x) { return floor(x); }
double calc_round(double x) { return round(x); }

double calc_pow(double x, double y) { return pow(x, y); }
double calc_atan2(double y, double x) { return atan2(y, x); }
double calc_fmod(double x, double y) { return fmod(x, y); }
double calc_min(double x, double y) { return x < y ? x : y; }
double calc_max(double x, double y) { return x > y ? x : y; }

double calc_rand(void) { return (double)rand() / RAND_MAX; }
double calc_pi(void) { return M_PI; }
double calc_e(void) { return M_E; }

/*
 * init_calculator
 *
 * Initializes calculator state and adds built-in functions.
 *
 * Input: calc - calculator state structure
 * Output: 0 on success, -1 on failure
 * Side effects: Creates context and populates symbol table
 *
 * Dependencies: Expression library, math library
 *
 * Sets up complete mathematical environment for calculator.
 */
int
init_calculator(calculator_state_t *calc)
{
    if (expr_context_new(&calc->ctx) != EXPR_SUCCESS)
        return -1;
    
    calc->variable_count = 0;
    calc->show_optimization = 0;
    calc->enable_all_operators = 1;
    
    /* Add mathematical constants using batch function */
    expr_constant_entry_t constants[] = {
        {"pi", M_PI, 0},
        {"e", M_E, 0},
        {"inf", INFINITY, 0},
        {"nan", NAN, 0}
    };
    expr_add_constant_list(calc->ctx, 4, constants);
    
    /* Add zero-argument functions using batch function */
    expr_function0_entry_t functions0[] = {
        {"rand", calc_rand, 0},
        {"pi", calc_pi, EXPR_FUNC_PURE},
        {"e", calc_e, EXPR_FUNC_PURE}
    };
    expr_add_function0_list(calc->ctx, 3, functions0);
    
    /* Add single-argument functions using batch function */
    expr_function1_entry_t functions1[] = {
        {"sin", calc_sin, EXPR_FUNC_PURE},
        {"cos", calc_cos, EXPR_FUNC_PURE},
        {"tan", calc_tan, EXPR_FUNC_PURE},
        {"asin", calc_asin, EXPR_FUNC_PURE},
        {"acos", calc_acos, EXPR_FUNC_PURE},
        {"atan", calc_atan, EXPR_FUNC_PURE},
        {"sinh", calc_sinh, EXPR_FUNC_PURE},
        {"cosh", calc_cosh, EXPR_FUNC_PURE},
        {"tanh", calc_tanh, EXPR_FUNC_PURE},
        {"exp", calc_exp, EXPR_FUNC_PURE},
        {"log", calc_log, EXPR_FUNC_PURE},
        {"log10", calc_log10, EXPR_FUNC_PURE},
        {"sqrt", calc_sqrt, EXPR_FUNC_PURE},
        {"abs", calc_fabs, EXPR_FUNC_PURE},
        {"ceil", calc_ceil, EXPR_FUNC_PURE},
        {"floor", calc_floor, EXPR_FUNC_PURE},
        {"round", calc_round, EXPR_FUNC_PURE}
    };
    expr_add_function1_list(calc->ctx, 17, functions1);
    
    /* Add two-argument functions using batch function */
    expr_function2_entry_t functions2[] = {
        {"pow", calc_pow, EXPR_FUNC_PURE},
        {"atan2", calc_atan2, EXPR_FUNC_PURE},
        {"mod", calc_fmod, EXPR_FUNC_PURE},
        {"min", calc_min, EXPR_FUNC_PURE},
        {"max", calc_max, EXPR_FUNC_PURE}
    };
    expr_add_function2_list(calc->ctx, 5, functions2);
    
    return 0;
}

/*
 * cleanup_calculator
 *
 * Cleans up calculator state and frees memory.
 *
 * Input: calc - calculator state structure
 * Output: None
 * Side effects: Frees context and variable names
 *
 * Dependencies: Expression library
 *
 * Ensures proper cleanup of all allocated resources.
 */
void
cleanup_calculator(calculator_state_t *calc)
{
    int i;
    
    for (i = 0; i < calc->variable_count; i++) {
        free(calc->variable_names[i]);
    }
    
    expr_context_free(calc->ctx);
}

/*
 * add_variable_with_permissions
 *
 * Adds a new variable to the calculator with specific permissions.
 *
 * Input: calc - calculator state
 *        name - variable name
 *        value - initial value
 *        permissions - variable permissions (EXPR_VAR_READABLE, EXPR_VAR_WRITABLE, etc.)
 * Output: 0 on success, -1 on failure
 * Side effects: Modifies calculator state
 *
 * Dependencies: Expression library, memory allocation
 *
 * Creates new variable with specified permissions for demonstration purposes.
 */
int
add_variable_with_permissions(calculator_state_t *calc, const char *name, double value, unsigned permissions)
{
    if (calc->variable_count >= MAX_VARIABLES)
        return -1;
    
    calc->variable_names[calc->variable_count] = malloc(strlen(name) + 1);
    if (!calc->variable_names[calc->variable_count])
        return -1;
    
    strcpy(calc->variable_names[calc->variable_count], name);
    calc->variables[calc->variable_count] = value;
    calc->variable_permissions[calc->variable_count] = permissions;
    
    if (expr_add_variable(calc->ctx, name, &calc->variables[calc->variable_count], 
                         permissions) != EXPR_SUCCESS) {
        free(calc->variable_names[calc->variable_count]);
        return -1;
    }
    
    calc->variable_count++;
    return 0;
}

/*
 * add_variable
 *
 * Adds a new variable to the calculator.
 *
 * Input: calc - calculator state
 *        name - variable name
 *        value - initial value
 * Output: 0 on success, -1 on failure
 * Side effects: Modifies calculator state
 *
 * Dependencies: Expression library, memory allocation
 *
 * Creates new variable with read-write permissions.
 */
int
add_variable(calculator_state_t *calc, const char *name, double value)
{
    return add_variable_with_permissions(calc, name, value, EXPR_VAR_READ_WRITE);
}

/*
 * show_help
 *
 * Displays help information for calculator commands.
 *
 * Input: None
 * Output: None
 * Side effects: Prints to stdout
 *
 * Dependencies: None
 *
 * Provides user guidance for calculator usage.
 */
void
show_help(void)
{
    printf("\nCalculator Commands:\n");
    printf("  <expression>     - Evaluate mathematical expression\n");
    printf("  :help or :h      - Show this help\n");
    printf("  :quit or :q      - Exit calculator\n");
    printf("  :vars            - List variables with values and permissions\n");
    printf("  :funcs           - List available functions\n");
    printf("  :optimize on/off - Enable/disable optimization reporting\n");
    printf("  :operators on/off- Enable/disable advanced operators\n");
    printf("\nVariable Permissions:\n");
    printf("  rw               - Read-write variable (can read and assign)\n");
    printf("  ro               - Read-only variable (can read, cannot assign)\n");
    printf("  wo               - Write-only variable (can assign, cannot read)\n");
    printf("  ans              - Standard read-write result variable\n");
    printf("\nOperators:\n");
    printf("  +, -, *, /       - Basic arithmetic\n");
    printf("  ^                - Exponentiation (if enabled)\n");
    printf("  %%                - Modulo (if enabled)\n");
    printf("  =                - Assignment\n");
    printf("  +=, -=, *=, /=   - Compound assignment (if enabled)\n");
    printf("  ( )              - Grouping\n");
    printf("\nExamples:\n");
    printf("  2 + 3 * 4        => 14\n");
    printf("  rw = 5           => assigns 5 to read-write variable\n");
    printf("  rw + ro          => reads from both variables (works)\n");
    printf("  wo = 42          => assigns to write-only variable (works)\n");
    printf("  wo + 1           => ERROR: cannot read from write-only variable\n");
    printf("  ro = 10          => ERROR: cannot assign to read-only variable\n");
    printf("  sin(pi/2)        => 1\n");
    printf("  sqrt(pow(3,2) + pow(4,2)) => 5\n");
    printf("  0x10 + 0xFF      => 271 (hexadecimal)\n");
}

/*
 * show_variables
 *
 * Lists all variables with their current values and permissions.
 *
 * Input: calc - calculator state
 * Output: None
 * Side effects: Prints to stdout
 *
 * Dependencies: None
 *
 * Displays current variable state and permissions for user reference.
 */
void
show_variables(calculator_state_t *calc)
{
    int i;
    
    if (calc->variable_count == 0) {
        printf("No variables defined.\n");
        return;
    }
    
    printf("\nVariables:\n");
    printf("  %-8s %-15s %s\n", "Name", "Value", "Permissions");
    printf("  %-8s %-15s %s\n", "----", "-----", "-----------");
    
    for (i = 0; i < calc->variable_count; i++) {
        const char *perms;
        unsigned p = calc->variable_permissions[i];
        
        if ((p & EXPR_VAR_READ_WRITE) == EXPR_VAR_READ_WRITE) {
            perms = "read-write";
        } else if (p & EXPR_VAR_READABLE) {
            perms = "read-only";
        } else if (p & EXPR_VAR_WRITABLE) {
            perms = "write-only";
        } else {
            perms = "none";
        }
        
        printf("  %-8s %-15.6g %s\n", calc->variable_names[i], calc->variables[i], perms);
    }
}

/*
 * show_functions
 *
 * Lists all available functions.
 *
 * Input: None
 * Output: None
 * Side effects: Prints to stdout
 *
 * Dependencies: None
 *
 * Displays available mathematical functions for user reference.
 */
void
show_functions(void)
{
    printf("\nAvailable Functions:\n");
    printf("  Constants: pi, e, inf, nan\n");
    printf("  Trigonometric: sin, cos, tan, asin, acos, atan\n");
    printf("  Hyperbolic: sinh, cosh, tanh\n");
    printf("  Exponential: exp, log, log10, pow\n");
    printf("  Utility: sqrt, abs, ceil, floor, round\n");
    printf("  Two-argument: pow(x,y), atan2(y,x), mod(x,y), min(x,y), max(x,y)\n");
    printf("  Random: rand() - returns value between 0 and 1\n");
}

/*
 * process_command
 *
 * Processes calculator commands starting with ':'.
 *
 * Input: calc - calculator state
 *        line - command line
 * Output: 0 to continue, 1 to quit
 * Side effects: May modify calculator state
 *
 * Dependencies: String manipulation
 *
 * Handles meta-commands for calculator control.
 */
int
process_command(calculator_state_t *calc, const char *line)
{
    if (strcmp(line, ":quit") == 0 || strcmp(line, ":q") == 0) {
        return 1;
    } else if (strcmp(line, ":help") == 0 || strcmp(line, ":h") == 0) {
        show_help();
    } else if (strcmp(line, ":vars") == 0) {
        show_variables(calc);
    } else if (strcmp(line, ":funcs") == 0) {
        show_functions();
    } else if (strncmp(line, ":optimize ", 10) == 0) {
        if (strcmp(line + 10, "on") == 0) {
            calc->show_optimization = 1;
            printf("Optimization reporting enabled.\n");
        } else if (strcmp(line + 10, "off") == 0) {
            calc->show_optimization = 0;
            printf("Optimization reporting disabled.\n");
        } else {
            printf("Usage: :optimize on|off\n");
        }
    } else if (strncmp(line, ":operators ", 11) == 0) {
        if (strcmp(line + 11, "on") == 0) {
            calc->enable_all_operators = 1;
            printf("Advanced operators enabled.\n");
        } else if (strcmp(line + 11, "off") == 0) {
            calc->enable_all_operators = 0;
            printf("Advanced operators disabled.\n");
        } else {
            printf("Usage: :operators on|off\n");
        }
    } else {
        printf("Unknown command. Type :help for available commands.\n");
    }
    
    return 0;
}

/*
 * evaluate_expression
 *
 * Evaluates a mathematical expression and displays result.
 *
 * Input: calc - calculator state
 *        expression - expression string
 * Output: None
 * Side effects: May create variables, prints results
 *
 * Dependencies: Expression library
 *
 * Main expression evaluation with error handling and optimization.
 */
void
evaluate_expression(calculator_state_t *calc, const char *expression)
{
    expr_handle handle;
    optimization_report_t opt_report;
    double result;
    int ret;
    unsigned options = 0;
    
    /* Set compilation options */
    if (calc->enable_all_operators) {
        options |= EXPR_ENABLE_POWER;
        options |= EXPR_ENABLE_MODULO;
        options |= EXPR_ENABLE_COMPOUND_ASSIGN;
    }
    options |= EXPR_ALLOW_SEMICOLON;
    
    /* Compile expression */
    ret = expr_compile(calc->ctx, expression, options, &handle);
    if (ret != EXPR_SUCCESS) {
        printf("Error: %s\n", expr_error(calc->ctx));
        int pos = expr_error_position(calc->ctx);
        if (pos >= 0) {
            printf("Position: %d\n", pos);
            printf("Expression: %s\n", expression);
            printf("            ");
            for (int i = 0; i < pos; i++) printf(" ");
            printf("^\n");
        }
        return;
    }
    
    /* Optimize if requested */
    if (calc->show_optimization) {
        ret = expr_optimize(&handle, &opt_report);
        if (ret == EXPR_SUCCESS) {
            printf("Optimization: %s\n", opt_report.summary ? opt_report.summary : "No changes");
            if (opt_report.original_expression && opt_report.optimized_expression) {
                if (strcmp(opt_report.original_expression, opt_report.optimized_expression) != 0) {
                    printf("Original:  %s\n", opt_report.original_expression);
                    printf("Optimized: %s\n", opt_report.optimized_expression);
                }
            }
            expr_free_optimization_report(&opt_report);
        }
    }
    
    /* Evaluate expression */
    ret = expr_evaluate(handle, &result);
    if (ret != EXPR_SUCCESS) {
        const char *error_msg;
        switch (ret) {
            case EXPR_ERROR_DIVISION_BY_ZERO:
                error_msg = "Division by zero";
                break;
            case EXPR_ERROR_INVALID_VARIABLE:
                error_msg = "Invalid variable access";
                break;
            case EXPR_ERROR_INVALID_FUNCTION:
                error_msg = "Invalid function call";
                break;
            default:
                error_msg = "Evaluation error";
                break;
        }
        printf("Error: %s\n", error_msg);
        expr_handle_free(handle);
        return;
    }
    
    /* Display result */
    if (isnan(result)) {
        printf("= NaN\n");
    } else if (isinf(result)) {
        printf("= %s\n", result > 0 ? "Infinity" : "-Infinity");
    } else {
        printf("= %.15g\n", result);
    }
    
    expr_handle_free(handle);
}

/*
 * trim_whitespace
 *
 * Removes leading and trailing whitespace from string.
 *
 * Input: str - string to trim
 * Output: Pointer to trimmed string
 * Side effects: Modifies input string
 *
 * Dependencies: Character classification
 *
 * Utility function for input processing.
 */
char*
trim_whitespace(char *str)
{
    char *end;
    
    /* Skip leading whitespace */
    while (isspace(*str))
        str++;
    
    if (*str == 0)
        return str;
    
    /* Trim trailing whitespace */
    end = str + strlen(str) - 1;
    while (end > str && isspace(*end))
        end--;
    
    end[1] = '\0';
    return str;
}

/*
 * main
 *
 * Main calculator loop with interactive interface.
 *
 * Input: Command line arguments (unused)
 * Output: Exit status
 * Side effects: Interactive session with user
 *
 * Dependencies: All calculator functions
 *
 * Provides complete calculator experience.
 */
int
main(int argc, char *argv[])
{
    calculator_state_t calc;
    char line[MAX_LINE_LENGTH];
    char *trimmed;
    
    (void)argc;
    (void)argv;
    
    printf("Mathematical Expression Calculator\n");
    printf("=================================\n");
    printf("Type expressions to evaluate them, or :help for commands.\n");
    printf("Use :quit to exit.\n\n");
    
    if (init_calculator(&calc) != 0) {
        fprintf(stderr, "Failed to initialize calculator.\n");
        return 1;
    }
    
    /* Add default variables demonstrating different permissions */
    add_variable(&calc, "ans", 0.0);
    add_variable_with_permissions(&calc, "rw", 42.0, EXPR_VAR_READ_WRITE);  /* Read-write */
    add_variable_with_permissions(&calc, "ro", 3.14159, EXPR_VAR_READABLE); /* Read-only */
    add_variable_with_permissions(&calc, "wo", 100.0, EXPR_VAR_WRITABLE);   /* Write-only */
    
    while (1) {
        printf("> ");
        fflush(stdout);
        
        if (!fgets(line, sizeof(line), stdin)) {
            printf("\n");
            break;
        }
        
        trimmed = trim_whitespace(line);
        
        if (strlen(trimmed) == 0)
            continue;
        
        if (trimmed[0] == ':') {
            if (process_command(&calc, trimmed))
                break;
        } else {
            evaluate_expression(&calc, trimmed);
        }
    }
    
    printf("Goodbye!\n");
    cleanup_calculator(&calc);
    return 0;
}