/*
 * expr_evaluator.c
 *
 * Copyright (C) 2025 by Robert Cousins
 * All Rights Reserved
 *
 * Expression evaluation engine for mathematical expression evaluation library.
 * Traverses AST nodes and computes expression values with proper error handling
 * for division by zero, variable permissions, and function calls.
 *
 * $Id: expr_evaluator.c,v 1.1 2025/06/25 16:02:06 rec Exp rec $
 *
 * Author: Robert Cousins
 *
 * 2025-06-22: Initial implementation
 */

#include "expr_private.h"

/*
 * expr_priv_evaluate_node
 *
 * Recursively evaluates an AST node and returns its value.
 *
 * Input: node - AST node to evaluate
 *        result - pointer to store computed value
 * Output: EXPR_SUCCESS on success, error code on failure
 * Side effects: May modify variables through assignments
 *
 * Dependencies: Symbol table access, math library functions
 *
 * Handles all node types with proper operator semantics.
 */
int
expr_priv_evaluate_node(expr_node_t *node, double *result)
{
    double left_val, right_val, operand_val;
    expr_symbol_t *symbol;
    int ret, i;
    double args[4];
    
    if (!node || !result)
        return EXPR_ERROR_INVALID_PARAM;
    
    if (node->has_cached_value) {
        *result = node->cached_value;
        return EXPR_SUCCESS;
    }
    
    switch (node->type) {
        case EXPR_NODE_NUMBER:
            *result = node->data.number;
            return EXPR_SUCCESS;
            
        case EXPR_NODE_CONSTANT:
            symbol = (expr_symbol_t*)node->data.symbol.symbol_ptr;
            if (!symbol)
                return EXPR_ERROR_UNDEFINED_SYMBOL;
            *result = symbol->data.constant_value;
            return EXPR_SUCCESS;
            
        case EXPR_NODE_VARIABLE:
            symbol = (expr_symbol_t*)node->data.symbol.symbol_ptr;
            if (!symbol)
                return EXPR_ERROR_UNDEFINED_SYMBOL;
            /* Read permission now validated at compile time with context awareness */
            *result = *symbol->data.variable_ptr;
            return EXPR_SUCCESS;
            
        case EXPR_NODE_FUNCTION0:
            symbol = (expr_symbol_t*)node->data.function.symbol_ptr;
            if (!symbol || !symbol->data.func0)
                return EXPR_ERROR_INVALID_FUNCTION;
            *result = symbol->data.func0();
            return EXPR_SUCCESS;
            
        case EXPR_NODE_FUNCTION1:
            symbol = (expr_symbol_t*)node->data.function.symbol_ptr;
            if (!symbol || !symbol->data.func1)
                return EXPR_ERROR_INVALID_FUNCTION;
            ret = expr_priv_evaluate_node(node->data.function.args[0], &args[0]);
            if (ret != EXPR_SUCCESS)
                return ret;
            *result = symbol->data.func1(args[0]);
            return EXPR_SUCCESS;
            
        case EXPR_NODE_FUNCTION2:
            symbol = (expr_symbol_t*)node->data.function.symbol_ptr;
            if (!symbol || !symbol->data.func2)
                return EXPR_ERROR_INVALID_FUNCTION;
            for (i = 0; i < 2; i++) {
                ret = expr_priv_evaluate_node(node->data.function.args[i], &args[i]);
                if (ret != EXPR_SUCCESS)
                    return ret;
            }
            *result = symbol->data.func2(args[0], args[1]);
            return EXPR_SUCCESS;
            
        case EXPR_NODE_FUNCTION3:
            symbol = (expr_symbol_t*)node->data.function.symbol_ptr;
            if (!symbol || !symbol->data.func3)
                return EXPR_ERROR_INVALID_FUNCTION;
            for (i = 0; i < 3; i++) {
                ret = expr_priv_evaluate_node(node->data.function.args[i], &args[i]);
                if (ret != EXPR_SUCCESS)
                    return ret;
            }
            *result = symbol->data.func3(args[0], args[1], args[2]);
            return EXPR_SUCCESS;
            
        case EXPR_NODE_FUNCTION4:
            symbol = (expr_symbol_t*)node->data.function.symbol_ptr;
            if (!symbol || !symbol->data.func4)
                return EXPR_ERROR_INVALID_FUNCTION;
            for (i = 0; i < 4; i++) {
                ret = expr_priv_evaluate_node(node->data.function.args[i], &args[i]);
                if (ret != EXPR_SUCCESS)
                    return ret;
            }
            *result = symbol->data.func4(args[0], args[1], args[2], args[3]);
            return EXPR_SUCCESS;
            
        case EXPR_NODE_UNARY_PLUS:
            ret = expr_priv_evaluate_node(node->data.unary.operand, &operand_val);
            if (ret != EXPR_SUCCESS)
                return ret;
            *result = operand_val;
            return EXPR_SUCCESS;
            
        case EXPR_NODE_UNARY_MINUS:
            ret = expr_priv_evaluate_node(node->data.unary.operand, &operand_val);
            if (ret != EXPR_SUCCESS)
                return ret;
            *result = -operand_val;
            return EXPR_SUCCESS;
            
        case EXPR_NODE_ADD:
            ret = expr_priv_evaluate_node(node->data.binary.left, &left_val);
            if (ret != EXPR_SUCCESS)
                return ret;
            ret = expr_priv_evaluate_node(node->data.binary.right, &right_val);
            if (ret != EXPR_SUCCESS)
                return ret;
            *result = left_val + right_val;
            return EXPR_SUCCESS;
            
        case EXPR_NODE_SUBTRACT:
            ret = expr_priv_evaluate_node(node->data.binary.left, &left_val);
            if (ret != EXPR_SUCCESS)
                return ret;
            ret = expr_priv_evaluate_node(node->data.binary.right, &right_val);
            if (ret != EXPR_SUCCESS)
                return ret;
            *result = left_val - right_val;
            return EXPR_SUCCESS;
            
        case EXPR_NODE_MULTIPLY:
            ret = expr_priv_evaluate_node(node->data.binary.left, &left_val);
            if (ret != EXPR_SUCCESS)
                return ret;
            ret = expr_priv_evaluate_node(node->data.binary.right, &right_val);
            if (ret != EXPR_SUCCESS)
                return ret;
            *result = left_val * right_val;
            return EXPR_SUCCESS;
            
        case EXPR_NODE_DIVIDE:
            ret = expr_priv_evaluate_node(node->data.binary.left, &left_val);
            if (ret != EXPR_SUCCESS)
                return ret;
            ret = expr_priv_evaluate_node(node->data.binary.right, &right_val);
            if (ret != EXPR_SUCCESS)
                return ret;
            if (right_val == 0.0)
                return EXPR_ERROR_DIVISION_BY_ZERO;
            *result = left_val / right_val;
            return EXPR_SUCCESS;
            
        case EXPR_NODE_POWER:
            ret = expr_priv_evaluate_node(node->data.binary.left, &left_val);
            if (ret != EXPR_SUCCESS)
                return ret;
            ret = expr_priv_evaluate_node(node->data.binary.right, &right_val);
            if (ret != EXPR_SUCCESS)
                return ret;
            *result = pow(left_val, right_val);
            return EXPR_SUCCESS;
            
        case EXPR_NODE_MODULO:
            ret = expr_priv_evaluate_node(node->data.binary.left, &left_val);
            if (ret != EXPR_SUCCESS)
                return ret;
            ret = expr_priv_evaluate_node(node->data.binary.right, &right_val);
            if (ret != EXPR_SUCCESS)
                return ret;
            if (right_val == 0.0)
                return EXPR_ERROR_DIVISION_BY_ZERO;
            *result = fmod(left_val, right_val);
            return EXPR_SUCCESS;
            
        case EXPR_NODE_ASSIGN:
            if (node->data.binary.left->type != EXPR_NODE_VARIABLE)
                return EXPR_ERROR_INVALID_VARIABLE;
            
            symbol = (expr_symbol_t*)node->data.binary.left->data.symbol.symbol_ptr;
            if (!symbol || !(symbol->options & EXPR_VAR_WRITABLE))
                return EXPR_ERROR_INVALID_VARIABLE;
            
            ret = expr_priv_evaluate_node(node->data.binary.right, &right_val);
            if (ret != EXPR_SUCCESS)
                return ret;
            
            *symbol->data.variable_ptr = right_val;
            *result = right_val;
            return EXPR_SUCCESS;
            
        case EXPR_NODE_ADD_ASSIGN:
            if (node->data.binary.left->type != EXPR_NODE_VARIABLE)
                return EXPR_ERROR_INVALID_VARIABLE;
            
            symbol = (expr_symbol_t*)node->data.binary.left->data.symbol.symbol_ptr;
            if (!symbol || !(symbol->options & EXPR_VAR_WRITABLE) || 
                !(symbol->options & EXPR_VAR_READABLE))
                return EXPR_ERROR_INVALID_VARIABLE;
            
            ret = expr_priv_evaluate_node(node->data.binary.right, &right_val);
            if (ret != EXPR_SUCCESS)
                return ret;
            
            *symbol->data.variable_ptr += right_val;
            *result = *symbol->data.variable_ptr;
            return EXPR_SUCCESS;
            
        case EXPR_NODE_SUB_ASSIGN:
            if (node->data.binary.left->type != EXPR_NODE_VARIABLE)
                return EXPR_ERROR_INVALID_VARIABLE;
            
            symbol = (expr_symbol_t*)node->data.binary.left->data.symbol.symbol_ptr;
            if (!symbol || !(symbol->options & EXPR_VAR_WRITABLE) || 
                !(symbol->options & EXPR_VAR_READABLE))
                return EXPR_ERROR_INVALID_VARIABLE;
            
            ret = expr_priv_evaluate_node(node->data.binary.right, &right_val);
            if (ret != EXPR_SUCCESS)
                return ret;
            
            *symbol->data.variable_ptr -= right_val;
            *result = *symbol->data.variable_ptr;
            return EXPR_SUCCESS;
            
        case EXPR_NODE_MUL_ASSIGN:
            if (node->data.binary.left->type != EXPR_NODE_VARIABLE)
                return EXPR_ERROR_INVALID_VARIABLE;
            
            symbol = (expr_symbol_t*)node->data.binary.left->data.symbol.symbol_ptr;
            if (!symbol || !(symbol->options & EXPR_VAR_WRITABLE) || 
                !(symbol->options & EXPR_VAR_READABLE))
                return EXPR_ERROR_INVALID_VARIABLE;
            
            ret = expr_priv_evaluate_node(node->data.binary.right, &right_val);
            if (ret != EXPR_SUCCESS)
                return ret;
            
            *symbol->data.variable_ptr *= right_val;
            *result = *symbol->data.variable_ptr;
            return EXPR_SUCCESS;
            
        case EXPR_NODE_DIV_ASSIGN:
            if (node->data.binary.left->type != EXPR_NODE_VARIABLE)
                return EXPR_ERROR_INVALID_VARIABLE;
            
            symbol = (expr_symbol_t*)node->data.binary.left->data.symbol.symbol_ptr;
            if (!symbol || !(symbol->options & EXPR_VAR_WRITABLE) || 
                !(symbol->options & EXPR_VAR_READABLE))
                return EXPR_ERROR_INVALID_VARIABLE;
            
            ret = expr_priv_evaluate_node(node->data.binary.right, &right_val);
            if (ret != EXPR_SUCCESS)
                return ret;
            
            if (right_val == 0.0)
                return EXPR_ERROR_DIVISION_BY_ZERO;
            
            *symbol->data.variable_ptr /= right_val;
            *result = *symbol->data.variable_ptr;
            return EXPR_SUCCESS;
            
        case EXPR_NODE_POW_ASSIGN:
            if (node->data.binary.left->type != EXPR_NODE_VARIABLE)
                return EXPR_ERROR_INVALID_VARIABLE;
            
            symbol = (expr_symbol_t*)node->data.binary.left->data.symbol.symbol_ptr;
            if (!symbol || !(symbol->options & EXPR_VAR_WRITABLE) || 
                !(symbol->options & EXPR_VAR_READABLE))
                return EXPR_ERROR_INVALID_VARIABLE;
            
            ret = expr_priv_evaluate_node(node->data.binary.right, &right_val);
            if (ret != EXPR_SUCCESS)
                return ret;
            
            *symbol->data.variable_ptr = pow(*symbol->data.variable_ptr, right_val);
            *result = *symbol->data.variable_ptr;
            return EXPR_SUCCESS;
            
        case EXPR_NODE_MOD_ASSIGN:
            if (node->data.binary.left->type != EXPR_NODE_VARIABLE)
                return EXPR_ERROR_INVALID_VARIABLE;
            
            symbol = (expr_symbol_t*)node->data.binary.left->data.symbol.symbol_ptr;
            if (!symbol || !(symbol->options & EXPR_VAR_WRITABLE) || 
                !(symbol->options & EXPR_VAR_READABLE))
                return EXPR_ERROR_INVALID_VARIABLE;
            
            ret = expr_priv_evaluate_node(node->data.binary.right, &right_val);
            if (ret != EXPR_SUCCESS)
                return ret;
            
            if (right_val == 0.0)
                return EXPR_ERROR_DIVISION_BY_ZERO;
            
            *symbol->data.variable_ptr = fmod(*symbol->data.variable_ptr, right_val);
            *result = *symbol->data.variable_ptr;
            return EXPR_SUCCESS;
            
        case EXPR_NODE_SEQUENCE:
            ret = expr_priv_evaluate_node(node->data.binary.left, &left_val);
            if (ret != EXPR_SUCCESS)
                return ret;
            ret = expr_priv_evaluate_node(node->data.binary.right, &right_val);
            if (ret != EXPR_SUCCESS)
                return ret;
            *result = right_val;
            return EXPR_SUCCESS;
            
        default:
            return EXPR_ERROR_INVALID_PARAM;
    }
}

/*
 * expr_evaluate
 *
 * Evaluates a compiled expression handle.
 *
 * Input: handle - compiled expression handle
 *        result - pointer to store result value
 * Output: EXPR_SUCCESS on success, error code on failure
 * Side effects: May modify variables through assignments
 *
 * Dependencies: AST evaluation functions
 *
 * Public API function for expression evaluation.
 */
int
expr_evaluate(expr_handle handle, double *result)
{
    if (!handle || !result)
        return EXPR_ERROR_INVALID_PARAM;
    
    if (!handle->root) {
        *result = NAN;
        return EXPR_SUCCESS;
    }
    
    return expr_priv_evaluate_node(handle->root, result);
}

/*
 * expr_easy
 *
 * Convenience function to compile, evaluate, and free expression.
 *
 * Input: ctx - context with symbol table
 *        expression - expression string
 *        result - pointer to store result value
 * Output: EXPR_SUCCESS on success, error code on failure
 * Side effects: Temporarily allocates handle memory
 *
 * Dependencies: Compilation and evaluation functions
 *
 * One-shot function for simple expression evaluation.
 */
int
expr_easy(expr_context ctx, const char *expression, double *result)
{
    expr_handle handle;
    int compile_ret, eval_ret;
    
    if (!ctx || !expression || !result)
        return EXPR_ERROR_INVALID_PARAM;
    
    compile_ret = expr_compile(ctx, expression, 0, &handle);
    if (compile_ret != EXPR_SUCCESS)
        return compile_ret;
    
    eval_ret = expr_evaluate(handle, result);
    expr_handle_free(handle);
    
    return eval_ret;
}

/*
 * expr_handle_free
 *
 * Frees a compiled expression handle and all associated memory.
 *
 * Input: handle - handle to free
 * Output: EXPR_SUCCESS on success, error code on failure
 * Side effects: Frees handle and AST memory
 *
 * Dependencies: AST cleanup functions
 *
 * Public API function for handle cleanup.
 */
int
expr_handle_free(expr_handle handle)
{
    if (!handle)
        return EXPR_ERROR_INVALID_PARAM;
    
    if (handle->root)
        expr_priv_node_free(handle->root);
    
    if (handle->original_expression)
        free(handle->original_expression);
    
    free(handle);
    return EXPR_SUCCESS;
}