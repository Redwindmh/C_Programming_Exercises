/*
 * expr_parser.c
 *
 * Copyright (C) 2025 by Robert Cousins
 * All Rights Reserved
 *
 * Recursive descent parser for mathematical expression evaluation library.
 * Implements operator precedence parsing following the specification's
 * precedence table with proper associativity handling.
 *
 * $Id: expr_parser_original.c,v 1.1 2025/06/25 16:02:06 rec Exp rec $
 *
 * Author: Robert Cousins
 *
 * 2025-06-22: Initial implementation
 */

#include "expr_private.h"

/*
 * expr_priv_skip_whitespace
 *
 * Advances parser position past whitespace characters.
 *
 * Input: state - parser state to modify
 * Output: None
 * Side effects: Updates current position in parser state
 *
 * Dependencies: Standard library character classification
 *
 * Skips spaces, tabs, newlines, and other whitespace.
 */
void
expr_priv_skip_whitespace(expr_parser_state_t *state)
{
    while (isspace(*state->current))
        state->current++;
}

/*
 * expr_priv_is_compound_assignment
 *
 * Checks if current position is start of compound assignment operator.
 *
 * Input: state - parser state
 *        op - operator character to check
 * Output: 1 if compound assignment, 0 otherwise
 * Side effects: None (doesn't advance position)
 *
 * Dependencies: Whitespace handling
 *
 * Looks ahead past whitespace to check for '=' after operator.
 */
int
expr_priv_is_compound_assignment(expr_parser_state_t *state, char op)
{
    const char *pos;
    
    if (!(state->options & EXPR_ENABLE_COMPOUND_ASSIGN))
        return 0;
    
    if (*state->current != op)
        return 0;
    
    pos = state->current + 1;
    while (isspace(*pos))
        pos++;
    
    return (*pos == '=');
}

/*
 * expr_priv_is_valid_identifier_start
 *
 * Checks if character can start an identifier.
 *
 * Input: c - character to check
 * Output: Non-zero if valid start character
 * Side effects: None
 *
 * Dependencies: Standard library character classification
 *
 * Identifiers start with letter or underscore.
 */
int
expr_priv_is_valid_identifier_start(int c)
{
    return isalpha(c) || c == '_';
}

/*
 * expr_priv_is_valid_identifier_char
 *
 * Checks if character can appear in an identifier.
 *
 * Input: c - character to check
 * Output: Non-zero if valid identifier character
 * Side effects: None
 *
 * Dependencies: Standard library character classification
 *
 * Identifiers contain letters, digits, underscores, and periods.
 */
int
expr_priv_is_valid_identifier_char(int c)
{
    return isalnum(c) || c == '_' || c == '.';
}

/*
 * expr_priv_parse_number
 *
 * Parses a numeric literal (decimal or hexadecimal).
 *
 * Input: state - parser state
 *        result - pointer to store parsed number
 * Output: EXPR_SUCCESS on success, error code on failure
 * Side effects: Updates parser position
 *
 * Dependencies: Standard library string conversion
 *
 * Supports decimal and 0x-prefixed hexadecimal numbers.
 */
int
expr_priv_parse_number(expr_parser_state_t *state, double *result)
{
    char *endptr;
    
    if (strncmp(state->current, "0x", 2) == 0 || strncmp(state->current, "0X", 2) == 0)
        *result = expr_priv_parse_hex_number(state->current, &endptr);
    else
        *result = strtod(state->current, &endptr);
    
    if (endptr == state->current) {
        expr_priv_set_error(state->ctx, "Invalid number format", state->current);
        return EXPR_ERROR_PARSE;
    }
    
    state->current = endptr;
    return EXPR_SUCCESS;
}

/*
 * expr_priv_parse_hex_number
 *
 * Parses a hexadecimal number literal.
 *
 * Input: str - string to parse
 *        endptr - pointer to store end position
 * Output: Parsed number value
 * Side effects: None
 *
 * Dependencies: Standard library character classification
 *
 * Converts 0x-prefixed hex strings to double values.
 */
double
expr_priv_parse_hex_number(const char *str, char **endptr)
{
    double result = 0.0;
    const char *p = str + 2;
    
    while (isxdigit(*p)) {
        result = result * 16.0;
        if (*p >= '0' && *p <= '9')
            result += *p - '0';
        else if (*p >= 'a' && *p <= 'f')
            result += *p - 'a' + 10;
        else if (*p >= 'A' && *p <= 'F')
            result += *p - 'A' + 10;
        p++;
    }
    
    *endptr = (char*)p;
    return result;
}

/*
 * expr_priv_parse_identifier
 *
 * Parses an identifier (variable, constant, or function name).
 *
 * Input: state - parser state
 *        result - pointer to store identifier string
 * Output: EXPR_SUCCESS on success, error code on failure
 * Side effects: Updates parser position, allocates memory
 *
 * Dependencies: Memory allocation, string manipulation
 *
 * Creates copy of identifier string for caller.
 */
int
expr_priv_parse_identifier(expr_parser_state_t *state, char **result)
{
    const char *start = state->current;
    int len;
    
    if (!expr_priv_is_valid_identifier_start(*state->current)) {
        expr_priv_set_error(state->ctx, "Invalid identifier", state->current);
        return EXPR_ERROR_PARSE;
    }
    
    while (expr_priv_is_valid_identifier_char(*state->current))
        state->current++;
    
    len = (int)(state->current - start);
    *result = (char*)malloc(len + 1);
    if (!*result)
        return EXPR_ERROR_MEMORY;
    
    strncpy(*result, start, len);
    (*result)[len] = '\0';
    
    return EXPR_SUCCESS;
}

/*
 * expr_priv_parse_primary
 *
 * Parses primary expressions (numbers, identifiers, parentheses).
 *
 * Input: state - parser state
 *        result - pointer to store parsed node
 * Output: EXPR_SUCCESS on success, error code on failure
 * Side effects: Updates parser position, creates AST nodes
 *
 * Dependencies: Number/identifier parsing, symbol lookup
 *
 * Handles numbers, variables, constants, functions, and parentheses.
 */
int
expr_priv_parse_primary(expr_parser_state_t *state, expr_node_t **result)
{
    expr_node_t *node;
    char *name;
    expr_symbol_t *symbol;
    double number;
    int ret, i, arg_count;
    
    expr_priv_skip_whitespace(state);
    
    if (*state->current == '\0') {
        expr_priv_set_error(state->ctx, "Unexpected end of expression", state->current);
        return EXPR_ERROR_PARSE;
    }
    
    if (*state->current == '(') {
        state->current++;
        ret = expr_priv_parse_expression(state, result);
        if (ret != EXPR_SUCCESS)
            return ret;
        
        expr_priv_skip_whitespace(state);
        if (*state->current != ')') {
            expr_priv_set_error(state->ctx, "Missing closing parenthesis", state->current);
            expr_priv_node_free(*result);
            return EXPR_ERROR_PARSE;
        }
        state->current++;
        return EXPR_SUCCESS;
    }
    
    if (isdigit(*state->current) || 
        ((*state->current == '0') && (state->current[1] == 'x' || state->current[1] == 'X'))) {
        ret = expr_priv_parse_number(state, &number);
        if (ret != EXPR_SUCCESS)
            return ret;
        
        node = expr_priv_node_new(EXPR_NODE_NUMBER);
        if (!node)
            return EXPR_ERROR_MEMORY;
        
        node->data.number = number;
        *result = node;
        return EXPR_SUCCESS;
    }
    
    if (expr_priv_is_valid_identifier_start(*state->current)) {
        ret = expr_priv_parse_identifier(state, &name);
        if (ret != EXPR_SUCCESS)
            return ret;
        
        symbol = expr_priv_symbol_find(state->ctx, name);
        if (!symbol) {
            expr_priv_set_error(state->ctx, "Undefined symbol", state->current - strlen(name));
            free(name);
            return EXPR_ERROR_UNDEFINED_SYMBOL;
        }
        
        expr_priv_skip_whitespace(state);
        
        switch (symbol->type) {
            case EXPR_SYMBOL_CONSTANT:
                node = expr_priv_node_new(EXPR_NODE_CONSTANT);
                if (!node) {
                    free(name);
                    return EXPR_ERROR_MEMORY;
                }
                node->data.symbol.name = name;
                node->data.symbol.symbol_ptr = symbol;
                *result = node;
                return EXPR_SUCCESS;
                
            case EXPR_SYMBOL_VARIABLE:
                node = expr_priv_node_new(EXPR_NODE_VARIABLE);
                if (!node) {
                    free(name);
                    return EXPR_ERROR_MEMORY;
                }
                node->data.symbol.name = name;
                node->data.symbol.symbol_ptr = symbol;
                *result = node;
                return EXPR_SUCCESS;
                
            case EXPR_SYMBOL_FUNCTION0:
            case EXPR_SYMBOL_FUNCTION1:
            case EXPR_SYMBOL_FUNCTION2:
            case EXPR_SYMBOL_FUNCTION3:
            case EXPR_SYMBOL_FUNCTION4:
                if (*state->current != '(') {
                    expr_priv_set_error(state->ctx, "Function requires parentheses", state->current);
                    free(name);
                    return EXPR_ERROR_PARSE;
                }
                
                state->current++;
                
                arg_count = symbol->type - EXPR_SYMBOL_FUNCTION0;
                node = expr_priv_node_new(EXPR_NODE_FUNCTION0 + arg_count);
                if (!node) {
                    free(name);
                    return EXPR_ERROR_MEMORY;
                }
                
                node->data.function.arg_count = arg_count;
                node->data.function.symbol_ptr = symbol;
                
                if (arg_count > 0) {
                    node->data.function.args = (expr_node_t**)malloc(arg_count * sizeof(expr_node_t*));
                    if (!node->data.function.args) {
                        free(name);
                        expr_priv_node_free(node);
                        return EXPR_ERROR_MEMORY;
                    }
                    
                    /* Initialize all pointers to NULL for safe cleanup */
                    for (i = 0; i < arg_count; i++) {
                        node->data.function.args[i] = NULL;
                    }
                    
                    for (i = 0; i < arg_count; i++) {
                        if (i > 0) {
                            expr_priv_skip_whitespace(state);
                            if (*state->current != ',') {
                                expr_priv_set_error(state->ctx, "Missing comma in function arguments", state->current);
                                free(name);
                                expr_priv_node_free(node);
                                return EXPR_ERROR_PARSE;
                            }
                            state->current++;
                        }
                        
                        ret = expr_priv_parse_expression(state, &node->data.function.args[i]);
                        if (ret != EXPR_SUCCESS) {
                            free(name);
                            expr_priv_node_free(node);
                            return ret;
                        }
                    }
                }
                
                expr_priv_skip_whitespace(state);
                if (*state->current != ')') {
                    expr_priv_set_error(state->ctx, "Missing closing parenthesis in function call", state->current);
                    free(name);
                    expr_priv_node_free(node);
                    return EXPR_ERROR_PARSE;
                }
                state->current++;
                
                free(name);
                *result = node;
                return EXPR_SUCCESS;
        }
    }
    
    expr_priv_set_error(state->ctx, "Unexpected character", state->current);
    return EXPR_ERROR_PARSE;
}

/*
 * expr_priv_parse_unary
 *
 * Parses unary expressions (unary +, unary -).
 *
 * Input: state - parser state
 *        result - pointer to store parsed node
 * Output: EXPR_SUCCESS on success, error code on failure
 * Side effects: Updates parser position, creates AST nodes
 *
 * Dependencies: Primary expression parsing
 *
 * Handles unary plus and minus operators with right associativity.
 */
int
expr_priv_parse_unary(expr_parser_state_t *state, expr_node_t **result)
{
    expr_node_t *node;
    int ret;
    
    expr_priv_skip_whitespace(state);
    
    if (*state->current == '+') {
        state->current++;
        ret = expr_priv_parse_unary(state, result);
        if (ret != EXPR_SUCCESS)
            return ret;
        
        node = expr_priv_node_new(EXPR_NODE_UNARY_PLUS);
        if (!node) {
            expr_priv_node_free(*result);
            return EXPR_ERROR_MEMORY;
        }
        
        node->data.unary.operand = *result;
        *result = node;
        return EXPR_SUCCESS;
    }
    
    if (*state->current == '-') {
        state->current++;
        ret = expr_priv_parse_unary(state, result);
        if (ret != EXPR_SUCCESS)
            return ret;
        
        node = expr_priv_node_new(EXPR_NODE_UNARY_MINUS);
        if (!node) {
            expr_priv_node_free(*result);
            return EXPR_ERROR_MEMORY;
        }
        
        node->data.unary.operand = *result;
        *result = node;
        return EXPR_SUCCESS;
    }
    
    return expr_priv_parse_primary(state, result);
}

/*
 * expr_priv_parse_power
 *
 * Parses power expressions (^ operator).
 *
 * Input: state - parser state
 *        result - pointer to store parsed node
 * Output: EXPR_SUCCESS on success, error code on failure
 * Side effects: Updates parser position, creates AST nodes
 *
 * Dependencies: Unary expression parsing
 *
 * Handles exponentiation with right associativity.
 */
int
expr_priv_parse_power(expr_parser_state_t *state, expr_node_t **result)
{
    expr_node_t *left, *right, *node;
    int ret;
    
    ret = expr_priv_parse_unary(state, &left);
    if (ret != EXPR_SUCCESS)
        return ret;
    
    expr_priv_skip_whitespace(state);
    
    if (*state->current == '^' && (state->options & EXPR_ENABLE_POWER)) {
        /* Check for compound assignment */
        if (expr_priv_is_compound_assignment(state, '^')) {
            *result = left;
            return EXPR_SUCCESS;  /* Let assignment parser handle it */
        }
        state->current++;
        ret = expr_priv_parse_power(state, &right);
        if (ret != EXPR_SUCCESS) {
            expr_priv_node_free(left);
            return ret;
        }
        
        node = expr_priv_node_new(EXPR_NODE_POWER);
        if (!node) {
            expr_priv_node_free(left);
            expr_priv_node_free(right);
            return EXPR_ERROR_MEMORY;
        }
        
        node->data.binary.left = left;
        node->data.binary.right = right;
        *result = node;
        return EXPR_SUCCESS;
    }
    
    *result = left;
    return EXPR_SUCCESS;
}

/*
 * expr_priv_parse_multiplication
 *
 * Parses multiplication, division, and modulo expressions.
 *
 * Input: state - parser state
 *        result - pointer to store parsed node
 * Output: EXPR_SUCCESS on success, error code on failure
 * Side effects: Updates parser position, creates AST nodes
 *
 * Dependencies: Power expression parsing
 *
 * Handles *, /, % operators with left associativity.
 */
int
expr_priv_parse_multiplication(expr_parser_state_t *state, expr_node_t **result)
{
    expr_node_t *left, *right, *node;
    expr_node_type_t op_type;
    int ret;
    
    ret = expr_priv_parse_power(state, &left);
    if (ret != EXPR_SUCCESS)
        return ret;
    
    while (1) {
        expr_priv_skip_whitespace(state);
        
        if (*state->current == '*') {
            /* Check for compound assignment */
            if (expr_priv_is_compound_assignment(state, '*')) {
                break;  /* Let assignment parser handle it */
            }
            op_type = EXPR_NODE_MULTIPLY;
        } else if (*state->current == '/') {
            /* Check for compound assignment */
            if (expr_priv_is_compound_assignment(state, '/')) {
                break;  /* Let assignment parser handle it */
            }
            op_type = EXPR_NODE_DIVIDE;
        } else if (*state->current == '%' && (state->options & EXPR_ENABLE_MODULO)) {
            /* Check for compound assignment */
            if (expr_priv_is_compound_assignment(state, '%')) {
                break;  /* Let assignment parser handle it */
            }
            op_type = EXPR_NODE_MODULO;
        } else {
            break;
        }
        
        state->current++;
        ret = expr_priv_parse_power(state, &right);
        if (ret != EXPR_SUCCESS) {
            expr_priv_node_free(left);
            return ret;
        }
        
        node = expr_priv_node_new(op_type);
        if (!node) {
            expr_priv_node_free(left);
            expr_priv_node_free(right);
            return EXPR_ERROR_MEMORY;
        }
        
        node->data.binary.left = left;
        node->data.binary.right = right;
        left = node;
    }
    
    *result = left;
    return EXPR_SUCCESS;
}

/*
 * expr_priv_parse_addition
 *
 * Parses addition and subtraction expressions.
 *
 * Input: state - parser state
 *        result - pointer to store parsed node
 * Output: EXPR_SUCCESS on success, error code on failure
 * Side effects: Updates parser position, creates AST nodes
 *
 * Dependencies: Multiplication expression parsing
 *
 * Handles +, - binary operators with left associativity.
 */
int
expr_priv_parse_addition(expr_parser_state_t *state, expr_node_t **result)
{
    expr_node_t *left, *right, *node;
    expr_node_type_t op_type;
    int ret;
    
    ret = expr_priv_parse_multiplication(state, &left);
    if (ret != EXPR_SUCCESS)
        return ret;
    
    while (1) {
        expr_priv_skip_whitespace(state);
        
        if (*state->current == '+') {
            /* Check for compound assignment */
            if (expr_priv_is_compound_assignment(state, '+')) {
                break;  /* Let assignment parser handle it */
            }
            op_type = EXPR_NODE_ADD;
        } else if (*state->current == '-') {
            /* Check for compound assignment */
            if (expr_priv_is_compound_assignment(state, '-')) {
                break;  /* Let assignment parser handle it */
            }
            op_type = EXPR_NODE_SUBTRACT;
        } else {
            break;
        }
        
        state->current++;
        ret = expr_priv_parse_multiplication(state, &right);
        if (ret != EXPR_SUCCESS) {
            expr_priv_node_free(left);
            return ret;
        }
        
        node = expr_priv_node_new(op_type);
        if (!node) {
            expr_priv_node_free(left);
            expr_priv_node_free(right);
            return EXPR_ERROR_MEMORY;
        }
        
        node->data.binary.left = left;
        node->data.binary.right = right;
        left = node;
    }
    
    *result = left;
    return EXPR_SUCCESS;
}

/*
 * expr_priv_parse_assignment
 *
 * Parses assignment expressions (=, +=, -=, etc.).
 *
 * Input: state - parser state
 *        result - pointer to store parsed node
 * Output: EXPR_SUCCESS on success, error code on failure
 * Side effects: Updates parser position, creates AST nodes
 *
 * Dependencies: Addition expression parsing
 *
 * Handles assignment operators with right associativity.
 */
int
expr_priv_parse_assignment(expr_parser_state_t *state, expr_node_t **result)
{
    expr_node_t *left, *right, *node;
    expr_node_type_t op_type;
    int ret;
    const char *op_start;
    
    ret = expr_priv_parse_addition(state, &left);
    if (ret != EXPR_SUCCESS)
        return ret;
    
    expr_priv_skip_whitespace(state);
    op_start = state->current;
    
    if (*state->current == '+' && state->current[1] == '=' && 
        (state->options & EXPR_ENABLE_COMPOUND_ASSIGN)) {
        state->current += 2;
        op_type = EXPR_NODE_ADD_ASSIGN;
    } else if (*state->current == '-' && state->current[1] == '=' && 
               (state->options & EXPR_ENABLE_COMPOUND_ASSIGN)) {
        state->current += 2;
        op_type = EXPR_NODE_SUB_ASSIGN;
    } else if (*state->current == '*' && state->current[1] == '=' && 
               (state->options & EXPR_ENABLE_COMPOUND_ASSIGN)) {
        state->current += 2;
        op_type = EXPR_NODE_MUL_ASSIGN;
    } else if (*state->current == '/' && state->current[1] == '=' && 
               (state->options & EXPR_ENABLE_COMPOUND_ASSIGN)) {
        state->current += 2;
        op_type = EXPR_NODE_DIV_ASSIGN;
    } else if (*state->current == '^' && state->current[1] == '=' && 
               (state->options & EXPR_ENABLE_COMPOUND_ASSIGN) && 
               (state->options & EXPR_ENABLE_POWER)) {
        state->current += 2;
        op_type = EXPR_NODE_POW_ASSIGN;
    } else if (*state->current == '%' && state->current[1] == '=' && 
               (state->options & EXPR_ENABLE_COMPOUND_ASSIGN) && 
               (state->options & EXPR_ENABLE_MODULO)) {
        state->current += 2;
        op_type = EXPR_NODE_MOD_ASSIGN;
    } else if (*state->current == '=') {
        state->current++;
        if (*state->current == '=') {
            state->current = op_start;
            *result = left;
            return EXPR_SUCCESS;
        }
        op_type = EXPR_NODE_ASSIGN;
    } else {
        *result = left;
        return EXPR_SUCCESS;
    }
    
    ret = expr_priv_parse_assignment(state, &right);
    if (ret != EXPR_SUCCESS) {
        expr_priv_node_free(left);
        return ret;
    }
    
    node = expr_priv_node_new(op_type);
    if (!node) {
        expr_priv_node_free(left);
        expr_priv_node_free(right);
        return EXPR_ERROR_MEMORY;
    }
    
    node->data.binary.left = left;
    node->data.binary.right = right;
    *result = node;
    return EXPR_SUCCESS;
}

/*
 * expr_priv_parse_sequence
 *
 * Parses sequence expressions (semicolon-separated).
 *
 * Input: state - parser state
 *        result - pointer to store parsed node
 * Output: EXPR_SUCCESS on success, error code on failure
 * Side effects: Updates parser position, creates AST nodes
 *
 * Dependencies: Assignment expression parsing
 *
 * Handles semicolon operator for expression sequences.
 */
int
expr_priv_parse_sequence(expr_parser_state_t *state, expr_node_t **result)
{
    expr_node_t *left, *right, *node;
    int ret;
    
    ret = expr_priv_parse_assignment(state, &left);
    if (ret != EXPR_SUCCESS)
        return ret;
    
    expr_priv_skip_whitespace(state);
    
    if (*state->current == ';' && (state->options & EXPR_ALLOW_SEMICOLON)) {
        state->current++;
        ret = expr_priv_parse_sequence(state, &right);
        if (ret != EXPR_SUCCESS) {
            expr_priv_node_free(left);
            return ret;
        }
        
        node = expr_priv_node_new(EXPR_NODE_SEQUENCE);
        if (!node) {
            expr_priv_node_free(left);
            expr_priv_node_free(right);
            return EXPR_ERROR_MEMORY;
        }
        
        node->data.binary.left = left;
        node->data.binary.right = right;
        *result = node;
        return EXPR_SUCCESS;
    }
    
    *result = left;
    return EXPR_SUCCESS;
}

/*
 * expr_priv_parse_expression
 *
 * Parses a complete expression using recursive descent.
 *
 * Input: state - parser state
 *        result - pointer to store parsed AST
 * Output: EXPR_SUCCESS on success, error code on failure
 * Side effects: Updates parser position, creates AST
 *
 * Dependencies: All precedence level parsers
 *
 * Top-level parsing function that starts precedence chain.
 */
int
expr_priv_parse_expression(expr_parser_state_t *state, expr_node_t **result)
{
    return expr_priv_parse_sequence(state, result);
}

/*
 * expr_compile
 *
 * Compiles an expression string into an AST handle.
 *
 * Input: ctx - context with symbol table
 *        expression - expression string to compile
 *        options - compilation options
 *        handle - pointer to store compiled handle
 * Output: EXPR_SUCCESS on success, error code on failure
 * Side effects: Allocates handle and AST memory
 *
 * Dependencies: Parser, handle creation
 *
 * Public API function for expression compilation.
 */
int
expr_compile(expr_context ctx, const char *expression, unsigned options, expr_handle *handle)
{
    expr_parser_state_t state;
    expr_handle_struct_t *new_handle;
    int ret;
    
    if (!ctx || !expression || !handle)
        return EXPR_ERROR_INVALID_PARAM;
    
    if (strlen(expression) == 0) {
        expr_priv_set_error(ctx, "Empty expression", expression);
        return EXPR_ERROR_EMPTY_EXPR;
    }
    
    new_handle = (expr_handle_struct_t*)malloc(sizeof(expr_handle_struct_t));
    if (!new_handle)
        return EXPR_ERROR_MEMORY;
    
    new_handle->original_expression = (char*)malloc(strlen(expression) + 1);
    if (!new_handle->original_expression) {
        free(new_handle);
        return EXPR_ERROR_MEMORY;
    }
    strcpy(new_handle->original_expression, expression);
    
    new_handle->ctx = ctx;
    new_handle->root = NULL;
    
    state.input = expression;
    state.current = expression;
    state.ctx = ctx;
    state.options = options;
    
    ctx->parse_position = expression;
    
    ret = expr_priv_parse_expression(&state, &new_handle->root);
    if (ret != EXPR_SUCCESS) {
        free(new_handle->original_expression);
        free(new_handle);
        return ret;
    }
    
    expr_priv_skip_whitespace(&state);
    if (*state.current != '\0') {
        expr_priv_set_error(ctx, "Unexpected characters at end of expression", state.current);
        expr_priv_node_free(new_handle->root);
        free(new_handle->original_expression);
        free(new_handle);
        return EXPR_ERROR_PARSE;
    }
    
    *handle = new_handle;
    return EXPR_SUCCESS;
}